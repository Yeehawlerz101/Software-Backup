--Nacho's Hax.
--For "Educational" purposes only... Nacho should not and will not be blamed for anything that happens with this...
print("Nacho's Hax: V6.15")
local TriggerBot = false
local Autoshoot = false
local Aimbot = false
local WallHack = false
local Entdetect = 0
local ChatSpam = CreateClientConVar( "hax_chatspam", "false", true, false )
local AimbotStyle = CreateClientConVar( "hax_aimbotstyle", 0, true, false )
local StatViewer = 0
local WallGlow = false
local HitWarner = false
local FreeCam = false
local Movement = CreateClientConVar( "hax_alignment", 0, true, false )
local Friend = CreateClientConVar( "hax_friend", 0, true, false )
local FCV = {
Pos = LocalPlayer():EyePos(),
Ang = LocalPlayer():EyeAngles(),
SpeedTog = 0
}
local Hlog = {}
local EntityList = {}
function EntityAdd(Name, Ent, Type)
	table.insert(EntityList, {Name=Name, Ent=Ent, Type=Type})
end
function addLog(str)
	if #Hlog >= 10 then
		table.remove(Hlog, 1)
	end
	table.insert(Hlog, str)
end
concommand.Add("hax_enabled", function()
	TriggerBot = !TriggerBot
	if (TriggerBot) then
		addLog("Hax enabled.")
	else
		addLog("Hax disabled.")
	end
end)
concommand.Add("hax_autoshoot", function()
	Autoshoot = !Autoshoot
	if (Autoshoot) then
		addLog("Autoshoot enabled.")
	else
		addLog("Autoshoot disabled.")
	end
end)
concommand.Add("hax_aimbot", function()
	Aimbot = !Aimbot
	if (Aimbot) then
		addLog("Aimbot enabled.")
	else
		addLog("Aimbot disabled.")
	end
end)
concommand.Add("hax_wallhack", function()
	WallHack = !WallHack
	if (WallHack) then
		addLog("Wall hack enabled.")
	else
		addLog("Wall hack disabled.")
	end
end)
concommand.Add("hax_entdetect", function()
	Entdetect = Entdetect + 1
	if Entdetect > 3 then Entdetect = 0 end
	if (Entdetect) then
		addLog("Entity Detector enabled.")
	else
		addLog("Entity Detector disabled.")
	end
end)
concommand.Add("hax_statviewer", function()
	if StatViewer == 0 then
		StatViewer = 1
	elseif StatViewer == 1 then
		StatViewer = 2
	elseif StatViewer == 2 then
		StatViewer = 0
	end
end)
concommand.Add("hax_hitwarner", function()
	HitWarner = !HitWarner
end)
concommand.Add("hax_glow", function()
	WallGlow = !WallGlow
end)
concommand.Add("hax_addprinter", function(ply, cmd, args)
	PrinterDerma()
end)
concommand.Add("hax_freecam", function(ply, cmd, args)
	FreeCam = !FreeCam
	FCV.Pos = LocalPlayer():EyePos()
	FCV.Ang = LocalPlayer():EyeAngles()
	FCV.SpeedTog = 0
end)
concommand.Add("hax_help", function(ply, cmd, args)
	print("hax_enabled	-	Enable Hax.")
	print("hax_autofire	-	Automatically shoot when you look at a player.")
	print("hax_aimbot	-	Lock onto a player and automatically aim at them.")
	print("hax_wallhack	-	See people through walls.")
	print("hax_entdetect	-	Has 3 settings:\n				1. Moneyprinter detection.\n				2. Shipment detection.\n				3. All of the above.")
end)

if not file.Exists("haxmp.txt", "DATA") then
	file.Write("haxmp.txt", "Money Printer|money_printer")
	EntityAdd("Money Printer", "money_printer", 1)
else
	UnSplit = file.Read("haxmp.txt", "DATA")
	Split = string.Explode("#", UnSplit)
	for k,v in pairs(Split) do
		ReSplit = string.Explode("|", v)
		EntityAdd(ReSplit[1], ReSplit[2], 1)
	end
end
EntityAdd("Money Printer", "money_printer", 1)
EntityAdd("Bronze Printer", "bronze_moneyprinter", 1)
EntityAdd("Topaz Printer", "topaz_printer", 1)
EntityAdd("Silver Printer", "silver_moneyprinter", 1)
EntityAdd("Titanium Printer", "titaniun_moneyprinter", 1)
EntityAdd("Gold Printer", "gold_moneyprinter", 1)
EntityAdd("Platinum Printer", "platinum_moneyprinter", 1)
EntityAdd("Purplite Printer", "purplite_moneyprinter", 1)
EntityAdd("Melon Printer", "melon_moneyprinter", 1)
EntityAdd("Money Printer", "adv_moneyprinter", 1)
EntityAdd("Bronze Printer", "money_printer_advbronze", 1)
EntityAdd("Silver Printer", "money_printer_advsilver", 1)
EntityAdd("Gold Printer", "money_printer_advgold", 1)
EntityAdd("Platinum Printer", "money_printer_advplatinum", 1)
EntityAdd("Wooden Money Printer", "wooden_money_printer", 1)
EntityAdd("Plastic Money Printer", "plastic_money_printer", 1)
EntityAdd("Stone Money Printer", "stone_money_printer", 1)
EntityAdd("Tin Money Printer", "tin_money_printer", 1)
EntityAdd("Iron Money Printer", "iron_money_printer", 1)
EntityAdd("Steel Money Printer", "steel_money_printer", 1)
EntityAdd("Bronze Money Printer", "bronze_money_printer", 1)
EntityAdd("Brass Money Printer", "brass_money_printer", 1)
EntityAdd("Silver Money Printer", "silver_money_printer", 1)
EntityAdd("Gold Money Printer", "gold_money_printer", 1)
EntityAdd("Shipment", "spawned_shipment", 2)
EntityAdd("Entity", "spawned_weapon", 2)
EntityAdd("Money", "spawned_money", 2)
lockEnt = nil
function correctMovement(ply)
	local lply = LocalPlayer()
	local lvel = lply:GetVelocity()
	local vel = ply:GetVelocity()
	local c = 30
	return (vel/c) - (lvel/c)
end
function aimbotTarget(lockEnt, ply)
	if lockEnt:Alive() and lockEnt:IsPlayer() then
		local targethead = lockEnt:LookupBone("ValveBiped.Bip01_Spine2") -- In this aimbot we only aim for the head.
		local targetheadpos,targetheadang = lockEnt:GetBonePosition(targethead) -- Get the position/angle of the head.
		local TriggerBot = CreateClientConVar( "triggerbot_enabled", 0, true, false )
		ply:SetEyeAngles((targetheadpos - ply:GetShootPos() + correctMovement(lockEnt)):Angle()) -- And finally, we snap our aim to the head of the target.
	else
		lockEnt = 0
	end
end
function aimbot()
	local ply = LocalPlayer()
	local trace = util.GetPlayerTrace( ply )
	local traceRes = util.TraceLine( trace )
	if (AimbotStyle:GetInt() == 0) then
		if lockEnt == 0 then
			if traceRes.HitNonWorld then
				local target = traceRes.Entity
				if target:IsPlayer() then
					lockEnt = target
				end
			end
		else
			if ((Friend:GetInt()>0) and (lockEnt:GetFriendStatus()=="friend")) then return end
			aimbotTarget(lockEnt, ply)
		end
	elseif (AimbotStyle:GetInt() == 1) then
		if lockEnt == 0 then
			local closest = 0
			for k,v in pairs(player.GetAll()) do
				if closest ~= 0 then
					if v:GetPos():Distance(ply:GetPos()) < closest:GetPos():Distance(ply:GetPos()) and not ((Friend:GetInt()>0) and (v:GetFriendStatus()=="friend")) then
						if v ~= ply and v:Alive() then
							closest = v
						end
					end
				else
					if v ~= ply and v:Alive() then
						closest = v
					end
				end
			end
			lockEnt = closest
		end
		aimbotTarget(lockEnt, ply)
	elseif (AimbotStyle:GetInt() == 2) then
		local closest = 0
		for k,v in pairs(player.GetAll()) do
			if closest ~= 0 then
				if v:GetPos():Distance(ply:GetPos()) < closest:GetPos():Distance(ply:GetPos()) and not ((Friend:GetInt()>0) and (v:GetFriendStatus()=="friend")) then
					if v ~= ply and v:Alive() then
						closest = v
					end
				end
			else
				if v ~= ply and v:Alive() then
					closest = v
				end
			end
		end
		lockEnt = closest
		aimbotTarget(lockEnt, ply)
	end
end
function chatspam()
	RunConsoleCommand( "say", ChatSpam:GetString() )
end
hook.Add( "Think", "Triggerbot", function()
	
	if TriggerBot and Aimbot then
		if !Hold then
			lockEnt = 0
		end
		aimbot()
	end
	if TriggerBot and ChatSpam:GetString() != "false" then
		chatspam()
	end
	local Target = LocalPlayer():GetEyeTrace().Entity		 
	if TriggerBot and Autoshoot and LocalPlayer():Alive() and LocalPlayer():GetActiveWeapon():IsValid() and ( Target:IsPlayer() or Target:IsNPC() ) then
			 
		if !Firing then
			 
			RunConsoleCommand( "+attack" )
			LocalPlayer():GetActiveWeapon().SetNextPrimaryFire( LocalPlayer():GetActiveWeapon() )
			Firing = true
			 
		else
			 
			RunConsoleCommand( "-attack" ) 
			Firing = false
			 
		end
	end
	if (!Autoshoot or TriggerBot) and Firing == true then
		RunConsoleCommand( "-attack" ) 
		Firing = false
	end
	RunConsoleCommand( "-attack" ) 
	Firing = false
	Hold = Aimbot
	
	if (TriggerBot and FreeCam) then
		FCV.SpeedTog = 0
		if (LocalPlayer():KeyDown(IN_ATTACK)) then
			if (LocalPlayer():KeyDown(IN_ATTACK2)) then
				FCV.SpeedTog = 1
			end
			FCV.Pos = FCV.Pos + LocalPlayer():EyeAngles():Forward()*(3+(10*(FCV.SpeedTog)))
		end
		FCV.Ang = LocalPlayer():EyeAngles()
	end
end)
		
surface.CreateFont("ScoreboardText", {
	size = 20,
	weight = 550,
	antialias = true,
	shadow = false,
	font = "coolvetica",
	outline = true})
surface.CreateFont("ScoreboardText2", {
	size = 30,
	weight = 550,
	antialias = true,
	shadow = false,
	font = "coolvetica",
	outline = true})
surface.CreateFont("ScoreboardText3", {
	size = 72,
	weight = 1000,
	antialias = true,
	shadow = false,
	font = "coolvetica",
	outline = true})	
function AddStat(ply, text)
	local Pos = ( ply:GetPos() + Vector( 0,0,50 ) ):ToScreen()
	draw.DrawText( text, "ScoreboardText", Pos.x-50, Pos.y+10+(Extra*20), Color(255,255,255), 0 )
	Extra = Extra+1
end
function PaintStats1(ply)
	Size = 120
	Extra = 1
	if ply:isHitman() then
		Size = Size+20
	end
	if not ply:GetActiveWeapon() == nil then
		Size = Size+20
	end
	if ply:IsAdmin() then
		Size = Size+20
	end
	for k,v in pairs(player.GetAll()) do
		if v:isHitman() then
			if v:hasHit() then
				if v:getHitTarget() == ply then
					Size = Size+20
				end
			end
		end
	end
	if ply:Alive() then
		local Pos = ( ply:GetPos() + Vector( 0,0,50 ) ):ToScreen()
		draw.RoundedBox(8, Pos.x-60,Pos.y,200,Size, Color(100,0,0,200))
		draw.DrawText( "Steam: "..ply:SteamID(), "ScoreboardText", Pos.x-50, Pos.y+10, Color(255,255,255), 0 )
		AddStat(ply, "Name: "..ply:Name())
		AddStat(ply, "Health: "..ply:Health())
		AddStat(ply, "Armor: "..ply:Armor())
		AddStat(ply, "Cash: "..tostring(ply:getDarkRPVar("money")))
		if not ply:GetActiveWeapon() == nil then
			AddStat(ply, "Weapon: "..ply:GetActiveWeapon():GetClass())
		end
		for k,v in pairs(player.GetAll()) do
			if v:isHitman() then
				if v:hasHit() then
					if v:getHitTarget() == ply then
						AddStat(ply, "Target: "..v:Name())
					end
				end
			end
		end
		if ply:isHitman() then
			if ply:hasHit() then
				AddStat(ply, "Hit: "..ply:getHitTarget():Name())
			else
				AddStat(ply, "Hit: None")
			end
		end
		if ply:IsAdmin() and ply:isHitman() then
			AddStat(ply, "Is Admin")
		elseif ply:IsAdmin() then
			AddStat(ply, "Is Admin")
		end
	end
end
function PaintStats2(ply)
	Extra = 1
	local Pos = ( ply:GetPos() + Vector( 0,0,50 ) ):ToScreen()
	draw.RoundedBox(8, Pos.x-60,Pos.y+20,200,(table.Count(ply:GetWeapons())*20)+40, Color(100,0,0,200))
	AddStat(ply, "Weapons:")
	for k,v in SortedPairs(ply:GetWeapons()) do
		AddStat(ply, v:GetClass()..": "..v:Clip1().." | "..ply:GetAmmoCount( v:GetPrimaryAmmoType()))
	end
end
function dispHax()
	if TriggerBot then
		draw.RoundedBox( 8, 19, 19 + Movement:GetInt(), 22, 22, Color( 255, 255, 255, 255 ))
		draw.RoundedBox( 8, 20, 20 + Movement:GetInt(), 20, 20, Color( 140, 140, 140, 255 ))
		draw.DrawText( "Wall Hack", "ScoreboardText", 50, 20 + Movement:GetInt(), Color( 255, 255, 255, 255 ), 0 )
		draw.RoundedBox( 8, 19, 49 + Movement:GetInt(), 22, 22, Color( 255, 255, 255, 255 ))
		draw.RoundedBox( 8, 20, 50 + Movement:GetInt(), 20, 20, Color( 140, 140, 140, 255 ))
		draw.DrawText( "Aim Bot", "ScoreboardText", 50, 50 + Movement:GetInt(), Color( 255, 255, 255, 255 ), 0 )
		draw.RoundedBox( 8, 19, 79 + Movement:GetInt(), 22, 22, Color( 255, 255, 255, 255 ))
		draw.RoundedBox( 8, 20, 80 + Movement:GetInt(), 20, 20, Color( 140, 140, 140, 255 ))
		draw.DrawText( "Autoshoot", "ScoreboardText", 50, 80 + Movement:GetInt(), Color( 255, 255, 255, 255 ), 0 )
		draw.RoundedBox( 8, 19, 109 + Movement:GetInt(), 22, 22, Color( 255, 255, 255, 255 ))
		draw.RoundedBox( 8, 20, 110 + Movement:GetInt(), 20, 20, Color( 140, 140, 140, 255 ))
		draw.DrawText( "Entity Detector", "ScoreboardText", 50, 110 + Movement:GetInt(), Color( 255, 255, 255, 255 ), 0 )
		draw.RoundedBox( 8, 19, 139 + Movement:GetInt(), 22, 22, Color( 255, 255, 255, 255 ))
		draw.RoundedBox( 8, 20, 140 + Movement:GetInt(), 20, 20, Color( 140, 140, 140, 255 ))
		draw.DrawText( "Chat Spammer", "ScoreboardText", 50, 140 + Movement:GetInt(), Color( 255, 255, 255, 255 ), 0 )
		draw.RoundedBox( 8, 19, 169 + Movement:GetInt(), 22, 22, Color( 255, 255, 255, 255 ))
		draw.RoundedBox( 8, 20, 170 + Movement:GetInt(), 20, 20, Color( 140, 140, 140, 255 ))
		draw.DrawText( "Glow", "ScoreboardText", 50, 170 + Movement:GetInt(), Color( 255, 255, 255, 255 ), 0 )
		draw.RoundedBox( 8, 19, 199 + Movement:GetInt(), 22, 22, Color( 255, 255, 255, 255 ))
		draw.RoundedBox( 8, 20, 200 + Movement:GetInt(), 20, 20, Color( 140, 140, 140, 255 ))
		draw.DrawText( "Stat Viewer", "ScoreboardText", 50, 200 + Movement:GetInt(), Color( 255, 255, 255, 255 ), 0 )
		draw.RoundedBox( 8, 19, 229 + Movement:GetInt(), 22, 22, Color( 255, 255, 255, 255 ))
		draw.RoundedBox( 8, 20, 230 + Movement:GetInt(), 20, 20, Color( 140, 140, 140, 255 ))
		draw.DrawText( "Free Cam", "ScoreboardText", 50, 230 + Movement:GetInt(), Color( 255, 255, 255, 255 ), 0 )
		
		if WallHack then
			draw.RoundedBox( 8, 20, 20 + Movement:GetInt(), 20, 20, Color( 0, 255, 0, 255 ))
		end
		if Aimbot then
			draw.RoundedBox( 8, 20, 50 + Movement:GetInt(), 20, 20, Color( 0, 255, 0, 255 ))
		end
		if Autoshoot then
			draw.RoundedBox( 8, 20, 80 + Movement:GetInt(), 20, 20, Color( 0, 255, 0, 255 ))
		end
		if Entdetect == 1 then
			draw.RoundedBox( 8, 20, 110 + Movement:GetInt(), 20, 20, Color( 255, 0, 0, 255 ))
		end
		if Entdetect == 2 then
			draw.RoundedBox( 8, 20, 110 + Movement:GetInt(), 20, 20, Color( 255, 128, 0, 255 ))
		end
		if Entdetect == 3 then
			draw.RoundedBox( 8, 20, 110 + Movement:GetInt(), 20, 20, Color( 0, 255, 0, 255 ))
		end
		if ChatSpam:GetString() != "false" then
			draw.RoundedBox( 8, 20, 140 + Movement:GetInt(), 20, 20, Color( 0, 255, 0, 255 ))
		end
		if WallGlow then
			draw.RoundedBox( 8, 20, 170 + Movement:GetInt(), 20, 20, Color( 0, 255, 0, 255 ))
		end
		if StatViewer == 1 then
			draw.RoundedBox( 8, 20, 200 + Movement:GetInt(), 20, 20, Color( 255, 0, 0, 255 ))
		end
		if StatViewer == 2 then
			draw.RoundedBox( 8, 20, 200 + Movement:GetInt(), 20, 20, Color( 0, 255, 0, 255 ))
		end
		if FreeCam then
			draw.RoundedBox( 8, 20, 230 + Movement:GetInt(), 20, 20, Color( 0, 255, 0, 255 ))
		end
		
		--HackLog
		surface.SetDrawColor(0,0,0)
		surface.DrawOutlinedRect(ScrW()-450, 19 + Movement:GetInt(), 440, 200)
		surface.SetDrawColor(0,0,0, 200)
		surface.DrawRect(ScrW()-450, 19 + Movement:GetInt(), 440, 200)
		for k,v in pairs(Hlog) do
			draw.DrawText(v, "ScoreboardText", ScrW()-440, 19 + Movement:GetInt() + ((k*20)-20), Color(255,255,255))
		end
	end
end

function drawFreeCam()
	local trace = LocalPlayer():GetEyeTrace()
	
	tr = util.TraceLine({
		start = LocalPlayer():GetPos(),
		endpos = LocalPlayer():GetPos() + Vector(0, 0, 400),
		ignoreworld = false
		}
	)
	
	renderTable = {
	["origin"] = FCV.Pos,
	["angles"] = FCV.Ang,
	["x"] = 0,
	["y"] = 0,
	["w"] = ScrW(),
	["h"] = ScrH(),
	["drawviewmodel"] = true
	}
	render.RenderView(renderTable)
end

hook.Add( "HUDPaint", "Wallhack", function()
	if TriggerBot and FreeCam then
		drawFreeCam()
	end
	dispHax()
	local Aim = LocalPlayer():GetEyeTrace().Entity
	if TriggerBot and StatViewer == 1 and Aim:IsPlayer() then
		if (LocalPlayer():EyePos():Distance( Aim:GetPos() ) < 256) then
			PaintStats1(Aim)
		end
	end
	if TriggerBot and StatViewer == 2 and Aim:IsPlayer() then
		if (LocalPlayer():EyePos():Distance( Aim:GetPos() ) < 256) then
			PaintStats2(Aim)
		end
	end
	if TriggerBot and StatViewer == 1 and WallHack then
		for k,v in pairs ( player.GetAll() ) do
			PaintStats1(v)
		end
	end
	if TriggerBot and StatViewer == 2 and WallHack then
		for k,v in pairs ( player.GetAll() ) do
			PaintStats2(v)
		end
	end
	if TriggerBot and WallHack then
		for k,v in pairs ( player.GetAll() ) do
	 
			local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
			local Name = ""
	 
			if v == LocalPlayer() then Name = "" else Name = v:Name() end
	 
			draw.DrawText( Name, "ScoreboardText", Position.x, Position.y, team.GetColor(v:Team()), 1 )
	 
		end
	end
	if TriggerBot == 0 or WallHack == 0 then
		hook.Remove("PreDrawHalos", "AddHalos")
	end
	if TriggerBot and HitWarner then
		for k,v in pairs(player.GetAll() ) do
			if v:isHitman() then
				if v:getHitTarget() == LocalPlayer() then
					draw.DrawText( v:Name().." has a hit on you", "ScoreboardText3", ScrW()-15, 10, Color( 200, 0, 0, 255 ), 2 )
				end
			end
		end
	end
	if TriggerBot and (Entdetect >= 1) then
		hook.Remove("PreDrawHalos", "AddHalos")
		for i,v in ipairs(EntityList) do
				if (v.Type == Entdetect) or Entdetect == 3 then
					if not (v.Ent == nil) then
						local EntList = ents.FindByClass(v.Ent)
						for k,m in ipairs(EntList) do
							local Position = ( m:GetPos() ):ToScreen()
							draw.DrawText( v.Name, "ScoreboardText", Position.x, Position.y, Color( 0, 255, 0, 255 ), 1 )
						end
					end
				end
			end
		if WallGlow then
			hook.Add( "PreDrawHalos", "AddHalos", function()
				for i,v in ipairs(EntityList) do
					if (v.Type == Entdetect) or Entdetect == 3 then
						if not (v.Ent == nil) then
							halo.Add( ents.FindByClass(v.Ent), Color( 255, 0, 0 ), 5, 5, 1 , true, true)
						end
					end
				end
			end )
		else
		end
	end
end )
function ChatCommands(  ply,  strText,  bTeamOnly,  bPlayerIsDead )
	if string.sub(strText, 1,7) == "/unlock" then
		lockEnt = 0
	end
end
hook.Remove("PreDrawHalos", "AddHalos")
hook.Add( "PreDrawHalos", "AddHalos", function()
	if WallGlow and TriggerBot then
		local living = table.Copy(player.GetHumans())
		for k,v in pairs(living) do if not v:Alive() then table.remove(living, k) end end
		halo.Add( living, Color( 0, 255, 0 ), 5, 5, 1 , true, true)
	end	
end)
function PrinterDerma()
	local Target = LocalPlayer():GetEyeTrace().Entity
	if not Target:IsValid() then return end
	local Name = Target:GetClass()
	local DermaPanel = vgui.Create( "DFrame" )
	DermaPanel:SetPos( ScrW()/2 - 250/2,ScrH()/2 - 50 )
	DermaPanel:SetSize( 250, 100 )
	DermaPanel:SetTitle( "Add Printer to list" )
	DermaPanel:SetVisible( true )
	DermaPanel:SetDraggable( true )
	DermaPanel:ShowCloseButton( true )
	DermaPanel:MakePopup()
	
	local DermaText = vgui.Create( "DTextEntry", DermaPanel )
	DermaText:SetPos( 25,35 )
	DermaText:SetTall( 20 )
	DermaText:SetWide( 200 )
	DermaText:SetText( Name )
	DermaText:SetEnterAllowed( true )
	DermaText.OnEnter = function()
		file.Append("haxmp.txt", DermaText:GetValue().."|"..Name.."#")
	end
	
	local DermaButton = vgui.Create( "DButton" )
	DermaButton:SetParent( DermaPanel ) -- Set parent to our "DermaPanel"
	DermaButton:SetText( "Add Printer" )
	DermaButton:SetPos( 25, 60 )
	DermaButton:SetSize( 200, 20 )
	DermaButton.DoClick = function ()
		file.Append("haxmp.txt", "#"..DermaText:GetValue().."|"..Name)
	end
end

hook.Add("OnPlayerChat","Chat", ChatCommands)