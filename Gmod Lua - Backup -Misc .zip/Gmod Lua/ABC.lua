



local cmdStr = "ABCUnlocker"
CreateClientConVar(cmdStr.."_Unlocker", 0, true, false)

Aqua = Color(0,255,255,255);
ForestGreen = Color(34,139,34,255);
Ivory = Color(255,255,240,255);
Navy = Color(0,0,128,255);

chat.AddText( ForestGreen, "{ABC Unlocker} ", Navy, "Thank you for choosing ABC Unlocker!")
chat.AddText( ForestGreen, "{ABC Unlocker} ", Navy, "Made by Yeehawlerz101!")
chat.AddText( ForestGreen, "{ABC Unlocker} ", Navy, "Please fav and thumb up on the workshop!")
chat.AddText( ForestGreen, "{ABC Unlocker} ", Navy, "Type: ABCUnlocker 1 to start unlocking achivements.")
chat.AddText( ForestGreen, "{ABC Unlocker} ", Navy, "To check if the lua is running check the console")
chat.AddText( ForestGreen, "{ABC Unlocker} ", Navy, "To stop/unload the lua type ABCUnlocker 0 in console")



MsgC( Aqua,[[
         :::     :::::::::   ::::::::         :::    ::: ::::    ::: :::        ::::::::   ::::::::  :::    ::: :::::::::: ::::::::: 
       :+: :+:   :+:    :+: :+:    :+:        :+:    :+: :+:+:   :+: :+:       :+:    :+: :+:    :+: :+:   :+:  :+:        :+:    :+: 
     +:+   +:+  +:+    +:+ +:+               +:+    +:+ :+:+:+  +:+ +:+       +:+    +:+ +:+        +:+  +:+   +:+        +:+    +:+  
   +#++:++#++: +#++:++#+  +#+               +#+    +:+ +#+ +:+ +#+ +#+       +#+    +:+ +#+        +#++:++    +#++:++#   +#++:++#:    
  +#+     +#+ +#+    +#+ +#+               +#+    +#+ +#+  +#+#+# +#+       +#+    +#+ +#+        +#+  +#+   +#+        +#+    +#+    
 #+#     #+# #+#    #+# #+#    #+#        #+#    #+# #+#   #+#+# #+#       #+#    #+# #+#    #+# #+#   #+#  #+#        #+#    #+#     
###     ### #########   ########          ########  ###    #### ########## ########   ########  ###    ### ########## ###    ###  
]])



local function Achivementediting()
    if GetConVarNumber(cmdStr.."_Unlocker") == 1 then
        	achievements.BalloonPopped() --1st tick
        	achievements.EatBall() 
        	achievements.IncBaddies() 
        	achievements.IncBystander() 
        	achievements.IncGoodies() 
        	achievements.Remover() 
        	achievements.SpawnedNPC() 
        	achievements.SpawnedProp() 
        	achievements.SpawnedRagdoll() 
        	achievements.SpawnMenuOpen()

        	
end
end


local function Achivementeditingalert()
    if GetConVarNumber(cmdStr.."_Unlocker") == 1 then
    	MsgC( Ivory,[[
Currently Running ABC Unlocker
]])
end
end

timer.Create("Unlocker", .5, 0, Achivementediting)

timer.Create("UnlockerAlert", 15, 0, Achivementeditingalert)


--Derma Menu








