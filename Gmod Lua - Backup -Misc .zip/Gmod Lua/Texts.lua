 
-- Colors --
-- Desc: Just writing colors so instead of numbers I can just use terms like red or blue later on. --
--Color codes are from here "http://rapidtables.com/web/color/RGB_Color.htm"
Black = Color(0,0,0,255);
Maroon = Color(128,0,0,255);
DarkRed = Color(139,0,0,255);
Brown = Color(165,42,42,255);
FireBrick = Color(178,34,34,255);
Crimson = Color(220,20,60,255);
Red = Color(255,0,0,255);
Tomato = Color(255,99,71,255);
Coral = Color(255,127,80,255);
IndianRed = Color(205,92,92,255);
LightCoral = Color(240,128,128,255);
DarkSalmon = Color(233,150,122,255);
Salmon = Color(250,128,114,255);
LightSalmon = Color(255,160,122,255);
OrangeRed = Color(255,69,0,255);
DarkOrange = Color(255,140,0,255);
Orange = Color(255,165,0,255);
Gold = Color(255,215,0,255);
DarkGoldenRod = Color(184,134,11,255);
GoldenRod = Color(218,165,32,255);
PaleGoldenRod = Color(238,232,170,255);
DarkKhaki = Color(189,183,107,255);
Khaki = Color(240,230,140,255);
Olive = Color(128,128,0,255);
Yellow = Color(255,255,0,255);
YellowGreen = Color(154,205,50,255);
DarkOliveGreen = Color(85,107,47,255);
OliveDrab = Color(107,142,35,255);
LawnGreen = Color(124,252,0,255);
ChartReuse = Color(127,255,0,255);
GreenYellow = Color(173,255,47,255);
DarkGreen = Color(0,100,0,255);
Green = Color(0,128,0,255);
ForestGreen = Color(34,139,34,255);
Lime = Color(0,255,0,255);
LimeGreen = Color(50,205,50,255);
LightGreen = Color(144,238,144,255);
PaleGreen = Color(152,251,152,255);
DarkSeaGreen = Color(143,188,143,255);
MediumSpringGreen = Color(0,250,154,255);
SpringGreen = Color(0,255,127,255);
SeaGreen = Color(46,139,87,255);
MediumAquaMarine = Color(102,205,170,255);
MediumSeaGreen = Color(60,179,113,255);
LightSeaGreen = Color(32,178,170,255);
DarkSlateGray = Color(47,79,79,255);
Teal = Color(0,128,128,255);
DarkCyan = Color(0,139,139,255);
Aqua = Color(0,255,255,255);
Cyan = Color(0,255,255,255);
LightCyan = Color(224,255,255,255);
DarkTurquoise = Color(0,206,209,255);
Turquoise = Color(64,224,208,255);
MediumTurquoise = Color(72,209,204,255);
PaleTurquoise = Color(175,238,238,255);
AquaMarine = Color(127,255,212,255);
PowderBlue = Color(176,224,230,255);
CadetBlue = Color(95,158,160,255);
SteelBlue = Color(70,130,180,255);
CornFlowerBlue = Color(100,149,237,255);
DeepSkyBlue = Color(0,191,255,255);
DodgerBlue = Color(30,144,255,255);
LightBlue = Color(173,216,230,255);
SkyBlue = Color(135,206,235,255);
LightSkyBlue = Color(135,206,250,255);
MidnightBlue = Color(25,25,112,255);
Navy = Color(0,0,128,255);
DarkBlue = Color(0,0,139,255);
MediumBlue = Color(0,0,205,255);
Blue = Color(0,0,255,255);
RoyalBlue = Color(65,105,225,255);
Blueviolet = Color(138,43,226,255);
Indigo = Color(75,0,130,255);
DarkSlateBlue = Color(72,61,139,255);
SlateBlue = Color(106,90,205,255);
MediumSlateBlue = Color(123,104,238,255);
MediumPurple = Color(147,112,219,255);
DarkMagenta = Color(139,0,139,255);
DarkViolet = Color(148,0,211,255);
DarkOrchid = Color(153,50,204,255);
MediumOrchid = Color(186,85,211,255);
Purple = Color(128,0,128,255);
Thistle = Color(216,191,216,255);
Plum = Color(221,160,221,255);
Violet = Color(238,130,238,255);
Magenta = Color(255,0,255,255);
Orchid = Color(218,112,214,255);
MediumVioletRed = Color(199,21,133,255);
PaleVioletRed = Color(219,112,147,255);
DeepPink = Color(255,20,147,255);
HotPink = Color(255,105,180,255);
LightPink = Color(255,182,193,255);
Pink = Color(255,192,203,255);
Antiquewhite = Color(250,235,215,255);
Beige = Color(245,245,220,255);
Bisque = Color(255,228,196,255);
BlanchedAlmond = Color(255,235,205,255);
Wheat = Color(245,222,179,255);
CornSilk = Color(255,248,220,255);
LemonChiffon = Color(255,250,205,255);
LightGoldenRodYellow = Color(250,250,210,255);
LightYellow = Color(255,255,224,255);
SaddleBrown = Color(139,69,19,255);
Sienna = Color(160,82,45,255);
Chocolate = Color(210,105,30,255);
Peru = Color(205,133,63,255);
SandyBrown = Color(244,164,96,255);
BurlyWood = Color(222,184,135,255);
Tan = Color(210,180,140,255);
RosyBrown = Color(188,143,143,255);
Moccasin = Color(255,228,181,255);
NavajoWhite = Color(255,222,173,255);
PeachPuff = Color(255,218,185,255);
MistyRose = Color(255,228,225,255);
LavenderBlush = Color(255,240,245,255);
Linen = Color(255,165,0,255,255);
OldLace = Color(255,165,0,255);
PapayaWhip = Color(255,239,213,255);
SeaShell = Color(255,245,238,255);
MintCream = Color(245,255,250,255);
SlateGray = Color(112,128,144,255);
LightSlateGray = Color(176,196,222,255);
LightSteelBlue = Color(119,136,153,255);
Lavender = Color(230,230,250,255);
FloralWhite = Color(255,250,240,255);
AliceBlue = Color(240,248,255,255);
GhostWhite = Color(248,248,255,255);
Honeydew = Color(240,255,240,255);
Ivory = Color(255,255,240,255);
Azure = Color(255,250,250,255);
Snow = Color(255,250,250,255);
DimGray = Color(255,165,0,255);
Gray = Color(128,128,128,255);
DarkGray = Color(169,169,169,255);
Silver = Color(192,192,192,255);
LightGray = Color(211,211,211,255);
Gainsboro = Color(220,220,220,255);
WhiteSmoke = Color(245,245,245,255);








 MsgC( DarkGoldenRod,[[
 _______________________ _______ _______            _______ _______ _       
(  ____ \__   __(  ___  |  ____ (  ____ \  |\     /(  ___  |  ____ \ \    /\
| (    \/  ) (  | (   ) | (    \/ (    \/  | )   ( | (   ) | (    \/  \  / /
| (_____   | |  | (___) | (__   | (__      | (___) | (___) | |     |  (_/ / 
(_____  )  | |  |  ___  |  __)  |  __)     |  ___  |  ___  | |     |   _ (  
      ) |  | |  | (   ) | (     | (        | (   ) | (   ) | |     |  ( \ \ 
/\____) |  | |  | )   ( | )     | )        | )   ( | )   ( | (____/\  /  \ \
\_______)  )_(  |/     \|/      |/         |/     \|/     \(_______/_/    \/
]])




MsgC( DarkGoldenRod,[[ 
 _______ _______ ______  _______    ______                 
(       |  ___  |  __  \(  ____ \  (  ___ \|\     /|       
| () () | (   ) | (  \  ) (    \/  | (   ) | \   / )   _   
| || || | (___) | |   ) | (__      | (__/ / \ (_) /   (_)  
| |(_)| |  ___  | |   | |  __)     |  __ (   \   /         
| |   | | (   ) | |   ) | (        | (  \ \   ) (      _   
| )   ( | )   ( | (__/  ) (____/\  | )___) )  | |     (_)  
|/     \|/_____\(______/(_______/__|/_\___/   \_/          


|\     /(  ____ (  ____ \     / ) ___  \                   
( \   / ) (    \/ (    \/    / /\/   \  \                  
 \ (_) /| (__   | (__       / /    ___) /                  
  \   / |  __)  |  __)     ( (    (___ (                   
   ) (  | (     | (         \ \       ) \                  
   | |  | (____/\ (____/\    \ \/\___/  /                  
   \_/  (_______(_______/     \_)______/  

  /__\                                                     
 ( \/ )                                                    
  \  /                                                     
  /  \/\                                                   
 / /\  /                                                   
(  \/  \                                                   
 \___/\/__________       _______ _______                   
(       )__   __/ \    /(  ___  |  ____ )\     /|          
| () () |  ) (  |  \  / / (   ) | (    )( \   / )          
| || || |  | |  |  (_/ /| |   | | (____)|\ (_) /           
| |(_)| |  | |  |   _ ( | |   | |  _____) \   /            
| |   | |  | |  |  ( \ \| |   | | (        ) (             
| )   ( |__) (__|  /  \ \ (___) | )        | |             
|/     \\_______/_/    \(_______)/         \_/             
                                                           

]])
MsgC( LightGoldenRodYellow,[[

         _______ _______    _______           
|\     /(  ____ (  ____ )  (  __   ) |\     /|
| )   ( | (    \/ (    )|  | (  )  | ( \   / )
| |   | | (__   | (____)|  | | /   |  \ (_) / 
( (   ) )  __)  |     __)  | (/ /) |   ) _ (  
 \ \_/ /| (     | (\ (     |   / | |  / ( ) \ 
  \   / | (____/\ ) \ \__  |  (__) |_( /   \ )
   \_/  (_______//   \__/  (_______|_)/     \|
                                              

]])




local ply = LocalPlayer()

chat.AddText( Aqua, "{CT-Hud} ", Crimson, "Loaded CT-Hud!")
chat.AddText( Aqua, "{CT-Hud} ", Crimson, "Exclusive to Mirror Gaming!")
chat.AddText( Aqua, "{CT-Hud} ", Crimson, "v0.01.Alpha")
chat.AddText( Aqua, "{CT-Hud} ", Crimson, "To open the menu, type +CTHud in console!")
chat.AddText( Aqua, "{CT-Hud} ", Crimson, "Please vote up on the forum post")
chat.AddText( Aqua, "{CT-Hud} ", Crimson, "http://adf.ly/1e66gf")


--DONE dO NOT TOUCH-- 
surface.CreateFont("Menu_Title",{font = "coolvetica", size = 14})

hook.Add( "HUDPaint", "defib_esp", function()
for k,v in pairs (ents.FindByClass("bn_defib")) do 
  local defibs = ( v:GetPos() + Vector( 0,0,10 ) ):ToScreen()
      draw.DrawText( "Medic", "Menu_Title", defibs.x, defibs.y, Color( 255, 40, 0, 255 ), 1 )
      halo.Add({v}, Color(0, 255, 0, 255), 2, 1, 5, true, true)
  end
end)


hook.Add( "HUDPaint", "defib_esp", function()
for k,v in pairs (ents.FindByClass("stim_kit")) do 
      halo.Add({v}, Color(0, 255, 0, 255), 2, 1, 5, true, true)
  end
end)

//hook.Add( "HUDPaint", "Medic_esp", function()
//for k,v in pairs (ents.FindByModel("models/player/327th/c327tht.mdl")) do 
//      halo.Add({v}, Color(230, 0, 0, 255), 2, 1, 5, true, true)
//  end
//end)
//



hook.Add( "HUDPaint", "Fleet_esp", function()
for k,v in pairs (ents.FindByModel("models/player/bridgestaff/cgibridgestaff.mdl")) do 
      halo.Add({v}, Color(110, 110, 110, 255), 2, 1, 5, true, true)
  end
end)



hook.Add( "HUDPaint", "Yoda_esp", function()
for k,v in pairs (ents.FindByModel("models/tfa/comm/gg/pm_sw_yodanojig.mdl")) do 
      halo.Add({v}, Color(0, 110, 0, 210), 2, 1, 5, true, true)
  end
end)





hook.Add( "HUDPaint", "Medic2_esp", function()
for k,v in pairs(player.GetAll()) do
      for k,v2 in pairs(v:GetWeapons()) do
        if v2:GetClass() == "bacta_kit" && v != ply then
          halo.Add({v},  Color(110, 210, 0, 210), 1, 1, 3, true, true)
        end
      end
    end
end)




//hook.Add("HUDPaint", "GlowESP", function()
//  for k,v in pairs(player.GetAll()) do
//      if (ents.FindByModel("models/player/ewq/starwars/esharp.mdl")) then
//      halo.Add({v}, team.GetColor(v:Team()), 1, 1, 3, true, true)
//      if (ents.FindByModel("models/tfa/comm/gg/pm_sw_aayala.mdl")) then
//      halo.Add({v}, team.GetColor(v:Team()), 1, 1, 3, true, true)
//      if (ents.FindByModel("models/player/327th/c327tht.mdl")) then
//        halo.Add({v}, team.GetColor(v:Team()), 1, 1, 3, true, true) 
//      end
//      end
//    end
//  end
//end)








