        print("ESP Loaded")
LocalPlayer():ChatPrint("BoxEsp Loaded")
LocalPlayer():ChatPrint("Glow Loaded")
LocalPlayer():ChatPrint("Made By: Yeehawlerz101")
LocalPlayer():ChatPrint("Add: Yeehawlerz101 on steam")
LocalPlayer():ChatPrint("Kik: Yeehawlerz101")
LocalPlayer():ChatPrint("Enjoy This!")

local function ESPCheck(v)
	if v:Alive() == true && v:Health() ~= 0 && v:Health() >= 0 && v ~= LocalPlayer() && LocalPlayer():Alive() then
		return true
	else
		return false
	end
end

hook.Add("PreDrawHalos", "", function()
	for k,v in next, player.GetAll() do
		if(v:Health() < 1) then continue; end
		if(v:IsDormant()) then continue; end
		if(v:Team() == LocalPlayer():Team()) then
		
		
		
		
		
			halo.Add({v}, Color(255,13,25,255), 1, 2, 1, true, true);
		else
			halo.Add({v}, Color(255,13,25,255), 1, 2, 1, true, true);
		
		
		
		
		end
	end
end);

hook.Add( "HUDPaint", "Wallhack", function()
 
	for k,v in pairs ( player.GetAll() ) do
 
		local Position = ( v:GetPos() + Vector( 0,0,120 ) ):ToScreen()
		local Name = ""
 
		if v == LocalPlayer() then Name = "" else Name = v:Name() end
					
					
		draw.DrawText( Name, "Trebuchet16", Position.x, Position.y, Color( 255, 13, 25, 250 ), 1 )
	end
 
end )

 hook.Add( "HUDPaint", "Distance", function()
 
	for k,v in pairs ( player.GetAll() ) do
 
		local Position = ( v:GetPos() + Vector( 0,0,-30 ) ):ToScreen()
					local distance = v:GetPos():Distance(LocalPlayer():GetPos())
						local distance = math.Round(distance).." m"

		
		draw.DrawText( distance, "Trebuchet16", Position.x, Position.y, Color( 255, 255, 255, 250 ), 1 )
	end
 
end )

local shouldDraw = true

local hzCross = CreateClientConVar("HZ_Crosshair","0",false)
 
function Crosshair1()
surface.SetDrawColor(team.GetColor(LocalPlayer():Team()))
surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2)
surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 11)
end
hook.Add("HUDPaint","CustomCross",Crosshair1)

local function coordinates( ent )
local min, max = ent:OBBMins(), ent:OBBMaxs()
local corners = {
        Vector( min.x, min.y, min.z ),
        Vector( min.x, min.y, max.z ),
        Vector( min.x, max.y, min.z ),
        Vector( min.x, max.y, max.z ),
        Vector( max.x, min.y, min.z ),
        Vector( max.x, min.y, max.z ),
        Vector( max.x, max.y, min.z ),
        Vector( max.x, max.y, max.z )
}
 
local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
for _, corner in pairs( corners ) do
        local onScreen = ent:LocalToWorld( corner ):ToScreen()
        minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
        maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end
 
return minX, minY, maxX, maxY
end
hook.Add("HUDPaint", "Example", function()
for k,v in pairs(player.GetAll()) do
        local x1,y1,x2,y2 = coordinates(v)
         print(tostring(team.GetColor(v:Team())))
         surface.SetDrawColor(color_white)
 
 
        surface.DrawLine( x1, y1, math.min( x1 + 5, x2 ), y1 )
        surface.DrawLine( x1, y1, x1, math.min( y1 + 5, y2 ) )
 
 
        surface.DrawLine( x2, y1, math.max( x2 - 5, x1 ), y1 )
        surface.DrawLine( x2, y1, x2, math.min( y1 + 5, y2 ) )
 
 
        surface.DrawLine( x1, y2, math.min( x1 + 5, x2 ), y2 )
        surface.DrawLine( x1, y2, x1, math.max( y2 - 5, y1 ) )
 
 
        surface.DrawLine( x2, y2, math.max( x2 - 5, x1 ), y2 )
        surface.DrawLine( x2, y2, x2, math.max( y2 - 5, y1 ) )
end
end)

local struc = {}
struc.pos = {}
struc.pos[1] = 100 -- x pos
struc.pos[2] = 200 -- y pos
struc.color = Color(255,0,0,255) -- Red
struc.text = "Hello World" -- Text
struc.font = "DefaultFixed" -- Font
struc.xalign = TEXT_ALIGN_CENTER -- Horizontal Alignment
struc.yalign = TEXT_ALIGN_CENTER -- Vertical Alignment
draw.Text( struc )