


--Hey this is Yee and Miko! Thank you for donloading our script and trying it out! all of this was possible from seeing others peoples code and modifiying it.
-- Credit will be served where it is due (found at bottom of this line of text) please enjoy and share! eventually i will make a tut on how i made this :D

--Anozira Scripts (Xeaxos), Cancerware (N/A [found on the internet]), gmod_isis_cheat_aimbot_esp_etc (Nomical + Fr1kin), SMEG_Hack (mmmaaalll1), and lastly snixzz3 (0xymoron)
--Why we used their scripts:


--Anozira Scripts, Basic Derma since it was simply to change some colors and location of things.
--cancerware, options tables and layout of options for the user.
--gmod_isis_cheat_aimbot_esp_etc, More derma stuff we liked. :D
--SMEG_Hack, all of the bones and the skeleton figure to select bone aim areas (very nice)
--Snixzz3, we saw how you used a http function to call your codeing and we honestly really loved that :D kudos to you man!

-- Colors --
-- Desc: Just writing colors so instead of numbers I can just use terms like red or blue later on. --
--Color codes are from here "http://rapidtables.com/web/color/RGB_Color.htm"
Black = Color(0,0,0,255);
Maroon = Color(128,0,0,255);
DarkRed = Color(139,0,0,255);
Brown = Color(165,42,42,255);
FireBrick = Color(178,34,34,255);
Crimson = Color(220,20,60,255);
Red = Color(255,0,0,255);
Tomato = Color(255,99,71,255);
Coral = Color(255,127,80,255);
IndianRed = Color(205,92,92,255);
LightCoral = Color(240,128,128,255);
DarkSalmon = Color(233,150,122,255);
Salmon = Color(250,128,114,255);
LightSalmon = Color(255,160,122,255);
OrangeRed = Color(255,69,0,255);
DarkOrange = Color(255,140,0,255);
Orange = Color(255,165,0,255);
Gold = Color(255,215,0,255);
DarkGoldenRod = Color(184,134,11,255);
GoldenRod = Color(218,165,32,255);
PaleGoldenRod = Color(238,232,170,255);
DarkKhaki = Color(189,183,107,255);
Khaki = Color(240,230,140,255);
Olive = Color(128,128,0,255);
Yellow = Color(255,255,0,255);
YellowGreen = Color(154,205,50,255);
DarkOliveGreen = Color(85,107,47,255);
OliveDrab = Color(107,142,35,255);
LawnGreen = Color(124,252,0,255);
ChartReuse = Color(127,255,0,255);
GreenYellow = Color(173,255,47,255);
DarkGreen = Color(0,100,0,255);
Green = Color(0,128,0,255);
ForestGreen = Color(34,139,34,255);
Lime = Color(0,255,0,255);
LimeGreen = Color(50,205,50,255);
LightGreen = Color(144,238,144,255);
PaleGreen = Color(152,251,152,255);
DarkSeaGreen = Color(143,188,143,255);
MediumSpringGreen = Color(0,250,154,255);
SpringGreen = Color(0,255,127,255);
SeaGreen = Color(46,139,87,255);
MediumAquaMarine = Color(102,205,170,255);
MediumSeaGreen = Color(60,179,113,255);
LightSeaGreen = Color(32,178,170,255);
DarkSlateGray = Color(47,79,79,255);
Teal = Color(0,128,128,255);
DarkCyan = Color(0,139,139,255);
Aqua = Color(0,255,255,255);
Cyan = Color(0,255,255,255);
LightCyan = Color(224,255,255,255);
DarkTurquoise = Color(0,206,209,255);
Turquoise = Color(64,224,208,255);
MediumTurquoise = Color(72,209,204,255);
PaleTurquoise = Color(175,238,238,255);
AquaMarine = Color(127,255,212,255);
PowderBlue = Color(176,224,230,255);
CadetBlue = Color(95,158,160,255);
SteelBlue = Color(70,130,180,255);
CornFlowerBlue = Color(100,149,237,255);
DeepSkyBlue = Color(0,191,255,255);
DodgerBlue = Color(30,144,255,255);
LightBlue = Color(173,216,230,255);
SkyBlue = Color(135,206,235,255);
LightSkyBlue = Color(135,206,250,255);
MidnightBlue = Color(25,25,112,255);
Navy = Color(0,0,128,255);
DarkBlue = Color(0,0,139,255);
MediumBlue = Color(0,0,205,255);
Blue = Color(0,0,255,255);
RoyalBlue = Color(65,105,225,255);
Blueviolet = Color(138,43,226,255);
Indigo = Color(75,0,130,255);
DarkSlateBlue = Color(72,61,139,255);
SlateBlue = Color(106,90,205,255);
MediumSlateBlue = Color(123,104,238,255);
MediumPurple = Color(147,112,219,255);
DarkMagenta = Color(139,0,139,255);
DarkViolet = Color(148,0,211,255);
DarkOrchid = Color(153,50,204,255);
MediumOrchid = Color(186,85,211,255);
Purple = Color(128,0,128,255);
Thistle = Color(216,191,216,255);
Plum = Color(221,160,221,255);
Violet = Color(238,130,238,255);
Magenta = Color(255,0,255,255);
Orchid = Color(218,112,214,255);
MediumVioletRed = Color(199,21,133,255);
PaleVioletRed = Color(219,112,147,255);
DeepPink = Color(255,20,147,255);
HotPink = Color(255,105,180,255);
LightPink = Color(255,182,193,255);
Pink = Color(255,192,203,255);
Antiquewhite = Color(250,235,215,255);
Beige = Color(245,245,220,255);
Bisque = Color(255,228,196,255);
BlanchedAlmond = Color(255,235,205,255);
Wheat = Color(245,222,179,255);
CornSilk = Color(255,248,220,255);
LemonChiffon = Color(255,250,205,255);
LightGoldenRodYellow = Color(250,250,210,255);
LightYellow = Color(255,255,224,255);
SaddleBrown = Color(139,69,19,255);
Sienna = Color(160,82,45,255);
Chocolate = Color(210,105,30,255);
Peru = Color(205,133,63,255);
SandyBrown = Color(244,164,96,255);
BurlyWood = Color(222,184,135,255);
Tan = Color(210,180,140,255);
RosyBrown = Color(188,143,143,255);
Moccasin = Color(255,228,181,255);
NavajoWhite = Color(255,222,173,255);
PeachPuff = Color(255,218,185,255);
MistyRose = Color(255,228,225,255);
LavenderBlush = Color(255,240,245,255);
Linen = Color(255,165,0,255,255);
OldLace = Color(255,165,0,255);
PapayaWhip = Color(255,239,213,255);
SeaShell = Color(255,245,238,255);
MintCream = Color(245,255,250,255);
SlateGray = Color(112,128,144,255);
LightSlateGray = Color(176,196,222,255);
LightSteelBlue = Color(119,136,153,255);
Lavender = Color(230,230,250,255);
FloralWhite = Color(255,250,240,255);
AliceBlue = Color(240,248,255,255);
GhostWhite = Color(248,248,255,255);
Honeydew = Color(240,255,240,255);
Ivory = Color(255,255,240,255);
Azure = Color(255,250,250,255);
Snow = Color(255,250,250,255);
DimGray = Color(255,165,0,255);
Gray = Color(128,128,128,255);
DarkGray = Color(169,169,169,255);
Silver = Color(192,192,192,255);
LightGray = Color(211,211,211,255);
Gainsboro = Color(220,220,220,255);
WhiteSmoke = Color(245,245,245,255);

-- Boot Message --
-- Desc: So you know what you are running and version. --
 MsgC( DarkGoldenRod,[[
 _______________________ _______ _______            _______ _______ _       
(  ____ \__   __(  ___  |  ____ (  ____ \  |\     /(  ___  |  ____ \ \    /\
| (    \/  ) (  | (   ) | (    \/ (    \/  | )   ( | (   ) | (    \/  \  / /
| (_____   | |  | (___) | (__   | (__      | (___) | (___) | |     |  (_/ / 
(_____  )  | |  |  ___  |  __)  |  __)     |  ___  |  ___  | |     |   _ (  
      ) |  | |  | (   ) | (     | (        | (   ) | (   ) | |     |  ( \ \ 
/\____) |  | |  | )   ( | )     | )        | )   ( | )   ( | (____/\  /  \ \
\_______)  )_(  |/     \|/      |/         |/     \|/     \(_______/_/    \/
]])




MsgC( Gold,[[ 
 _______ _______ ______  _______    ______                 
(       |  ___  |  __  \(  ____ \  (  ___ \|\     /|       
| () () | (   ) | (  \  ) (    \/  | (   ) | \   / )   _   
| || || | (___) | |   ) | (__      | (__/ / \ (_) /   (_)  
| |(_)| |  ___  | |   | |  __)     |  __ (   \   /         
| |   | | (   ) | |   ) | (        | (  \ \   ) (      _   
| )   ( | )   ( | (__/  ) (____/\  | )___) )  | |     (_)  
|/     \|/_____\(______/(_______/__|/_\___/   \_/          
|\     /(  ____ (  ____ \     / ) ___  \                   
( \   / ) (    \/ (    \/    / /\/   \  \                  
 \ (_) /| (__   | (__       / /    ___) /                  
  \   / |  __)  |  __)     ( (    (___ (                   
   ) (  | (     | (         \ \       ) \                  
   | |  | (____/\ (____/\    \ \/\___/  /                  
   \_/  (_______(_______/     \_)______/                   
  /__\                                                     
 ( \/ )                                                    
  \  /                                                     
  /  \/\                                                   
 / /\  /                                                   
(  \/  \                                                   
 \___/\/__________       _______ _______                   
(       )__   __/ \    /(  ___  |  ____ )\     /|          
| () () |  ) (  |  \  / / (   ) | (    )( \   / )          
| || || |  | |  |  (_/ /| |   | | (____)|\ (_) /           
| |(_)| |  | |  |   _ ( | |   | |  _____) \   /            
| |   | |  | |  |  ( \ \| |   | | (        ) (             
| )   ( |__) (__|  /  \ \ (___) | )        | |             
|/     \\_______/_/    \(_______)/         \_/             
                                                           

]])
MsgC( Red,[[

         _______ _______    _______           
|\     /(  ____ (  ____ )  (  __   ) |\     /|
| )   ( | (    \/ (    )|  | (  )  | ( \   / )
| |   | | (__   | (____)|  | | /   |  \ (_) / 
( (   ) )  __)  |     __)  | (/ /) |   ) _ (  
 \ \_/ /| (     | (\ (     |   / | |  / ( ) \ 
  \   / | (____/\ ) \ \__  |  (__) |_( /   \ )
   \_/  (_______//   \__/  (_______|_)/     \|
                                              

]])

chat.AddText( Gold, "Staff Hack")
chat.AddText( Red, "Version: 0.X")
chat.AddText( Gray, "Made by Yee<3 & Mikopy")
chat.AddText( Gray, "Get updates from")
chat.AddText( Aqua, "https://goo.gl/1HZuRW")




--Bones --
-- Desc: We can draw bones and color them in case the admin is missing addons. --
local BONES = {
    { "ValveBiped.Bip01_Head1", "ValveBiped.Bip01_Neck1" },
    { "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_Pelvis" },
    { "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_L_UpperArm" },
    { "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_R_UpperArm" },
    { "ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_L_Forearm" },
    { "ValveBiped.Bip01_R_UpperArm", "ValveBiped.Bip01_R_Forearm" },
    { "ValveBiped.Bip01_R_Forearm", "ValveBiped.Bip01_R_Hand" },
    { "ValveBiped.Bip01_L_Forearm", "ValveBiped.Bip01_L_Hand" },
    { "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_L_Thigh" },
    { "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_R_Thigh" },
    { "ValveBiped.Bip01_L_Thigh", "ValveBiped.Bip01_L_Calf" },
    { "ValveBiped.Bip01_R_Thigh", "ValveBiped.Bip01_R_Calf" },
    { "ValveBiped.Bip01_R_Calf", "ValveBiped.Bip01_R_Foot" },
    { "ValveBiped.Bip01_L_Calf", "ValveBiped.Bip01_L_Foot" },
} 



-- Fonts --
-- Desc: Custom Fonts. --
	--ESP Name Fonts
surface.CreateFont("PlyNameESP_Clrd", { size = 15, weight = 800, antialias = true, font = "Marlett"})
surface.CreateFont("PlyNameESP_Black", { size = 17, weight = 800, antialias = true, font = "Marlett"})
	--ESP HP Fonts
surface.CreateFont("PlyHPESP_Clrd", { size = 15, weight = 800, antialias = true, font = "CloseCaption_BoldItalic"})
surface.CreateFont("PlyHPESP_Black", { size = 17, weight = 800, antialias = true, font = "CloseCaption_BoldItalic"})
--


SHackmessages = {}
SHackmessages[1] = "// Welcome to our server!"
SHackmessages[2] = "// I am ready to help!"
SHackmessages[3] = "// Please favourite our server. <3"
SHackmessages[4] = "// Please consider donating for exclusive benefits!"
SHackmessages[5] = "// Remember we are here to help!"
SHackmessages[6] = "// We are also human, we may have bad days but we will try to help!"
SHackmessages[7] = "// Whats your favourite type of music?"
SHackmessages[8] = "// You playing on this server motivates us to make our server better!"


local cmdStr = "SHack"

local function OOCchats()
    if GetConVarNumber(cmdStr.."_chat") == 1 then
        LocalPlayer():ConCommand("say "..table.Random(SHackmessages).." " )
end
end

timer.Create("chattimer", 50, 0, OOCchats)




hook.Add("HUDPaint", "GlowESP", function()
	for k,v in pairs(player.GetAll()) do
			if (GetConVarNumber(cmdStr.."_userGLOW") == 1) then
			halo.Add({v}, team.GetColor(v:Team()), 2, 1, 5, true, true)
		end
end
end)




--
	--General Player Info (HP & Name, will be adding Armor) 
--


hook.Add( "HUDPaint", "userESP", function()
	if (GetConVarNumber(cmdStr.."_userESP") == 1) then
	for k,v in pairs ( player.GetAll() ) do
			local plyPos = v:GetPos()
			local pos = ( plyPos + Vector( 0, 0, 90 )):ToScreen()
			local plyName = v:Nick()
			local plyHP = "Health: " .. v:Health()
			local ply = LocalPlayer()
			draw.SimpleTextOutlined( plyName, "PlyNameESP_Clrd", pos.x, pos.y, team.GetColor(v:Team()), 1, 1, 1, Color( 0, 0, 0 ) )
			draw.SimpleTextOutlined( plyName, "PlyNameESP_Black", pos.x, pos.y, Color( 0, 0, 0 ), 1, 1, 1, Color( 0, 0, 0 ) )
			draw.SimpleTextOutlined( plyHP, "PlyHPESP_Clrd", pos.x, pos.y + 15, Color( 10, 255, 10 ), 1, 1, 1, Color( 0, 0, 0 ) )
			draw.SimpleTextOutlined( plyHP, "PlyHPESP_Black", pos.x, pos.y + 15, Color( 0, 0, 0 ), 1, 1, 1, Color( 0, 0, 0 ) )
		end
	end
end)

--
	--Derma Menu starting Function
--

concommand.Add( "+SHMenu", function()

local DermaPanel = vgui.Create( "DFrame" )
DermaPanel:SetPos( 50,50 )
DermaPanel:SetSize( 750, 350 )
DermaPanel:SetTitle( "StaffHack" )
DermaPanel:SetVisible( true )
DermaPanel:SetDraggable( true )
DermaPanel:ShowCloseButton( true )
DermaPanel.Paint = function( self, w, h ) 
	draw.RoundedBox( 0, 0, 0, w, h, Color( 75, 75, 75, 150 ) ) 
end
DermaPanel:MakePopup()
 
HTMLTest = vgui.Create("HTML", DermaPanel)
HTMLTest:SetPos(460,30)
HTMLTest:SetSize(290, 320)
HTMLTest:OpenURL("https://goo.gl/1HZuRW")
 
 local PropertySheet = vgui.Create( "DPropertySheet" )
PropertySheet:SetParent( DermaPanel )
PropertySheet:SetPos( 0, 30 )
PropertySheet:SetSize( 460, 350 )
PropertySheet.Paint = function( self, w, h ) 
	draw.RoundedBox( 0, 0, 0, w, h, Color( 25, 25, 25, 150 ) ) 
end

local Aim = vgui.Create( "DFrame" )
Aim:SetPos( 50,50 )
Aim:SetSize( 450, 300 )
Aim:SetTitle( "" )
Aim:SetVisible( true )
Aim:SetDraggable( false )
Aim:ShowCloseButton( false )
Aim.Paint = function( self, w, h ) 
	draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 0 ) ) 
end
 
local ESP = vgui.Create( "DFrame" )
ESP:SetPos( 50,50 )
ESP:SetSize( 450, 300 )
ESP:SetTitle( "" )
ESP:SetVisible( true )
ESP:SetDraggable( true )
ESP:ShowCloseButton( false )
ESP.Paint = function( self, w, h ) 
	draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 0 ) ) 
end

local Misc = vgui.Create( "DFrame" )
Misc:SetPos( 50,50 )
Misc:SetSize( 450, 300 )
Misc:SetTitle( "" )
Misc:SetVisible( true )
Misc:SetDraggable( true )
Misc:ShowCloseButton( false )
Misc.Paint = function( self, w, h ) 
	draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 0 ) )  
end
  
PropertySheet:AddSheet( "Aim Hacks", Aim, "icon16/user.png", false, false, "Aimbot and Aimbot settings." )
PropertySheet:AddSheet( "ESP Hacks", ESP, "icon16/group.png", false, false, "ESP hacks and ESP settings." ) 
PropertySheet:AddSheet( "Misc Hacks", Misc, "icon16/help.png", false, false, "All misc hacks." ) 
PropertySheet:AddSheet( "HUD Hacks", HUD, "icon16/application.png", false, false, "Hacks for your HUD, like Watermarks and Admin detectors!" ) 
PropertySheet:AddSheet( "Prop Kill", PropKill, "icon16/brick.png", false, false, "Hacks for your HUD, like Watermarks and Admin detectors!" ) 
 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", TrialMod)
CheckBoxThing:SetPos( 10,25 )
CheckBoxThing:SetText( "User Esp" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_userESP" ) 
CheckBoxThing:SizeToContents() 
 
local CheckBoxThing = vgui.Create( "DCheckBoxLabel", TrialMod)
CheckBoxThing:SetPos( 10,50 )
CheckBoxThing:SetText( "Aimbot" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_userGLOW" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Mod)
CheckBoxThing:SetPos( 10,25 )
CheckBoxThing:SetText( "PlayerInfo" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_playerinfo" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Mod)
CheckBoxThing:SetPos( 10,50 )
CheckBoxThing:SetText( "3D BoxESP" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_3dboxesp" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", HeadMod)
CheckBoxThing:SetPos( 10,75 )
CheckBoxThing:SetText( "2D BoxESP" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_2dboxesp" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", TrialAdmin)
CheckBoxThing:SetPos( 10,100 )
CheckBoxThing:SetText( "Glow ESP" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_glowesp" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", SuperAdmin)
CheckBoxThing:SetPos( 10,125 )
CheckBoxThing:SetText( "Chams" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_chams" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Owner)
CheckBoxThing:SetPos( 10,150 )
CheckBoxThing:SetText( "Entity ESP" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_entityesp" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Owner)
CheckBoxThing:SetPos( 10,25 )
CheckBoxThing:SetText( "Namechanger" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_namechanger" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Owner)
CheckBoxThing:SetPos( 10,50 )
CheckBoxThing:SetText( "Crosshair" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_crosshair" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Owner)
CheckBoxThing:SetPos( 10,75 )
CheckBoxThing:SetText( "Flashlight Spam" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_flashlightspam" ) 
CheckBoxThing:SizeToContents() 

local DermaButton = vgui.Create( "DButton", DermaPanel )
DermaButton:SetText( "Click Here to See what Servers are Useing StaffHack" )
DermaButton:SetTextColor( Color( 255, 255, 255 ) )
DermaButton:SetPos( 75, 320 )
DermaButton:SetSize( 300, 25 )
DermaButton.DoClick = function ()
    gui.OpenURL( "www.com" )
end
DermaButton.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 175 ) ) 
end
end)