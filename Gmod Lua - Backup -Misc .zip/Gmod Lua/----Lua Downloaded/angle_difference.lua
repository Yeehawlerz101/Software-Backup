local function Angle(_p, _y, _r)
	return {x = _p, y = _y, r = _r};
end

view = Angle(89, 0, 0)
aim = Angle(-89, 0, 0)

local function DotProduct(ang1, ang2)
	return ang1.x * ang2.x + ang1.y * ang2.y;
end

local function AngDiff(view, aim, fov)
	local a, b = {}, {};
	a.x = math.sin(math.rad(view.x)) * math.cos(math.rad(view.y))
	a.y = math.sin(math.rad(view.x)) * math.sin(math.rad(view.y))
	a.z = math.cos(math.rad(view.x))
	
	b.x = math.sin(math.rad(aim.x)) * math.cos(math.rad(aim.y))
	b.y = math.sin(math.rad(aim.x)) * math.sin(math.rad(aim.y))
	b.z = math.cos(math.rad(aim.x))
	
	return math.deg(math.acos(DotProduct(a, b))) <= fov;
end

print(AngDiff(view, aim, 30))