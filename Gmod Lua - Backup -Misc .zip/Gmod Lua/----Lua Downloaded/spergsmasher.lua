//require("bsendpacket")
require("dickwrap")

surface.CreateFont("wireless gamer", {font = "Open Sans MS", size = 45})
surface.CreateFont("visual gamer", {font = "Open Sans MS", size = 15, weight = 600, outline = true})
local _R = debug.getregistry()
_R["__rbackup"] = _R["__rbackup"] and _R["__rbackup"] or table.Copy(_R)
local r = _R["__rbackup"]
local me = LocalPlayer()
ok = {}
ok.cvars = {}
ok.aaa = {}
ok.ys = GetConVarNumber("m_yaw")
ok.aat = nil
ok.aas = false
ok.atk = false
ok.ct = 0
ok.flt = 0
ok.fltm = 0
ok.er = 0
ok.eg = 0
ok.eb = 0
ok.fa = nil
ok.sp = nil
ok.ep = nil

function ok.Log(...)
	MsgC(Color(5, 130, 255), "[SpergSmasher] ", Color(255, 190, 5), ...)
	MsgN("")
end

ok.Log("Loading...")

function ok.CreateConsoleVar(name, default)
	local ret = CreateClientConVar(name, default)
	ok.cvars[name] = tostring(default)
	ok.Log("Created convar: ", Color(255, 120, 5), name, Color(255, 0, 0), " (default: " .. tostring(default) .. ", value: ", ret:GetString(), ")")
	return ret
end

ok.vars = {
	aimbot = {
		enabled = ok.CreateConsoleVar("ok_aimbot", 1),
		pointscale = ok.CreateConsoleVar("ok_aimbot_point", 0.5),
		autowall = ok.CreateConsoleVar("ok_aimbot_autowall", 0),
		silent = ok.CreateConsoleVar("ok_aimbot_silent", 1),
		nospread = ok.CreateConsoleVar("ok_aimbot_nospread", 1),
		bodyaim = ok.CreateConsoleVar("ok_aimbot_body", 0),
		static = ok.CreateConsoleVar("ok_aimbot_staticaa", 1),
		nextshot = ok.CreateConsoleVar("ok_aimbot_nextshot", 1),
		autoshoot = ok.CreateConsoleVar("ok_aimbot_autoshoot", 1),
		team = ok.CreateConsoleVar("ok_aimbot_ignoreteam", 1),
		friends = ok.CreateConsoleVar("ok_aimbot_ignorefriends", 0)
	},

	visuals = {
		enabled = ok.CreateConsoleVar("ok_esp", 1),
		name = ok.CreateConsoleVar("ok_esp_name", 1),
		box = ok.CreateConsoleVar("ok_esp_box", 1),
		health = ok.CreateConsoleVar("ok_esp_health", 1),
		rank = ok.CreateConsoleVar("ok_esp_rank", 1),
		team = ok.CreateConsoleVar("ok_esp_team", 1),
		chams = ok.CreateConsoleVar("ok_esp_chams", 1),
		aimpos = ok.CreateConsoleVar("ok_esp_aimpos", 1),
	},

	hvh = {
		antiaim = ok.CreateConsoleVar("ok_hvh_antiaim", 1),
		edge = ok.CreateConsoleVar("ok_hvh_aa_edge", 1),
		edgemet = ok.CreateConsoleVar("ok_hvh_aa_edge_met", "regular"),
		jitter = ok.CreateConsoleVar("ok_hvh_aa_jitter", 0),
		adaptive = ok.CreateConsoleVar("ok_hvh_aa_adaptive", 1),
		adapyaw = ok.CreateConsoleVar("ok_hvh_adap_yaw", 450),
		adapmax = ok.CreateConsoleVar("ok_hvh_adap_max", 15),
		adapspeed = ok.CreateConsoleVar("ok_hvh_adap_speed", 1),
		fakeangles = ok.CreateConsoleVar("ok_hvh_aa_fakeangles", 1),
		pitch = ok.CreateConsoleVar("ok_hvh_aa_pitch", -192),
		yaw = ok.CreateConsoleVar("ok_hvh_aa_yaw", -541),
		yawbase = ok.CreateConsoleVar("ok_hvh_aa_yawbase", 360),
		yawadd = ok.CreateConsoleVar("ok_hvh_aa_yawadd", 45),
		fakelag = ok.CreateConsoleVar("ok_hvh_fakelag", 0),
		flchoke = ok.CreateConsoleVar("ok_hvh_fl_choke", 12),
		flsend = ok.CreateConsoleVar("ok_hvh_fl_send", 5)
	},

	highjump = ok.CreateConsoleVar("ok_highjump", 0),
	thirdperson = ok.CreateConsoleVar("ok_thirdperson", 0)
}

ok.pitches = {
	["-90"] = {
		-1.05,
	},

	["90"] = {
		-5.00,
		1.05,
		-5.00,
		1.05,
	}
}

ok.cones = {}

function _R.Entity.FireBullets(ent, bul)
	if bul.Spread then
		ok.cones[me:GetActiveWeapon():GetClass()] = bul.Spread * -1
	end

	r.Entity.FireBullets(ent, bul)
end

function ok.GetCone(wep)
	local cone = 0
	if !wep then return nil end
	if wep.Cone then cone = wep.Cone end
	if wep.Primary and wep.Primary.Cone then cone = wep.Primary.Cone end
	if wep.Secondary and wep.Secondary.Cone then cone = wep.Secondary.Cone end
	if cone != 0 then return Vector(-cone, -cone, -cone) end
	return nil
end

function ok.Compensate(cmd, ang)
	local wep = me:GetActiveWeapon()
	if !IsValid(wep) then return ang end
	local cone = ok.GetCone(wep) or ok.cones[wep:GetClass()]
	if !cone then return ang end
	return ok.vars["aimbot"]["nospread"]:GetBool() and (dickwrap.Predict(cmd, ang:Forward(), cone):Angle() or ang) or ang
end

function ok.CheckVis(ent)
	local sp = me:GetShootPos()
	local ep = !ok.vars["aimbot"]["bodyaim"]:GetBool() and (ent:GetAttachment(ent:LookupAttachment("eyes") or ent:LookupAttachment("forward")).Pos) or ent:GetPos() + ent:OBBCenter()

	local tdata = {
		start = sp,
		endpos = ep,
		filter = {ent, me},
		mask = MASK_SHOT
	}

	local trace = util.TraceLine(tdata)
	return trace.Fraction == 1, sp, ep + ((ent:GetVelocity() * engine.TickInterval()) - (me:GetVelocity() * engine.TickInterval()))
end


function ok.CanWallbang(sp, ep, ent)
    local tdata = {
    	start = sp,
    	endpos = ep,
    	filter = {ent, me},
    	mask = 1577075107
    }

    local wall = util.TraceLine(tdata)
    tdata.start = ep 
    tdata.endpos = sp
    local wall2 = util.TraceLine(tdata)
    if 17.5 > (wall2.HitPos - wall.HitPos):Length2D() then
    	return true
    else
    	return false
    end
end


function ok.GetTarget()
	local vis
	ok.sp, ok.ep, ok.aat = nil, nil, nil

	for k,v in next, player.GetAll() do
		if !ok.vars["aimbot"]["enabled"]:GetBool() or !v or !v:IsPlayer() or 0 >= v:Health() or v:IsDormant() or v == me then continue end
		if ok.vars["aimbot"]["team"]:GetBool() and v:Team() == me:Team() then continue end
		if ok.vars["aimbot"]["friends"]:GetBool() and v:GetFriendStatus() == "friend" then continue end
		local sp, ep
		vis, sp, ep = ok.CheckVis(v)
		ok.aat = v
		if vis or (ok.vars["aimbot"]["autowall"]:GetBool() and ok.CanWallbang(sp, ep, v)) then ok.sp = sp ok.ep = ep break else continue end
	end
end

function ok.DoSilent(cmd)
	if !ok.fa then ok.fa = cmd:GetViewAngles() end
	ok.fa = ok.fa + Angle(cmd:GetMouseY() * ok.ys, cmd:GetMouseX() * -ok.ys, 0)
	ok.fa.p = math.Clamp(ok.fa.p, -89, 89)
	ok.fa.y = math.NormalizeAngle(ok.fa.y)
end

function ok.FixMove(cmd, aa)
	local fix = Vector(cmd:GetForwardMove(), cmd:GetSideMove(), 0)
	fix = (fix:Angle() + cmd:GetViewAngles() - Angle(0, ok.fa.y, 0)):Forward() * fix:Length()
       
	if aa then
		cmd:SetForwardMove(fix.x)
		cmd:SetSideMove(fix.y * -1)
		return
	end
       
	cmd:SetForwardMove(fix.x)
	cmd:SetSideMove(fix.y)
end

function ok.GetCurTime()
	if IsFirstTimePredicted() then
		ok.ct = CurTime() + engine.TickInterval()
	end
end

function ok.CanFire()
	if !ok.ct or ok.ct == 0 then return false end
	local wep = me:GetActiveWeapon() or NULL
	if !IsValid(wep) then return false end
	return wep:GetActivity() != ACT_RELOAD and ok.ct > wep:GetNextPrimaryFire()
end

function ok.Aimbot(cmd)
	local autoshoot = ok.vars["aimbot"]["autoshoot"]:GetBool()
	local nextshot = ok.vars["aimbot"]["nextshot"]:GetBool()
	local silent = ok.vars["aimbot"]["silent"]:GetBool()
	local fakelag = ok.vars["hvh"]["fakelag"]:GetBool()
	local antiaim = ok.vars["hvh"]["antiaim"]:GetBool()

	ok.DoSilent(cmd)
	if cmd:CommandNumber() == 0 and !ok.vars["thirdperson"]:GetBool() and (silent or antiaim) then cmd:SetViewAngles(ok.fa) return end

	if !fakelag then
		bSendPacket = true
	end

	if ok.sp and ok.ep then
		local aafix = false
		local ap = ok.Compensate(cmd, (ok.ep - ok.sp):Angle())
		ap.p, ap.y = math.NormalizeAngle(ap.p), math.NormalizeAngle(ap.y)

		if ok.CanFire() and (autoshoot or cmd:KeyDown(IN_ATTACK)) then
			cmd:SetViewAngles(ap)
			if autoshoot then
				if nextshot then
					cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
				else
					if ok.atk then
						cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_ATTACK))
					else
						cmd:RemoveKey(IN_ATTACK)
					end

					ok.atk = !ok.atk
				end
			end

			if silent then
				ok.FixMove(cmd, aafix)
			end

			if !fakelag then
				bSendPacket = false
			end
		else
			if autoshoot and nextshoot then
				cmd:RemoveKey(IN_ATTACK)
			end

			cmd:SetViewAngles(ok.fa)

			if !fakelag then
				bSendPacket = true
			end
		end

		return
	end

	if antiaim or silent then
		cmd:SetViewAngles(ok.fa)
	end
end

ok.fat = 0
ok.aa_as = false
ok.aa_a = 0
ok.aayaws = {}

function ok.AntiAim(cmd, force)
	if cmd:CommandNumber() == 0 and !ok.vars["thirdperson"]:GetBool() then return end
	if !force and (ok.sp != nil or ok.ep != nil) then return end
	if !force and cmd:KeyDown(IN_ATTACK) then
		if ok.vars["aimbot"]["static"]:GetBool() then
			cmd:SetViewAngles(Angle(-ok.fa.p - 180, ok.fa.y + 180, 0))
			ok.FixMove(cmd, true)
		end

		return
	end

	for i = 1, 5 do
		ok.aayaws[i] = (ok.vars["hvh"]["yawbase"]:GetInt() * i) + ok.vars["hvh"]["yawadd"]:GetInt()
	end

	if ok.vars["hvh"]["antiaim"]:GetBool() then
		local fakeangles = ok.vars["hvh"]["fakeangles"]:GetBool()
		local pitch = ok.vars["hvh"]["pitch"]:GetFloat() or 262
		local yaw = ok.vars["hvh"]["yaw"]:GetFloat() or 450

		if ok.vars["hvh"]["fakeangles"]:GetBool() and !ok.vars["hvh"]["fakelag"]:GetBool() then
			if ok.fat >= 3 then
				bSendPacket = !bSendPacket
				ok.fat = 0
			end
		end

		ok.fat = ok.fat + 1

		if ok.vars["hvh"]["adaptive"]:GetBool() then


			local adapyaw = ok.vars["hvh"]["adapyaw"]:GetFloat()
			local aay = (ok.aat and ok.aat != NULL) and (ok.aat:GetAttachment(ok.aat:LookupAttachment("forward") or ok.aat:LookupAttachment("eyes")).Pos - me:GetShootPos()):Angle().y + 180 or 0
			if !fakeangles then
				cmd:SetViewAngles(Angle(pitch, aay + adapyaw + math.random(-15, 15), 0))
			else
				if bSendPacket then
					cmd:SetViewAngles(Angle(pitch, aay + adapyaw + ok.aa_a, 0))
				else
					cmd:SetViewAngles(Angle(pitch, aay + adapyaw + 90 + ok.aa_a, 0))
				end
			end
		elseif ok.vars["hvh"]["jitter"]:GetBool() then
			if !fakeangles then
				cmd:SetViewAngles(Angle(pitch, table.Random(ok.aayaws) + math.random(-2, 2), 0))
			else
				if bSendPacket then
					cmd:SetViewAngles(Angle(pitch, table.Random(ok.aayaws) + math.random(-2, 2), 0))
				else
					cmd:SetViewAngles(Angle(pitch, table.Random(ok.aayaws) - 90 + math.random(-10, 10), 0))
				end
			end
		else
			if !fakeangles then
				cmd:SetViewAngles(Angle(pitch, yaw, 0))
			else
				if bSendPacket then
					cmd:SetViewAngles(Angle(pitch, yaw, 0))
				else
					cmd:SetViewAngles(Angle(pitch, yaw + 90, 0))
				end
			end
		end

		if ok.vars["hvh"]["edge"]:GetBool() then

		end

		pitch = cmd:GetViewAngles().p
		ok.aas = !ok.aas
		ok.FixMove(cmd, (pitch > 90 or -90 > pitch) and true or false)
	end
end

function ok.FakeLag(cmd)
	if cmd:CommandNumber() == 0 then return end
	local choke = ok.vars["hvh"]["flchoke"]:GetInt()
	local send = ok.vars["hvh"]["flsend"]:GetInt()
	ok.fltm = choke + send

	if ok.vars["hvh"]["fakelag"]:GetBool() then
		ok.flt = ok.flt + 1
		
		if ok.flt > ok.fltm then
			ok.flt = 1
		end

		if send >= ok.flt then
			bSendPacket = true
		else
			bSendPacket = false
		end
	end
end

function ok.CheckAAA(ply)
	for f,t in next, ok.pitches do
		for i,p in next, t do
			if tonumber(string.sub(tostring(ply:EyeAngles().x), 1, 5)) == p then
				ply:SetRenderAngles(Angle(0, ply:EyeAngles().y + 180, 0))
				ply:SetPoseParameter("aim_pitch", tonumber(f))
				ply:InvalidateBoneCache()
			end
		end
	end
end

function ok.AutoHop(cmd)
	if me:IsOnGround() and cmd:KeyDown(IN_JUMP) then
		cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_JUMP))
	else
		cmd:RemoveKey(IN_JUMP)
	end
end

ok.ld = false
ok.gd = false

function ok.HighJump(cmd)
	if !ok.vars["highjump"]:GetBool() then return end
	local pos = me:GetPos()
	local tdata = {start = pos, endpos = pos - Vector(0, 0, 1337), mask = MASK_SOLID}
	local trace = util.TraceLine(tdata)
	if (pos - trace.HitPos).z > 35 then
		ok.ld = true
		cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_DUCK))
	elseif !ok.gd then
		if ok.ld then
			ok.gd = true
			ok.ld = false
		end

		cmd:RemoveKey(IN_DUCK)
	end

	if me:IsOnGround() then
		ok.gd = false
	end
end

function ok.Visuals()
	ok.er = math.sin(CurTime() * 4) * 127 + 128
	ok.eg = math.sin(CurTime() * 4 + 2) * 127 + 128
	ok.eb = math.sin(CurTime() * 4 + 4) * 127 + 128
	draw.SimpleText("Sperg$masher", "wireless gamer", 4, 40, Color(ok.er, ok.eg, ok.eb), TEXT_ALIGN_LEFT, TEXT_ALIGN_BOTTOM)

	for k,v in next, player.GetAll() do
		if !ok.vars["visuals"]["enabled"]:GetBool() or !v:IsValid() or !v:IsPlayer() or !v:Alive() or 0 >= v:Health() or v == me then continue end
		local min, max, pos = v:OBBMins(), v:OBBMaxs(), v:GetPos()
		local top, bottom = (pos + Vector(0, 0, max.z)):ToScreen(), (pos - Vector(0, 0, 15)):ToScreen()
		local middle = bottom.y - top.y
		local width = middle / 2.5

		if ok.vars["visuals"]["name"]:GetBool() then
			draw.SimpleText(v:Nick(), "visual gamer", bottom.x, top.y - 12, Color(255, 255, 255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		if ok.vars["visuals"]["box"]:GetBool() then
			surface.SetDrawColor(me:Team() == v:Team() and Color(0, 0, 255) or Color(255, 255, 0))
			surface.DrawOutlinedRect(bottom.x - width, top.y, width * 2, middle)
			surface.SetDrawColor(Color(0, 0, 0))
			surface.DrawOutlinedRect(bottom.x - width - 1, top.y - 1, width * 2 + 2, middle + 2)
			surface.DrawOutlinedRect(bottom.x - width + 1, top.y + 1, width * 2 - 2, middle - 2)
		end

		if ok.vars["visuals"]["health"]:GetBool() then
			local health = v:Health()
			local col = health >= 101 and Color(0, 200, 0) or Color(0, 255, 0)
			draw.SimpleText(tostring(health), "visual gamer", bottom.x, bottom.y + 12, col, TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		if ok.vars["visuals"]["rank"]:GetBool() then
			local rank = v:GetUserGroup()
			draw.SimpleText(rank, "visual gamer", bottom.x, bottom.y + 24, (rank == "guest" or rank == "user") and Color(255, 255, 0) or Color(255, 0, 0), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end

		if ok.vars["visuals"]["team"]:GetBool() then
			local tm = v:Team()
			draw.SimpleText(team.GetName(tm), "visual gamer", bottom.x, bottom.y + 36, team.GetColor(tm), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
		end
	end
end

ok.chams1 = CreateMaterial("wireless_gamer_material", "UnlitGeneric", {
	["$ignorez"] = 1,
	["$model"] = 1,
	["$basetexture"] = "models/debug/debugwhite"
})

ok.chams2 = CreateMaterial("wired_gamer_loser_material", "UnlitGeneric", {
	["$ignorez"] = 0,
	["$model"] = 1,
	["$basetexture"] = "models/debug/debugwhite"
})

function ok.GetChamsColor(t, v)
	if t then
		if v then
			return 0, 0, 255 / 255
		else
			return 0, 255 / 255, 0
		end	
	else
		if v then
			return 255 / 255, 255 / 255, 0
		else
			return 255 / 255, 185 / 255, 0
		end
	end
end

function ok.Chams()
	for k,v in next, player.GetAll() do
		if !ok.vars["visuals"]["enabled"]:GetBool() or !ok.vars["visuals"]["chams"]:GetBool() or !v:IsValid() or !v:IsPlayer() or !v:Alive() or 0 >= v:Health() or v == me then continue end
		cam.Start3D()
		render.MaterialOverride(ok.chams1)
		render.SetColorModulation(ok.GetChamsColor(me:Team() == v:Team(), true))
		v:DrawModel()

		render.SetColorModulation(ok.GetChamsColor(me:Team() == v:Team(), false))
		render.MaterialOverride(ok.chams2)
		v:DrawModel()
		cam.End3D()
	end
end

function ok.CalcView(ply, pos, angle, fov, nearZ, farZ)
	local view = {}
	view.angles = (ok.vars["hvh"]["antiaim"]:GetBool() or ok.vars["aimbot"]["silent"]:GetBool()) and ok.fa or angle
	view.origin = ok.vars["thirdperson"]:GetBool() and (pos - ok.fa:Forward() * 100) or pos

	return view
end

function ok.ShouldDrawLocalPlayer()
	return ok.vars["thirdperson"]:GetBool()
end

function ok.PreDrawOpaqueRenderables()
	for k,v in next, player.GetAll() do
		ok.CheckAAA(v)
	end

	for e,a in next, ok.aaa do
		if !e or !IsValid(e) or !e:IsPlayer() then ok.aaa[e] = nil continue end
		e:SetRenderAngles(Angle(0, a.y, 0))
		e:SetPoseParameter("aim_pitch", a.p)
		e:InvalidateBoneCache()
	end
end

function ok.AAAMenu()
	local last = 0

	local frame = vgui.Create("DFrame")
	frame:SetSize(350, 300)
	frame:SetPos(0, 0)
	frame:SetTitle("AAA Menu")
	frame:Center()
	frame:MakePopup()

	local lista = vgui.Create("DListView", frame)
	lista:SetPos(0, 24)
	lista:SetSize(250, 276)
	lista:SetMultiSelect(false)
	lista:AddColumn("Players")
	lista:AddColumn("Pitch")
	lista:AddColumn("Yaw")

	local ply = 0

	lista.OnRowSelected = function(panel, line)
		ply = line
	end

	local plabel = vgui.Create("DLabel", frame)
	plabel:SetPos(255, 26)
	plabel:SetText("Pitch:")

	local ylabel = vgui.Create("DLabel", frame)
	ylabel:SetPos(255, 40)
	ylabel:SetText("Yaw:")

	local ptext = vgui.Create("DTextEntry", frame)
	ptext:SetPos(285, 30)
	ptext:SetSize(30, 14)
	ptext:SetText("89")
	ptext.OnEnter = function() end

	local ytext = vgui.Create("DTextEntry", frame)
	ytext:SetPos(285, 44)
	ytext:SetSize(30, 14)
	ytext:SetText("180")
	ytext.OnEnter = function() end

	local but = vgui.Create("DButton", frame)
	but:SetPos(255, 66)
	but:SetSize(65, 24)
	but:SetText("Set")
	
	function but.DoClick()
		if player.GetAll()[ply] then
			ok.aaa[player.GetAll()[ply]] = Angle(tonumber(ptext:GetText()), tonumber(ytext:GetText()), 0)
		end
	end

	for i = 1, #player.GetAll() do
		local e = player.GetAll()[i]
		lista:AddLine(e:Nick(), e:EyeAngles().p, e:EyeAngles().y)
	end
end

function ok.ResetConsoleVars()
	for k,v in next, ok.cvars do
		me:ConCommand(k .. " " .. v)
		ok.Log("Reset convar: ", Color(255, 120, 5), k, Color(255, 0, 0), " (value: ", v, ")")
	end
end

function ok.AddHook(htype, name, func)
	hook.Add(htype, name, func)
	ok.Log("Created ", Color(255, 120, 5), htype, Color(255, 190, 5), " hook: ", Color(255, 120, 5), name, Color(255, 0, 0), " (" .. tostring(func) .. ")")
end

function ok.CreateMove(cmd)
	ok.Aimbot(cmd)
	ok.AntiAim(cmd)
	ok.FakeLag(cmd)
	ok.AutoHop(cmd)
	ok.HighJump(cmd)
end

ok.AddHook("Think", "ok.GetTarget", ok.GetTarget)
ok.AddHook("Move", "ok.GetCurTime", ok.GetCurTime)
ok.AddHook("DrawOverlay", "ok.Visuals", ok.Visuals)
ok.AddHook("RenderScreenspaceEffects", "ok.Chams", ok.Chams)
ok.AddHook("CreateMove", "ok.CreateMove", ok.CreateMove)
ok.AddHook("CalcView", "ok.CalcView", ok.CalcView)
ok.AddHook("ShouldDrawLocalPlayer", "ok.ShouldDrawLocalPlayer", ok.ShouldDrawLocalPlayer)
ok.AddHook("PreDrawOpaqueRenderables", "ok.PreDrawOpaqueRenderables", ok.PreDrawOpaqueRenderables)
concommand.Add("ok_aaa", ok.AAAMenu)
ok.Log("Created concommand: ", Color(255, 120, 5), "ok_aaa", Color(255, 0, 0), " (" .. tostring(ok.AAAMenu) .. ")")
concommand.Add("ok_resetcv", ok.ResetConsoleVars)
ok.Log("Created concommand: ", Color(255, 120, 5), "ok_resetcv", Color(255, 0, 0), " (" .. tostring(ok.ResetConsoleVars) .. ")")
ok.Log("Loaded!")