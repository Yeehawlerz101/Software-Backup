 
hook.Add( "HUDPaint", "Wallhack", function()
 
	for k,v in pairs ( player.GetAll() ) do
 
		local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
		local Name = ""
 
		if v == LocalPlayer() then Name = "" else Name = v:Name() end
 
		draw.DrawText( Name, "Trebuchet16", Position.x, Position.y, Color( 255, 255, 255, 255 ), 1 )
 
	end
 
end )
 