


surface.CreateFont(
        "darkhud", {
                font = "Trebuchet24",
                size = 14,
                weight = 50,
        }
)

 hook.Add("DrawOverlay", function(ucmd)
        local humans = player.GetAll()
		dark.me    = LocalPlayer()
        for k,v in next, humans do
                if (!IsValid(v) || v == dark.me || !v:Alive() || v:Health() < 1 || v:Name() == nil) then continue end
                local c = v:LocalToWorld( v:OBBCenter() ):ToScreen()
					draw.RoundedBox( 4, c.x - 10 , c.y - 65, 20,  5, (team.GetColor( v:Team() )))		
					draw.SimpleTextOutlined( dark.g.math.Round( v:GetPos():Distance(LocalPlayer():GetPos())), "darkhud", c.x , c.y - 55, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 9, 94 , 0))
					draw.SimpleTextOutlined( v:Health(), "darkhud", c.x , c.y  - 45, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 9, 94 , 0 ))
					draw.SimpleTextOutlined( v:GetUserGroup(), "darkhud", c.x , c.y - 35, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 9, 94 , 0 ))
					draw.SimpleTextOutlined( v:Name(), "darkhud", c.x , c.y  - 25, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 9, 94 , 0 ))
	  

		
		end
end)
 