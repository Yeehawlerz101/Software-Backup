+-----------------------------------+
|            _               ____   |
|           (_)             |___ \  |
|  ___ _ __  ___  __ ________ __) | |
| / __| '_ \| \ \/ /|_  /_  /|__ <  |
| \__ \ | | | |>  <  / / / / ___) | |
| |___/_| |_|_/_/\_\/___/___|____/  |
|                                   |
+-----------------------------------+
| Instructions                      |
+-----------------------------------+

Injection:
 
<WORK IN PROGRESS, FOR NOW FIND YOUR OWN INJECTOR, SIMPLY INJECT EXTERNAL2.DLL INTO HL2.EXE AND FOLLOW THE INSTRUCTIONS BELOW>

You are given 2 C++ .dll modules & 1 .lua file
Place the .dll files APART FROM external2.dll into your garrysmod/garrysmod/lua/bin/ folder, if it doesn't exist, create it.
Create a folder named "external" in your Documents folder, place snixzz3.lua and external2.dll here.
Run your sv_allowcslua bypass, for more information on how to do this, see the Injection section above
Once in a server type 'external snixzz3.lua' in your console (~) to load the snixzz3 launcher.
You will be greeted with a basic loader, simply select the build you would like to load & the method you would like to use

+-----------------------------------+
| Support                           |
+-----------------------------------+

n/a

+-----------------------------------+
| Legal                             |
+-----------------------------------+

Permission to use, copy and/or modify for any purpose with or without fee is hereby granted, provided that the above copyright notice and this permission notice appear in all copies. You may not redistribute the software and the software should only be downloaded from offical sources.

THE SOFTWARE IS PROVIDED "AS IS" AND THE AUTHOR DISCLAIMS ALL WARRANTIES WITH REGARD TO THIS SOFTWARE INCLUDING ALL IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS. IN NO EVENT SHALL THE AUTHOR BE LIABLE FOR ANY SPECIAL, DIRECT, INDIRECT, OR CONSEQUENTIAL DAMAGES OR ANY DAMAGES WHATSOEVER RESULTING FROM LOSS OF USE, DATA OR PROFITS, WHETHER IN AN ACTION OF CONTRACT, NEGLIGENCE OR OTHER TORTIOUS ACTION, ARISING OUT OF OR IN CONNECTION WITH THE USE OR PERFORMANCE OF THIS SOFTWARE.

+-----------------------------------+
| UUID                              |
+-----------------------------------+

Downloaded at Fri, 16 Sep 2016 06:01:58 -0700 (1474030918)
FF432E08-2BD5-BB4E-136E-144634363D6F