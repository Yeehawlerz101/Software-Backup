local Frame = vgui.Create( "DFrame" )
Frame:SetTitle( "Yeehaw Menu!" )
Frame:SetSize( ScrW() * 0.708, ScrH() * .77 )
Frame:Center()
Frame:MakePopup()
Frame.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
	draw.RoundedBox( 0, 0, 0, w, h, Color( 20, 50, 60, 100 ) ) -- Draw a Dark Blue box instead of the frame
end

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Frame )
CheckBoxThing:SetPos( 30,50 )
CheckBoxThing:SetText( "Bunny hop" )
CheckBoxThing:SetConVar( "bhop" ) 1, 0
CheckBoxThing:SetPos( 150, 150 )
CheckBoxThing:SetSize( 100, 30 )

--local HTMLTest = vgui.Create("HTML")
--HTMLTest:SetPos(50,50)
--HTMLTest:SetSize(ScrW() - 150, ScrH() - 150)
--HTMLTest:OpenURL("http://www.yeehawlerz101.weebly.com")

	  cvars.AddChangeCallback("bhop", function()
if GetConVarNumber("bhop") == 1 then
     
	 


	 print( Variable works ); -- Output: "Shared"
     
    
  end
  end)


local Button = vgui.Create( "DButton", Frame )
Button:SetText( "Click me I'm pretty!" )
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 100, 100 )
Button:SetSize( 100, 30 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color( 41, 128, 185, 250 ) ) -- Draw a button
end
Button.DoClick = function()
	print( "I was clicked!" )
end