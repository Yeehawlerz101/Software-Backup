/*
	
	snixzz.net PropHunt ESP
	Author: 0xymoron
	
	VISIT snixzz.net FOR THE BEST FREE & PRIVATE CHEATS & SCRIPTS!
	
*/

-- Tables & copies
local snixzz = { g = table.Copy( _G ) }
local g = snixzz.g.table.Copy( _G ) 
local r = g.debug.getregistry()

-- Undefined variables
local pos	


function snixzz.AddHook( Type, Func )
	name = g.tostring( Func )
	return g.hook.Add( Type, name, Func )
end
	
function snixzz.HUDPaint()
	
	for k, v in g.next, g.ents.FindByClass( "ph_prop" ) do
		pos = v:GetPos():ToScreen()
		
		if v:GetOwner() != g.LocalPlayer() then

			g.cam.Start3D()			
				v:SetMaterial( "" )
				v:DrawModel()				
			g.cam.End3D()
					
			g.draw.SimpleText( "Prop", "default", pos.x, pos.y + 20, g.Color( 255, 0, 0 ), g.TEXT_ALIGN_CENTER, g.TEXT_ALIGN_CENTER )
			g.draw.SimpleText( v:GetOwner():Name(), "DefaultFixed", pos.x, pos.y - 11, g.Color( 255, 255, 255, 255 ), g.TEXT_ALIGN_CENTER, g.TEXT_ALIGN_CENTER )
			
			halo.Add({v}, Color( 255, 0, 0, 250 ), 5, 1, 1, true, true);
		end
		
	end

end

function snixzz.HUDPaint2()
	for k,v in pairs(player.GetAll()) do
		for k,v2 in pairs(v:GetWeapons()) do
		pos = v:GetPos():ToScreen()
		
		if v:GetOwner() != g.LocalPlayer() then

			g.cam.Start3D()			
				v:SetMaterial( "" )
				v:DrawModel()				
			g.cam.End3D()
					
			g.draw.SimpleText( "Hunter", "default", pos.x, pos.y + 20, g.Color( 0, 0, 205 ), g.TEXT_ALIGN_CENTER, g.TEXT_ALIGN_CENTER )
			g.draw.SimpleText(v:Name(), "DefaultFixed", pos.x, pos.y - 11, g.Color( 0, 0, 205, 255 ), g.TEXT_ALIGN_LEFT, g.TEXT_ALIGN_LEFT)
			halo.Add({v}, Color( 0, 0, 205, 250 ), 1, 1, 1, true, true);
			
			end
		end
	end
end
snixzz.AddHook( "HUDPaint", snixzz.HUDPaint )
snixzz.AddHook( "HUDPaint", snixzz.HUDPaint2 )