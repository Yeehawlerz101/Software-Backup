concommand.Add( "Yeehaw_Menu", function()

 surface.PlaySound ("ambient/levels/canals/drip4.wav")

local Frame = vgui.Create( "DFrame" )
Frame:SetTitle( "Yeehaw Menu!" )
Frame:SetSize( ScrW() * 0.708, ScrH() * .77 )
Frame:Center()
Frame:MakePopup()
Frame.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
	draw.RoundedBox( 0, 0, 0, w, h, Color( 20, 50, 60, 100 ) ) -- Draw a Dark Blue box instead of the frame
end

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Frame )
CheckBoxThing:SetPos( 30,50 )
CheckBoxThing:SetText( "Bunny hop" )
CheckBoxThing:SetConVar( "_Yesp")
CheckBoxThing:SetPos( 150, 150 )
CheckBoxThing:SetSize( 100, 30 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color( 41, 128, 185, 250 ) ) -- Draw a blue button
end
CreateClientConVar(cmdStr.."_entityesp", 0, true, false)

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", ESP )
CheckBoxThing:SetPos( 10,150 )
CheckBoxThing:SetText( "Entity ESP" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_entityesp" ) 
CheckBoxThing:SizeToContents() 




 cvars.AddChangeCallback("bhop", function()
		if GetConVarNumber("bhop") == 1 then
			surface.PlaySound ("ambient/machines/thumper_startup1.wav")
			chat.AddText( Color( 100, 255, 100 ) ,"Yeehaw_Menu:" ,  Color( 0, 157, 209 ), "Bunnyhop is turned", Color( 13, 255, 134 ), " Activated")
		elseif GetConVarNumber("bhop") == 0 then
			chat.AddText( Color( 100, 255, 100 ) ,"Yeehaw_Menu:" ,  Color( 0, 157, 209 ),"Bunnyhop is turned", Color( 255,110,0 ), " Deactivated" )
			surface.PlaySound ("buttons/combine_button5.wav")
		end
end)



local Button = vgui.Create( "DButton", Frame )
Button:SetText( "Click me I'm pretty!" )
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( 100, 100 )
Button:SetSize( 100, 30 )
Button.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color( 41, 128, 185, 250 ) ) -- Draw a blue button
end
Button.DoClick = function()
	print( "I was clicked!" )
end
end)
