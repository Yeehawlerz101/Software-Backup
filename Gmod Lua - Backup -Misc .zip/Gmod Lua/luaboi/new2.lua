local PESP = CreateClientConVar("Prop_ESP", "1", true, false)
local ply = LocalPlayer()






local function coordinates( ent )
	local min, max = ent:OBBMins(), ent:OBBMaxs()
	local corners = {
			Vector( min.x, min.y, min.z ),
			Vector( min.x, min.y, max.z ),
			Vector( min.x, max.y, min.z ),
			Vector( min.x, max.y, max.z ),
			Vector( max.x, min.y, min.z ),
			Vector( max.x, min.y, max.z ),
			Vector( max.x, max.y, min.z ),
			Vector( max.x, max.y, max.z )
	}
 
	local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
	for _, corner in pairs( corners ) do
		local onScreen = ent:LocalToWorld( corner ):ToScreen()
        minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
        maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
	end
 
	return minX, minY, maxX, maxY
end





hook.Add("HUDPaint", "ESPs", function()
    if PESP:GetInt() == 1 then
	for k, v in pairs(ents.FindByClass("ph_prop")) do
		if v.Owner != ply then
		cam.Start3D(EyePos(), EyeAngles())
        v:SetMaterial("")
		v:SetColor(Color(255, 0, 0, 255))
		render.MaterialOverride("models/wireframe")
		render.SuppressEngineLighting( false )
		render.SetBlend( 0.3 )
		render.SetColorModulation( 1, 0, 0 )
		v:DrawModel()

		cam.End3D()
		end
	end
	for k,v in pairs(player.GetAll()) do
			for k,v2 in pairs(v:GetWeapons()) do
				if v2:GetClass() == "weapon_crowbar" && v != ply then
					cam.Start3D(EyePos(), EyeAngles())
					v:SetMaterial("models/wireframe")
					v:SetColor(Color(0, 255, 0, 255))
					render.MaterialOverride("models/wireframe")
					render.SuppressEngineLighting( false )
					render.SetBlend( 0.3 )
					render.SetColorModulation( 0, 1, 0 )
					v:DrawModel()
					cam.End3D()
				end
			end
		end
    end
end)