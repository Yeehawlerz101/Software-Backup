chat.AddText( Color( 0, 180, 180 ), "[Murder Buddy] ", Color( 255, 255, 255 ), "Player ESP loaded successfully!" )
chat.AddText( Color( 0, 180, 180 ), "[Murder Buddy] ", Color( 255, 255, 255 ), "Loot ESP loaded successfully!" )
chat.AddText( Color( 0, 180, 180 ), "[Murder Buddy] ", Color( 255, 255, 255 ), "Weapon ESP loaded successfully!" )
chat.AddText( Color( 0, 180, 180 ), "[Murder Buddy] ", Color( 255, 255, 255 ), "Crosshair loaded successfully!" )

CreateClientConVar( "mb_player_esp", 0, true, false )
CreateClientConVar( "mb_loot_esp", 0, true, false )
CreateClientConVar( "mb_weapons_esp", 0, true, false )
CreateClientConVar( "mb_crosshair", 0, true, false )

surface.CreateFont("s1", {
font = "ScoreboardText",
size = 25,
weight = 0,
antialias = true,
shadow = false,
})

hook.Add( "HUDPaint", "Loot_esp", function()
if ConVarExists( "mb_loot_esp" ) and GetConVar("mb_loot_esp"):GetInt() == 1 then
	for k,v in pairs (ents.FindByClass("mu_loot")) do 
	local lootpos = ( v:GetPos() + Vector( 0,0,10 ) ):ToScreen()
	draw.DrawText( "Loot Here!", "s1", lootpos.x, lootpos.y, Color( 0, 255, 0, 255 ), 1 )
	end
	end
end )

hook.Add( "HUDPaint", "player_esp", function()
	if ConVarExists( "mb_player_esp" ) and GetConVar("mb_player_esp"):GetInt() == 1 then
		for k,v in pairs ( player.GetAll() ) do
		local plypos = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
		if v:Alive() then
 	surface.SetDrawColor( 255, 0, 127 )
	surface.DrawOutlinedRect( plypos.x, plypos.y, 32, 72 )
	end
	end
end
end)

hook.Add( "HUDPaint", "Weapon_esp", function()
if ConVarExists( "mb_weapons_esp" ) and GetConVar("mb_weapons_esp"):GetInt() == 1 then
	for k,v in pairs (ents.FindByClass("weapon_mu_magnum")) do 
	local gunpos = ( v:GetPos() + Vector( 0,0,10 ) ):ToScreen()
	draw.DrawText( "Gun!", "s1", gunpos.x, gunpos.y, Color( 0, 0, 255, 255 ), 1 )
	end
		for k,v in pairs (ents.FindByClass("weapon_mu_knife")) do 
	local knifepos = ( v:GetPos() + Vector( 0,0,10 ) ):ToScreen()
	draw.DrawText( "KNIFE!", "s1", knifepos.x, knifepos.y, Color( 255, 0, 0, 255 ), 1 )
	end
	end
end )

hook.Add( "HUDPaint", "crosshair", function()
if ConVarExists( "mb_crosshair" ) and GetConVar("mb_crosshair"):GetInt() == 1 then
surface.SetDrawColor( 255, 255, 0 )
surface.DrawLine(ScrW() / 2 - 10, ScrH() / 2, ScrW() / 2 + 11 , ScrH() / 2)
surface.DrawLine(ScrW() / 2 - 0, ScrH() / 2 - 10, ScrW() / 2 - 0 , ScrH() / 2 + 11)
    end
end)