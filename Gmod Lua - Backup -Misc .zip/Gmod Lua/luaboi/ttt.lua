

local function coordinates( ent )
local min, max = ent:OBBMins(), ent:OBBMaxs()
local corners = {
        Vector( min.x, min.y, min.z ),
        Vector( min.x, min.y, max.z ),
        Vector( min.x, max.y, min.z ),
        Vector( min.x, max.y, max.z ),
        Vector( max.x, min.y, min.z ),
        Vector( max.x, min.y, max.z ),
        Vector( max.x, max.y, min.z ),
        Vector( max.x, max.y, max.z )
}
 
local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
for _, corner in pairs( corners ) do
        local onScreen = ent:LocalToWorld( corner ):ToScreen()
        minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
        maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
end
 
return minX, minY, maxX, maxY
end
hook.Add("HUDPaint", "Example", function()
for k,v in pairs(player.GetAll()) do
        local x1,y1,x2,y2 = coordinates(v)
         print(tostring(team.GetColor(v:Team())))
         surface.SetDrawColor(color_white)
 
 
        surface.DrawLine( x1, y1, math.min( x1 + 5, x2 ), y1 )
        surface.DrawLine( x1, y1, x1, math.min( y1 + 5, y2 ) )
 
 
        surface.DrawLine( x2, y1, math.max( x2 - 5, x1 ), y1 )
        surface.DrawLine( x2, y1, x2, math.min( y1 + 5, y2 ) )
 
 
        surface.DrawLine( x1, y2, math.min( x1 + 5, x2 ), y2 )
        surface.DrawLine( x1, y2, x1, math.max( y2 - 5, y1 ) )
 
 
        surface.DrawLine( x2, y2, math.max( x2 - 5, x1 ), y2 )
        surface.DrawLine( x2, y2, x2, math.max( y2 - 5, y1 ) )
end
end)


concommand.Add("ihop_toggle", function()
if ihop then
    ihop = !ihop
    LocalPlayer():ChatPrint("iHop turned OFF")
else
    ihop = !ihop
    LocalPlayer():ChatPrint("iHop turned ON")
end
end)


LocalPlayer():ChatPrint("Traitor Finder Loaded")
local matOverlay = Material( "sprites/glow08" )
local matTraitor = Material( "sprites/dot" )
local twep = { "weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport", "(Disguise)" ,"spiderman's_swep", "weapon_ttt_trait_defilibrator", "weapon_ttt_xbow", "weapon_ttt_dhook", "weapon_awp", "weapon_jihadbomb", "weapon_ttt_knife", "weapon_ttt_c4", "weapon_ttt_decoy", "weapon_ttt_flaregun", "weapon_ttt_phammer", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_sipistol", "weapon_ttt_teleport", "weapon_ttt_awp", "weapon_ttt_silencedsniper", "weapon_ttt_turtlenade", "weapon_ttt_death_station", "weapon_ttt_sg552", "weapon_ttt_tripmine"}

for _,v in pairs(player.GetAll()) do
        v.HatTraitor = nil
end
for _,v in pairs(ents.GetAll()) do
        v.HatESPTracked = nil
end

hook.Add("PostDrawOpaqueRenderables", "wire_animations_idle", function()
        if GAMEMODE.round_state != ROUND_ACTIVE then
                for _,v in pairs(player.GetAll()) do
                        v.HatTraitor = nil
                end
                for _,v in pairs(ents.GetAll()) do
                        v.HatESPTracked = nil
                end
                return
        end
        for _,v in pairs( ents.GetAll() ) do
                if v and IsValid(v) and (table.HasValue(twep, v:GetClass()) and !v.HatESPTracked) then
                        local pl = v.Owner
                        if pl and IsValid(pl) and pl:IsTerror() then
                                if pl:IsDetective() then
                                        v.HatESPTracked = true
                                else
                                        v.HatESPTracked = true
                                        pl.HatTraitor = true
                                        chat.AddText( pl, Color(255,125,0), " is a ",Color(255,0,0), "TRAITOR",Color(255,125,0), " with a ",Color(255,0,0),v:GetClass().."!")
                                end
                        end
                end
        end
          
  

end)