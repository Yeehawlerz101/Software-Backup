	------------------------------------------------------------
	--	HUD Fonts
	--	Author: V92
	------------------------------------------------------------
	surface.CreateFont(	"StalkerClock", {			size = 14,	weight = 500,	antialias = true,	shadow = true,	font = "Arial"})
	surface.CreateFont(	"StalkerRadarText", {		size = 64,	weight = 400,	antialias = true,	shadow = true,	font = "Arial"})
	surface.CreateFont(	"StalkerAmmo", {			size = 32,	weight = 500,	antialias = true,	shadow = true,	font = "gunplay"})
	surface.CreateFont(	"StalkerAmmoStore", {		size = 24,	weight = 500,	antialias = true,	shadow = true,	font = "gunplay"})
	surface.CreateFont(	"StalkerPDATitleBarTxt", {	size = 24,	weight = 500,	antialias = true,	shadow = true,	font = "Arial"})
	surface.CreateFont(	"StalkerPDAErrorTxt", {		size = 72,	weight = 500,	antialias = false,	shadow = false,	font = "Arial"})
	surface.CreateFont(	"StalkerPDAName", {			size = 14,	weight = 500,	antialias = true,	outline = false,		shadow = true,	font = "Arial"})

			local Tex_HudMapNoise = surface.GetTextureID("jessev92/ui/stalker/cop/noise_minimap")
			local hudMapNoiseSize	= 218
			local hudMapXPos 	= 12
			local hudMapYPos 	= 12
			surface.SetTexture( Tex_HudMapNoise )
			surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
			surface.DrawTexturedRect ( hudMapXPos,hudMapYPos,hudMapNoiseSize, hudMapNoiseSize )	
		else
				local Tex_HudMapNoise = surface.GetTextureID("jessev92/ui/stalker/cop/noise_minimap")
				local hudMapNoiseSize	= 218
				local hudMapXPos 	= 12
				local hudMapYPos 	= 12
				surface.SetTexture( Tex_HudMapNoise )
				surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
				surface.DrawTexturedRect ( hudMapXPos,hudMapYPos,hudMapNoiseSize, hudMapNoiseSize )	
			else
				local	_RADARDOTCOLOUR		= Color( 255, 255, 255, 255 )
				local	_RADARTEXTCOLOUR	= Color( 255, 255, 255, 255 )
				local	_RADARW				= 164
				local	_RADARH				= 164
				local	_RADAR_X			= 37
				local	_RADAR_Y			= 43
				local	_RADARALP			= 0.8
				local	_RADARRANGE			= 5000
				local	_RADARBGDCOL		= Color(50,50,50,255)
				local	_RADARFGDCOL		= Color(0,0,0,255)
				local	_RADARDETAIL		= 64
				local	_RADARANG			= 0
				local	_RADNUMPLY			= 0	--	HUD Radar Player Counter
				local vertices = {}
				for i=1,_RADARDETAIL do
					local shift = math.fmod(CurTime()*_RADARANG,360)
					local sizescale = 1
					local tab = {}
						tab.x = _RADAR_X+_RADARW/2 + math.cos(math.rad((360/_RADARDETAIL)*i+shift)) * _RADARW/2 * sizescale
						tab.y = _RADAR_Y+_RADARH/2 + math.sin(math.rad((360/_RADARDETAIL)*i+shift)) * _RADARH/2 * sizescale
						tab.u = 0
						tab.v = 0
					table.insert(vertices,tab)
				end
				surface.SetTexture(surface.GetTextureID("vgui/white"))
				surface.SetDrawColor(_RADARBGDCOL.r,_RADARBGDCOL.g,_RADARBGDCOL.b,_RADARBGDCOL.a*_RADARALP)
				surface.DrawPoly(vertices)
				draw.RoundedBox( 0, _RADAR_X+_RADARW/2, _RADAR_Y, 1, _RADARH, _RADARFGDCOL )
				draw.RoundedBox( 0, _RADAR_X, _RADAR_Y+_RADARH/2, _RADARW, 1, _RADARFGDCOL )

				-- What should the MINIMAP RADAR look for?  Accepts partial names.
				local _TBLPLY = {}
				_RADARSEARCH	= {	"player",	"blastfungus",	"rpg_missile", "missile", "bolt",	"crossbow_bolt", "item_",	"npc_",	"sent_", "medic", "medkit", "health", "charger",	"prop_vehicle", "wep,", "swep", "util", "weapon", "ins_", "hl2_", "hit_"			}
				local _TBLNADE = {}
				_RADARFRAG	= {	"frag", "grenade", "nade", "shell", "40mm", "m67", "rgd", "40x46", "pineapple", "shrap", "mk2", "mkii", "m203", "gp30", "gp25", "vog25"	}
				local _TBLQUEST = {}
				_RADARQUEST = { "" }
				local _TBLANOM = {}
				_RADARANOM = { "anom", "anomaly", "anomely" }
				
				for i = 1, GetConVarNumber("vnt_stalkerhud_radar_updaterate") do	--	HUD Radar Refresh Rate
					local _ENT = ents.GetByIndex(i)
					if _ENT:IsValid() then
						local _ENTTYPE = _ENT:GetClass()
						for _K, _V in ipairs(_RADARSEARCH) do
							if string.find(_ENTTYPE,_V) then
								table.insert(_TBLPLY,_ENT)
							end
						end
						for _K, _V in ipairs(_RADARFRAG) do
							if string.find(_ENTTYPE,_V) then
								table.insert(_TBLNADE,_ENT)
							end
						end						
						for _K, _V in ipairs(_RADARQUEST) do
							if string.find(_ENTTYPE,_V) then
								table.insert(_TBLQUEST,_ENT)
							end
						end					
						for _K, _V in ipairs(_RADARANOM) do
							if string.find(_ENTTYPE,_V) then
								table.insert(_TBLANOM,_ENT)
							end
						end						
					end
				end

				for i, _SE in ipairs(_TBLPLY) do
					local	cx			= _RADAR_X+_RADARW/2
					local	cy			= _RADAR_Y+_RADARH/2
					local	_RADARPOSDIF		= _SE:GetPos()-_P:GetPos()
					local	dummy		= nil
					if (_RADARPOSDIF:Length() > _RADARRANGE) then 
						dummy = nil
					else
						if _SE:IsValid() then
							if ( _P	!=	_SE ) then
								local px = (_RADARPOSDIF.x/_RADARRANGE)
								local py = (_RADARPOSDIF.y/_RADARRANGE)
								local z = math.sqrt( px*px + py*py )
								local phi = math.rad( math.deg( math.atan2( px, py ) ) - math.deg( math.atan2( _P:GetAimVector().x, _P:GetAimVector().y ) ) - 90 )
									px = math.cos(phi)*z
									py = math.sin(phi)*z
								if _SE:IsPlayer() and _SE:Alive() then
									_RADNUMPLY = _RADNUMPLY + 1
									draw.RoundedBox( 4, cx+px*_RADARW/2-4, cy+py*_RADARH/2-4, 8, 8, Color( 25,225,25,255))
								elseif  (_SE:IsNPC() ) then
									_RADNUMPLY = _RADNUMPLY + 1
									_RADARDOTCOLOUR = Color( 150, 150, 150, 255 ) 
									draw.RoundedBox( 4, cx+px*_RADARW/2-4, cy+py*_RADARH/2-4, 8, 8, _RADARDOTCOLOUR)
								elseif  (_SE:IsWeapon() and !(_SE:GetOwner():IsPlayer() or	_SE:GetOwner():IsNPC())) then
									local Tex_HudMapBack = surface.GetTextureID("jessev92/ui/stalker/cop/minimap")
									surface.SetTexture( Tex_HudMapBack )
									surface.SetDrawColor(Color(255,255,255,255))
									--surface.DrawPartialTexturedRect ( cx+px*_RADAR_SCRSIZEX/2-12,cy+py*_RADAR_SCRSIZEY/2-12, 24, 24, 144, 233, 24, 24, 256, 256 )
									surface.DrawPartialTexturedRect ( cx+px*_RADARW/2-8,cy+py*_RADARH/2-8, 16, 16, 167, 229, 27, 27, 256, 256 )
								end
								if GetConVarNumber( "VNT_STALKERHUD_Radar_Names" ) != 0 then
									if _SE:IsPlayer() then
										draw.DrawText(_SE:GetName(), "StalkerClock", cx+px*_RADARW/2, cy+py*_RADARH/2+8, Color( 225,225,225,255), TEXT_ALIGN_CENTER)
									elseif _SE:IsNPC() then
										draw.DrawText( _SE:GetClass(), "StalkerClock", cx+px*_RADARW/2, cy+py*_RADARH/2+8, _RADARTEXTCOLOUR, TEXT_ALIGN_CENTER)
									elseif  _SE:IsWeapon() and (!_SE:GetOwner():IsPlayer() and	!_SE:GetOwner():IsNPC()) then
										_RADARTEXTCOLOUR = Color( 255, 255, 255, 255 ) 
										draw.DrawText( _SE:GetPrintName(), "StalkerClock", cx+px*_RADARW/2, cy+py*_RADARH/2+8, _RADARTEXTCOLOUR, TEXT_ALIGN_CENTER)
									end
								end	
							elseif !_SE:Alive() then
								_RADNUMPLY = _RADNUMPLY - 1
							end
						end
					end
				end
				if _RADNUMPLY <= 0 then	_RADNUMPLY	= 0	end
				if _RADNUMPLY > 99 then	_RADNUMPLY	= 99 end
				
				draw.SimpleText( _RADNUMPLY, "StalkerClock", 220,126,Color( 255, 217, 0, 255 ), 1, 1)
				for i, _SE in ipairs(_TBLNADE) do
					local	cx			= _RADAR_X+_RADARW/2
					local	cy			= _RADAR_Y+_RADARH/2
					local	_RADARPOSDIF		= _SE:GetPos()-_P:GetPos()
					local	dummy		= nil
					if (_RADARPOSDIF:Length() > _RADARRANGE) then 
						dummy = nil
					else
						if (_SE:IsValid() and !_SE:IsWeapon()) then
							local	px	= (_RADARPOSDIF.x/_RADARRANGE)
							local	py	= (_RADARPOSDIF.y/_RADARRANGE)
							local	z	= math.sqrt( px*px + py*py )
							local	phi	= math.rad( math.deg( math.atan2( px, py ) ) - math.deg( math.atan2( _P:GetAimVector().x, _P:GetAimVector().y ) ) - 90 )
										px	= math.cos(phi)*z
										py	= math.sin(phi)*z
							local Tex_HudMapBack = surface.GetTextureID("jessev92/ui/stalker/cop/minimap")
							surface.SetTexture( Tex_HudMapBack )
							surface.SetDrawColor(Color(255,255,255,255))
							surface.DrawPartialTexturedRect ( cx+px*_RADARW/2-10,cy+py*_RADARH/2-10, 20, 20, 40, 222, 20, 20, 256, 256 )
							if GetConVarNumber( "VNT_STALKERHUD_Radar_Names" ) != 0 then
								_RADARTEXTCOLOUR = Color( 255, 75, 0, 255 ) 
								draw.DrawText( _SE:GetClass(), "StalkerClock", cx+px*_RADARW/2, cy+py*_RADARH/2+8, _RADARTEXTCOLOUR, TEXT_ALIGN_CENTER)
							end	
						end
					end
				end
				for i, _SE in ipairs(_TBLQUEST) do
					local	cx			= _RADAR_X+_RADARW/2
					local	cy			= _RADAR_Y+_RADARH/2
					local	_RADARPOSDIF		= _SE:GetPos()-_P:GetPos()
					local	dummy		= nil
					if (_RADARPOSDIF:Length() > _RADARRANGE) then 
						dummy = nil
					else
						if (_SE:IsValid() and _SE:GetNWBool("STALKERQUEST") == true) then
							local	px	= (_RADARPOSDIF.x/_RADARRANGE)
							local	py	= (_RADARPOSDIF.y/_RADARRANGE)
							local	z	= math.sqrt( px*px + py*py )
							local	phi	= math.rad( math.deg( math.atan2( px, py ) ) - math.deg( math.atan2( _P:GetAimVector().x, _P:GetAimVector().y ) ) - 90 )
										px	= math.cos(phi)*z
										py	= math.sin(phi)*z
							local Tex_HudMapBack = surface.GetTextureID("jessev92/ui/stalker/cop/minimap")
							surface.SetTexture( Tex_HudMapBack )
							surface.SetDrawColor(Color(255,255,255,255))
							surface.DrawPartialTexturedRect ( cx+px*_RADARW/2-10,cy+py*_RADARH/2-10, 20, 20, 120, 233, 23, 23, 256, 256 )
							if GetConVarNumber( "VNT_STALKERHUD_Radar_Names" ) != 0 then
								_RADARTEXTCOLOUR = Color( 255, 217, 0, 255 )
								draw.DrawText( _SE:GetClass(), "StalkerClock", cx+px*_RADARW/2, cy+py*_RADARH/2+8, _RADARTEXTCOLOUR, TEXT_ALIGN_CENTER)
							end	
						end
					end
				end
				for i, _SE in ipairs(_TBLANOM) do
					local	cx			= _RADAR_X+_RADARW/2
					local	cy			= _RADAR_Y+_RADARH/2
					local	_RADARPOSDIF		= _SE:GetPos()-_P:GetPos()
					local	dummy		= nil
					if (_RADARPOSDIF:Length() > _RADARRANGE) then 
						dummy = nil
					else
						if (_SE:IsValid() and _SE:GetClass(_RADARANOM)) then
							local	px	= (_RADARPOSDIF.x/_RADARRANGE)
							local	py	= (_RADARPOSDIF.y/_RADARRANGE)
							local	z	= math.sqrt( px*px + py*py )
							local	phi	= math.rad( math.deg( math.atan2( px, py ) ) - math.deg( math.atan2( _P:GetAimVector().x, _P:GetAimVector().y ) ) - 90 )
										px	= math.cos(phi)*z
										py	= math.sin(phi)*z
							local Tex_HudMapBack = surface.GetTextureID("jessev92/ui/stalker/cop/minimap")
							surface.SetTexture( Tex_HudMapBack )
							surface.SetDrawColor(Color(255,255,255,255))
							surface.DrawPartialTexturedRect ( cx+px*_RADARW/2-18,cy+py*_RADARH/2-18, 36, 36, 216, 216, 40, 40, 256, 256 )
							if GetConVarNumber( "VNT_STALKERHUD_Radar_Names" ) != 0 then
								_RADARTEXTCOLOUR = Color( 255, 217, 0, 255 )
								draw.DrawText( _SE:GetClass(), "StalkerClock", cx+px*_RADARW/2, cy+py*_RADARH/2+8, _RADARTEXTCOLOUR, TEXT_ALIGN_CENTER)
							end	
						end
								--surface.PlaySound( Sound( "jessev92/stalker/soc/pda/beep_anom.wav" ) )
					end
				end
			end
end)