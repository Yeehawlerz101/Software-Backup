-- Made by Dark, Many thanks to Gravko for the help! Gravko credits for aimbot base!
-- Deligit hooking system and optimiziation of esp and xray a great help-
print [[


______           _    _                     _       _         _   _  __  
|  _  \         | |  ( )                   (_)     | |       | | | |/  | 
| | | |__ _ _ __| | _|/ ___   ___  ___ _ __ _ _ __ | |_ ___  | | | |`| | 
| | | / _` | '__| |/ / / __| / __|/ __| '__| | '_ \| __/ __| | | | | | | 
| |/ / (_| | |  |   <  \__ \ \__ \ (__| |  | | |_) | |_\__ \ \ \_/ /_| |_
|___/ \__,_|_|  |_|\_\ |___/ |___/\___|_|  |_| .__/ \__|___/  \___/ \___/
                                             | |                         
                                             |_|                         
                                                                                                                           
                   ---------------------------------
                   -----LIST OF CONSOLE COMMANDS----
                   ---------------------------------
dark_menu -- Opens the menu
dark_xray -- toggles the general xray
dark_entity -- toggles the Entity finder/esp (printers,money,weapons)
dark_180 -- Do a 180 flip
darkbhop -- Toggles bunny hop
dark_chat-- Toggles the autospam default message is (ooc) Dark is cool!
dark_music -- Toggles a hl2 song
dark_adminalert -- Toggles the admin alert
darkide_adminalert_distance -- Admin alert distance
dark_chatspammer - Toggle the chatspam on and off default message is "default message"
dark_chatspammer_msg -- You can change the chatspam message via the menu press enter on the chatspam input or do dark_chatspammer yourmessagehere
dark_flashspam -- Toggles the Flashlight spammer!
dark_rainbow - Toggles the rainbow physgun, It is clientside only so YOU only see this!
dark_unload -- Unloads the script! (Exits the script May be buggy)
dark_aimbot -- Toggles the aimbot, Hold E to activate
dark_aimbot_ignore_buddies -- Toggles the aimbot to ignore buddies
dark_aimbot_ignore_friends -- Toggles the aimbot to ignore friends
dark_aimbot_ignore_team -- Toggles the aimbot to ignore teammates
dark_rendertargetspy -- Toggles the render target spy camera, Server must have render target camera for this to work!
dark_crosshair 1 -- Toggles the first crosshair
dark_crosshair 2 -- toggles the second crosshair
dark_help -- Prints help message
dark_globalchat - Access a global chatroom to speak to other users of lua scripts!
dark_localchat -- Speak to other darks scripts V1 and shittyscripts users on the same server.
]]



concommand.Add ("dark_help" ,function ()
print [[

______           _    _                     _       _         _   _  __  
|  _  \         | |  ( )                   (_)     | |       | | | |/  | 
| | | |__ _ _ __| | _|/ ___   ___  ___ _ __ _ _ __ | |_ ___  | | | |`| | 
| | | / _` | '__| |/ / / __| / __|/ __| '__| | '_ \| __/ __| | | | | | | 
| |/ / (_| | |  |   <  \__ \ \__ \ (__| |  | | |_) | |_\__ \ \ \_/ /_| |_
|___/ \__,_|_|  |_|\_\ |___/ |___/\___|_|  |_| .__/ \__|___/  \___/ \___/
                                             | |                         
                                             |_|                         
                                                                                                                           
                   ---------------------------------
                   -----LIST OF CONSOLE COMMANDS----
                   ---------------------------------
dark_menu -- Opens the menu
dark_xray -- toggles the general xray
dark_entity -- toggles the Entity finder/esp (printers,money,weapons)
dark_180 -- Do a 180 flip
darkbhop -- Toggles bunny hop
dark_chat-- Toggles the autospam default message is (ooc) Dark is cool!
dark_music -- Toggles a hl2 song
dark_adminalert -- Toggles the admin alert
darkide_adminalert_distance -- Admin alert distance
dark_chatspammermer - Toggle the chatspam on and off default message is "default message"
dark_chatspammermer_msg -- You can change the chatspam message via the menu press enter on the chatspam input or do dark_chatspammer yourmessagehere
dark_flashspam -- Toggles the Flashlight spammer!
dark_rainbow - Toggles the rainbow physgun, It is clientside only so YOU only see this!
dark_unload -- Unloads the script! (Exits the script May be buggy)
dark_aimbot -- Toggles the aimbot, Hold E to activate
dark_aimbot_ignore_buddies -- Toggles the aimbot to ignore buddies
dark_aimbot_ignore_friends -- Toggles the aimbot to ignore friends
dark_aimbot_ignore_team -- Toggles the aimbot to ignore teammates
dark_rendertargetspy -- Toggles the render target spy camera, Server must have render target camera for this to work!
dark_crosshair 1 -- Toggles the first crosshair
dark_crosshair 2 -- toggles the second crosshair
dark_help -- Prints help message
dark_globalchat - Access a global chatroom to speak to other users of lua scripts!
dark_localchat -- Speak to other darks scripts V1 and shittyscripts users on the same server.
]]
end )
 
if dark then
        rawset(_G, "dark", nil)
end
 
local dark = {} // make local table
 
dark.g = table.Copy(_G); // copy _G
 
function dark.Copy(t, lookup_table)
    if (t == nil) then return nil end
    local copy = {}
    setmetatable(copy, getmetatable(t))
        for i,v in pairs(t) do
            if ( !istable(v) ) then
                     copy[i] = v
                else
                    lookup_table = lookup_table or {}
                    lookup_table[t] = copy
                    if lookup_table[v] then
                        copy[i] = lookup_table[v]
                    else
                        copy[i] = dark.Copy(v,lookup_table) --
                    end
                end
        end
    return copy
end
 
dark.new_gm_hooks                       = {};
dark.gm_hooks                           = {};                              
dark.old_gm_hooks                       = {};
dark.OrigFuncs                          = {};
dark.FakeFuncs                          = {};
dark.CmdHooks                           = {};
dark.Plys                                       = {} // table for valid players
dark.me                                         = dark.g.LocalPlayer()
dark.gm                                         = table.Copy(GAMEMODE)
dark.cm                                         = dark.Copy(dark.g.FindMetaTable("CUserCmd")) // we need these
dark.am                                         = dark.Copy(dark.g.FindMetaTable("Angle")) // we need these
dark.vm                                         = dark.Copy(dark.g.FindMetaTable("Vector")) // we need these
dark.wm                                         = dark.Copy(dark.g.FindMetaTable("Weapon")) // we need these
dark.em                                         = dark.Copy(dark.g.FindMetaTable("Entity")) // we need these
dark.pm                                         = dark.Copy(dark.g.FindMetaTable("Player")) // we need these
dark.r                                          = dark.Copy(dark.g.debug.getregistry()) // we need these
dark.ConCMD                                     = dark.Copy(concommand)
dark.odbginf                            = debug.getinfo;
dark.ogmt                                       = getmetatable;
dark.shouldbhop                         = CreateClientConVar("darkbhop", "0", true, true)
dark.xrei                                       = CreateClientConVar("dark_xray", 0, false, false)
dark.adminwarning                       = CreateClientConVar("dark_adminalert", "1", true, false)
 dark.espon                     = CreateClientConVar("dark_esp", "1", false, false)
 
 
 
dark.g.surface.CreateFont(
        "darkhud", {
                font = "Trebuchet24",
                size = 14,
                weight = 50,
        }
)
 
function dark.DetourFunc(func, newfunc) // luv from deligit to my nigga Function <3
    dark.g.table.insert(dark.OrigFuncs, func);
    dark.g.table.insert(dark.FakeFuncs, newfunc);
end
 
function dark.CopyTable(t, lookup_table)
    if (t == nil) then return nil end
    local copy = {}
    setmetatable(copy, getmetatable(t))
        for i,v in dark.g.pairs(t) do
            if ( !istable(v) ) then
                     copy[i] = v
                else
                    lookup_table = lookup_table or {}
                    lookup_table[t] = copy
                    if lookup_table[v] then
                        copy[i] = lookup_table[v]
                    else
                        copy[i] = dark.CopyTable(v,lookup_table) --
                    end
                end
        end
    return copy
end
 
setmetatable(_G, {
        ['__index'] = function(self, k)
                if k == "dark" then
                        return dark;
        end
    end,
    ['__newindex'] = function(self, k, v)
                dark.g.rawset(self, k, v);
                if k == "GAMEMODE" then
                        for k,v in dark.g.pairs(GAMEMODE) do
                                dark.old_gm_hooks[k] = v;
            end
                        local GMTbl = GAMEMODE;
                        if !(getmetatable(GMTbl)) then
                                setmetatable(GMTbl, {
                                        ['__newindex'] = function(self, k, v)
                                                dark.old_gm_hooks[k] = v;
                                        end,
                                        ['__call'] = function(self, k, id, v)
                                                if (not dark.gm_hooks[k]) then dark.gm_hooks[k] = {}; end
                                                dark.gm_hooks[k][id] = v
                                                        if (not dark.new_gm_hooks[k]) then
                                                                dark.new_gm_hooks[k] = function(GM, ...)
                                                                        if (dark.old_gm_hooks[k]) then
                                                                                dark.old_gm_hooks[k](GM, ...);
                                                                        end
                                                                        for k,v in dark.g.pairs(dark.gm_hooks[k]) do
                                                                                v(...);
                                                                        end
                                                                end
                                                                dark.DetourFunc(dark.old_gm_hooks[k], dark.new_gm_hooks[k]);
                                                        end    
                                                dark.g.rawset(self, k, dark.new_gm_hooks[k]);
                                        end,
                                        ['__index'] = function(self, k)
                                                local returnval = dark.old_gm_hooks[k] or rawget(self, k);
                                                return returnval
                                        end,
                                });
            end
        end
    end,
});
 
function dark.Hook(typ, func)
        if dark.gm[typ] and GAMEMODE[typ] then
                GAMEMODE[typ] = function(...)
                        dark.gm[typ](...)
                        func(...)
                end
        end
end
 
local ndbginf = function(func, ...)
        local args = {...};
        local targ = func;
        local arg = args[1] or false;
        for i, fakefunc in dark.g.pairs(dark.FakeFuncs) do
                if (func == fakefunc) then
                        targ = dark.OrigFuncs[i];
                        break;
                end
        end
        local tbl = arg and dark.odbginf(targ, arg) or dark.odbginf(targ);
        if (tbl.func) then tbl.func = func; end
        return(tbl)
end
 
local ngmt = function(tbl, ...)
if (dark.gdebug.traceback() and (tbl == _G or tbl == GAMEMODE)) then return nil; end
        return dark.ogmt(tbl, ...);
end
 
dark.DetourFunc(debug.getinfo,   ndbginf);
debug.getinfo   = ndbginf;
 
function dark.GetPlys() // faster than calling player.GetAll all the time
        dark.Plys = {}
        local humans = dark.g.player.GetAll()
        for i = 1, #humans do
                local v = humans[i]
                if (!IsValid(v) || v == dark.me || !v:Alive() || v:Health() < 1) then continue end
                dark.Plys[i] = v
        end
        dark.g.timer.Simple(2, dark.GetPlys) // better than using hooks
end
 
 dark.GetPlys()
 
 
 
 
 dark.Hook("DrawOverlay", function(ucmd)
        local humans = dark.g.player.GetAll()
		if dark.espon:GetBool() then
        for k,v in next, humans do
                if (!IsValid(v) || v == dark.me || !v:Alive() || v:Health() < 1 || v:Name() == nil) then continue end
                local c = v:LocalToWorld( v:OBBCenter() ):ToScreen()
               -- dark.g.draw.SimpleTextOutlined( v:Name(), "darkhud", c.x, c.y + 20, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0 ))
               -- dark.g.draw.SimpleTextOutlined( v:Health(), "darkhud", c.x, c.y - 10, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0 ))
               -- dark.g.draw.SimpleTextOutlined( team.GetName( v:Team()), "darkhud", c.x, c.y, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0 ))
               -- dark.g.draw.SimpleTextOutlined( v:GetUserGroup(), "darkhud", c.x, c.y + 10, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0 ))
                -- dark.g.draw.SimpleTextOutlined( dark.g.math.Round( v:GetPos():Distance(LocalPlayer():GetPos())), "darkhud", c.x, c.y - 20, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0))
        
		  dark.g.draw.RoundedBox( 4, c.x - 10 , c.y - 65, 20,  5, (team.GetColor( v:Team() )))		
          dark.g.draw.SimpleTextOutlined( dark.g.math.Round( v:GetPos():Distance(LocalPlayer():GetPos())), "darkhud", c.x , c.y - 55, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 9, 94 , 0))
          dark.g.draw.SimpleTextOutlined( v:Health(), "darkhud", c.x , c.y  - 45, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 9, 94 , 0 ))
          dark.g.draw.SimpleTextOutlined( v:GetUserGroup(), "darkhud", c.x , c.y - 35, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 9, 94 , 0 ))
          dark.g.draw.SimpleTextOutlined( v:Name(), "darkhud", c.x , c.y  - 25, Color( 255, 255, 255, 255 ), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color( 9, 94 , 0 ))
	  

	  		halo.Add({v}, (team.GetColor( v:Team()), 2, 2, 1, true, true);
		else
			halo.Add({v}, Color(255,0,0,255), 2, 2, 1, true, true);
		
		end
	end
end)
 

 
 
 
 -------------- ESP POSISTIONING ON THIS VERSION IS SCREWED UP DONT UPLOAD WITH THIS ACTIVE UNTIL THE ESP IS FULLY FIXED ALSO EXPERIMENTAL METHODS OF DOING THINGS ARE HERE MUST DO SURVEYS/OPINIONS BEFORE USING THIS VERSION!
---dark.Hook("DrawOverlay", function(ucmd)
       --- local humans = dark.g.player.GetAll()
       ---- for k,v in next, humans do
            ----    if (!IsValid(v) || v == dark.me || !v:Alive() || v:Health() < 1 || v:Name() == nil) then continue end
            -----    local c = v:LocalToWorld( v:OBBCenter() ):ToScreen()
				
				-------------- ESP POSISTIONING ON THIS VERSION IS SCREWED UP DONT UPLOAD UNTIL THE ESP IS FULLY FIXED ALSO EXPERIMENTAL METHODS OF DOING THINGS ARE HERE MUST DO SURVEYS/OPINIONS BEFORE USING THIS VERSION! 
				
				--- dark.g.draw.RoundedBox( 6, c.x - 26, c.y - 100, 50,  70, Color( 255, 255, 255, 100 ) ) --- need to get peoples opinions before i can use this
				
				----dark.g.draw.SimpleTextOutlined( dark.g.math.Round( v:GetPos():Distance(LocalPlayer():GetPos())), "darkhud", c.x - 20, c.y - 90, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0))
                
				---dark.g.draw.WordBox( 8, c.x - 26, c.y - 100, v:Health(), "darkhud", team.GetColor( v:Team() ), Color(255,255,255,255) ) -- maybe good idea??????????????????? wordboxes look good but are big and cant make any smaller,.,
				
				----dark.g.draw.WordBox( 8, c.x - 26, c.y - 100, ( team.GetName( v:Team())), "darkhud", team.GetColor( v:Team() ), Color(255,255,255,255) )
				
				
				---- dark.g.draw.SimpleTextOutlined( team.GetName( v:Team()), "darkhud", c.x - 20 , c.y - 80 , team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0 ))
				
               -----  dark.g.draw.SimpleTextOutlined( v:Health(), "darkhud", c.x - 20, c.y  - 70, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0 ))
                
               ----  dark.g.draw.SimpleTextOutlined( v:GetUserGroup(), "darkhud", c.x - 20, c.y - 60, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0 ))
				
				---- dark.g.draw.SimpleTextOutlined( v:Name(), "darkhud", c.x - 20, c.y  - 50, team.GetColor( v:Team() ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0 ))
                
		          

	  ----  end
---- end)
 
dark.Hook("CreateMove", function(data, ucmd)
        if (ucmd:KeyDown(2) && !dark.me:IsOnGround() && dark.shouldbhop:GetBool()) then
        ucmd:SetButtons( bit.band( ucmd:GetButtons(), bit.bnot(2) ) );
        end
end)
 
local pm = FindMetaTable("Player");
 
local ogethands = dark.pm.GetHands; -- Note: Only for c_ viewmodels
 
function pm.GetHands(...)
        return false && ogethands(...);
end
 
function dark.AdminAlert()
        if dark.adminwarning:GetBool() then
        for k,v in next, dark.Plys do
                        local amdminipos = v:LocalToWorld(v:OBBCenter()):ToScreen()
                        local admindist = dark.g.math.floor((LocalPlayer():GetPos():Distance( v:GetPos()))/40)
                        if v:GetUserGroup() != "user" and v != LocalPlayer() then
                                dark.g.draw.DrawText( "An admin is nearby!", "DermaLarge", ScrW() * 0.5, ScrH() * 0.7, Color( 255, 0, 0, 255 ), TEXT_ALIGN_CENTER )
                                dark.g.surface.PlaySound ("vo/trainyard/female01/cit_bench01.wav")
                                dark.g.surface.SetDrawColor(255,0,0)
                                dark.g.surface.DrawLine(ScrW() * .5, ScrH() * .5, amdminipos.x, amdminipos.y)
                        end
                end
        end
end
 
local chamsmat = dark.g.CreateMaterial("z", "VertexLitGeneric", {
        ["$ignorez"] = 1,
        ["$model"] = 1,
        ["$basetexture"] = "models/debug/debugwhite",
});
 
local chamsmat2 = dark.g.CreateMaterial("y", "vertexlitgeneric", {
        ["$ignorez"] = 0,
        ["$model"] = 1,
        ["$basetexture"] = "models/debug/debugwhite",
});
 
dark.xraymat = dark.g.CreateMaterial(dark.g.util.CRC("dark_xraymat"), "VertexLitGeneric", {
        ["$basetexture"] = "models/debug/debugwhite"
})
 
dark.Hook("HUDPaint", function()
        local allprops = dark.g.ents.FindByClass("prop_physics")
        for i = 1, #allprops do
                local v = allprops[i]
                if !dark.em.IsValid(v) then continue end
                if !dark.xrei:GetBool() then
                        dark.em.SetNoDraw(v, false)
                        continue
                end
                dark.g.cam.Start3D()
                        dark.g.render['SuppressEngineLighting'](true)
                        dark.g.render['MaterialOverride'](dark.xraymat)
                        dark.g.render.SetColorModulation(0,191,255)
						v:SetColor(Color(255,255,255))
                        dark.g.render.SetBlend(0.10)
                        dark.em.DrawModel(v)
                        dark.em.SetNoDraw(v, true)
                        dark.g.render['SuppressEngineLighting'](false)
                       
                        dark.em.DrawModel(v)
                dark.g.cam.End3D()
        end
        if !ShowSpec then return end
        local spectatePlayers = {}
        local x = 0
        for k,v in dark.g.next, dark.Plys do
            if v:GetObserverTarget() == LocalPlayer() then
                dark.g.table.insert(spectatePlayers, v:Name())
                        end
        end
        if #spectatePlayers == 0 then return end
        local textLength = surface.GetTextSize(dark.g.table.concat(spectatePlayers) ) / 3
        dark.g.draw.RoundedBox(1, ScrW() - 180, ScrH() - ScrH() + 15, 150, 30 + textLength, Color(0,0,0,150))
        dark.g.draw.SimpleText("Spectators", "TabLarge", ScrW() - 140, ScrH() - ScrH() + 18, Color(130, 0, 255, 255))
        dark.g.draw.SimpleText("Spectators", "TabLarge", ScrW() - 140, ScrH() - ScrH() + 16, Color(0, 255, 25, 255))
        for k,v in dark.g.next, spectatePlayers do
        dark.g.draw.SimpleText(v, "TabLarge", ScrW() - 140, ScrH() - ScrH() + 37 + x, Color(130, 0, 255, 255))
                dark.g.draw.SimpleText(v, "TabLarge", ScrW() - 140, ScrH() - ScrH() + 35 + x, Color(75, 255, 25, 255))
        x = x + 15
    end
end)

chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "Welcome to Dark's scripts!")
chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ),"Type dark_menu in console to open the menu!")



cvars.AddChangeCallback("dark_xray", function(convar_name, value_old, value_new)
		if GetConVarNumber("dark_xray") == 1 then
			surface.PlaySound ("npc/sniper/reload1.wav")
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "Xray is turned on!")
		elseif GetConVarNumber("dark_xray") == 0 then
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ),"Xray is deactivated!")
			surface.PlaySound ("vehicles/APC/apc_shutdown.wav")
		end
end)
 
 cvars.AddChangeCallback("darkbhop", function(convar_name, value_old, value_new)
		if GetConVarNumber("darkbhop") == 1 then
			surface.PlaySound ("ambient/machines/thumper_startup1.wav")
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "Bunnyhop is turned", Color( 13, 255, 134 ), " on!")
		elseif GetConVarNumber("darkbhop") == 0 then
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ),"Bunnyhop is turned", Color( 255,110,0 ), " off!" )
			surface.PlaySound ("buttons/combine_button5.wav")
		end
end)
 
  cvars.AddChangeCallback("dark_entity", function(convar_name, value_old, value_new)
		if GetConVarNumber("dark_entity") == 1 then
			surface.PlaySound ("buttons/combine_button1.wav")
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "Entity finder is turned", Color( 13, 255, 134 ), " on!")
		elseif GetConVarNumber("dark_entity") == 0 then
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ),"Entity finder is turned", Color( 255,110,0 ), " off!")
			surface.PlaySound ("buttons/combine_button2.wav")
		end
end)
 
 
   cvars.AddChangeCallback("dark_adminalert", function(convar_name, value_old, value_new)
		if GetConVarNumber("dark_adminalert") == 1 then
			surface.PlaySound ("buttons/combine_button1.wav")
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "Admin alert is turned", Color( 13, 255, 134 ), " on!")
		elseif GetConVarNumber("dark_adminalert") == 0 then
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ),"Admin alert is turned", Color( 255,110,0 ), " off!")
			surface.PlaySound ("buttons/combine_button2.wav")
		end
end)
 
 
 
    cvars.AddChangeCallback("dark_chatspammer_nrgamingisbad", function(convar_name, value_old, value_new)
		if GetConVarNumber("dark_chatspammer_nrgamingisbad") == 1 then
			surface.PlaySound ("buttons/combine_button1.wav")
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "Chat spammer is turned", Color( 13, 255, 134 ), " on!")
		elseif GetConVarNumber("dark_chatspammer_nrgamingisbad") == 0 then
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ),"Chat spammer is turned", Color( 255,110,0 ), " off!")
			surface.PlaySound ("buttons/combine_button2.wav")
		end
end)
 
 
 
 
     cvars.AddChangeCallback("dark_flashspam", function(convar_name, value_old, value_new)
		if GetConVarNumber("dark_flashspam") == 1 then
			surface.PlaySound ("buttons/combine_button1.wav")
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "Flaslight spammer is turned", Color( 13, 255, 134 ), " on!")
		elseif GetConVarNumber("dark_flashspam") == 0 then
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ),"Flashlight spammer is turned", Color( 255,110,0 ), " off!")
			surface.PlaySound ("buttons/combine_button2.wav")
		end
end)
 
 
      cvars.AddChangeCallback("dark_rainbow", function(convar_name, value_old, value_new)
		if GetConVarNumber("dark_rainbow") == 1 then
			surface.PlaySound ("ambient/energy/whiteflash.wav")
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "Rainbow physgun is turned", Color( 13, 255, 134 ), " on!")
		elseif GetConVarNumber("dark_rainbow") == 0 then
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ),"Rainbow physgun is turned", Color( 255,110,0 ), " off!")
			surface.PlaySound ("npc/roller/code2.wav")
		end
end)
 
 
 
       cvars.AddChangeCallback("dark_hud", function(convar_name, value_old, value_new)
		if GetConVarNumber("dark_hud") == 1 then
			surface.PlaySound ("npc/scanner/combat_scan2.wav")
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "HUD is turned", Color( 13, 255, 134 ), " on!")
		elseif GetConVarNumber("dark_hud") == 0 then
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ),"HUD is turned", Color( 255,110,0 ), " off!")
			surface.PlaySound ("npc/scanner/combat_scan5.wav")
		end
end)
 
 
 
        cvars.AddChangeCallback("dark_watermark", function(convar_name, value_old, value_new)
		if GetConVarNumber("dark_watermark") == 1 then
			surface.PlaySound ("npc/scanner/combat_scan2.wav")
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "Watermark is turned", Color( 13, 255, 134 ), " on!")
		elseif GetConVarNumber("dark_watermark") == 0 then
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ),"Watermark is turned", Color( 255,110,0 ), " off!")
			surface.PlaySound ("npc/scanner/combat_scan5.wav")
		end
end)
 

         cvars.AddChangeCallback("dark_crosshair", function(convar_name, value_old, value_new)
		if GetConVarNumber("dark_crosshair") == 1 then
			surface.PlaySound ("npc/roller/mine/rmine_blip3.wav")
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "Crosshair is turned", Color( 13, 255, 134 ), " on!")
		elseif GetConVarNumber("dark_crosshair") == 0 then
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ),"Crosshair is turned", Color( 255,110,0 ), " off!")
			surface.PlaySound ("npc/roller/mine/combine_mine_deactivate1.wav")
		end
end)



 
         cvars.AddChangeCallback("dark_crosshair2", function(convar_name, value_old, value_new)
		if GetConVarNumber("dark_crosshair2") == 1 then
			surface.PlaySound ("npc/roller/mine/rmine_blip3.wav")
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "2nd Crosshair is turned", Color( 13, 255, 134 ), " on!")
		elseif GetConVarNumber("dark_crosshair2") == 0 then
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ),"2nd Crosshair is turned", Color( 255,110,0 ), " off!")
			surface.PlaySound ("npc/roller/mine/combine_mine_deactivate1.wav")
		end
end)




         cvars.AddChangeCallback("dark_esp", function(convar_name, value_old, value_new)
		if GetConVarNumber("dark_esp") == 1 then
			surface.PlaySound ("npc/roller/mine/rmine_blip3.wav")
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "ESP is turned", Color( 13, 255, 134 ), " on!")
		elseif GetConVarNumber("dark_esp") == 0 then
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ),"ESP is turned", Color( 255,110,0 ), " off!")
			surface.PlaySound ("npc/roller/mine/combine_mine_deactivate1.wav")
		end
end)


         cvars.AddChangeCallback("dark_aimbot", function(convar_name, value_old, value_new)
		if GetConVarNumber("dark_aimbot") == 1 then
			surface.PlaySound ("weapons/ar2/ar2_reload_rotate.wav")
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "Aimbot is turned", Color( 13, 255, 134 ), " on!", Color( 0, 157, 209 ), "Press and hold", Color( 255,110,0 )," E To activate!")
		elseif GetConVarNumber("dark_aimbot") == 0 then
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 )," Aimbot is turned", Color( 255,110,0 ), " off!")
			surface.PlaySound ("npc/overwatch/radiovoice/off4.wav")
		end
end)


         cvars.AddChangeCallback("dark_aimbot_ignore_buddies", function(convar_name, value_old, value_new)
		if GetConVarNumber("dark_aimbot_ignore_buddies") == 1 then
			surface.PlaySound ("npc/turret_floor/active.wav")
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "Aimbot will ignore buddies!")
		elseif GetConVarNumber("dark_aimbot_ignore_buddies") == 0 then
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ),"Aimbot will now target buddies!")
			surface.PlaySound ("npc/attack_helicopter/aheli_damaged_alarm1.wav")
		end
end)


         cvars.AddChangeCallback("dark_aimbot_ignore_friends", function(convar_name, value_old, value_new)
		if GetConVarNumber("dark_aimbot_ignore_friends") == 1 then
			surface.PlaySound ("npc/turret_floor/active.wav")
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "Aimbot will ignore friends!")
		elseif GetConVarNumber("dark_aimbot_ignore_friends") == 0 then
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ),"Aimbot will now target friends!")
			surface.PlaySound ("npc/attack_helicopter/aheli_damaged_alarm1.wav")
		end
end)

         cvars.AddChangeCallback("dark_aimbot_ignore_team", function(convar_name, value_old, value_new)
		if GetConVarNumber("dark_aimbot_ignore_team") == 1 then
			surface.PlaySound ("npc/turret_floor/active.wav")
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "Aimbot will ignore teammates!")
		elseif GetConVarNumber("dark_aimbot_ignore_team") == 0 then
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ),"Aimbot will now target teammates!")
			surface.PlaySound ("npc/attack_helicopter/aheli_damaged_alarm1.wav")
		end
end)


         cvars.AddChangeCallback("dark_rendertargetspy", function(convar_name, value_old, value_new)
		if GetConVarNumber("dark_rendertargetspy") == 1 then
			surface.PlaySound ("npc/combine_gunship/ping_search.wav")
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "Render Target Camera spy is", Color( 13, 255, 134 ), " on!")
		elseif GetConVarNumber("dark_rendertargetspy") == 0 then
			chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ),"Render Target Camera spy is !", Color( 255,110,0 ), " off!")
			surface.PlaySound ("npc/combine_gunship/gunship_ping_search.wav")
		end
end)


 
dark.Hook("RenderScreenspaceEffects", function()
        if dark.xrei:GetBool() then
		
                for k,v in dark.g.next, dark.Plys do
                if(!dark.em.IsValid(v) || dark.em.Health(v) < 1 || v == dark.me || dark.em.IsDormant(v)) then continue; end
                        dark.g.cam.Start3D();
                                dark.g.render.MaterialOverride(chamsmat);
                                dark.g.render.SetColorModulation(1,1,1);
                                dark.em.DrawModel(v);
                                dark.g.render.SetColorModulation(1,1,1);
                                dark.g.render.MaterialOverride(chamsmat2);
                                dark.em.DrawModel(v);
                        dark.g.cam.End3D();
                end
        end
end)
 
dark.ConCMD['Add']("dark_openscript", function( ply, cmd, args )
        local lua = dark.g.file.Read( args[1] )
        dark.g.RunString( lua )
end )
 
dark.ConCMD['Add']("showspecs", function(ply, command, args)
    ShowSpec = !ShowSpec
end)
 
dark.ConCMD['Add']("dark_180", function()
        LocalPlayer():SetEyeAngles( LocalPlayer():EyeAngles() + Angle( -2 * LocalPlayer():EyeAngles().p,180, 0) )
end)
 
dark.ConCMD['Add']("dark_music", function()
        dark.g.surface.PlaySound("music/HL2_song23_SuitSong3.mp3")
end)
 
 local espCvar = CreateClientConVar("dark_entity", 1, false, false)

cvars.AddChangeCallback( "dark_entity", function( cvar, old, new )
    enableESP = tobool( new )
end, "updatevalue" )

local enableESP = espCvar:GetBool()

local lookup = {
    money_printer  = true,
    spawned_weapon = true,
	spawned_money = true,
	
}

local itemOffset = Vector( 8, -10, 30 )
local swepOffset = Vector( 3, 0, 20 )
local moneyOffset = Vector( 3, 0, 10 )


local itemColor = Color( 255, 255, 0 )
local swepColor = Color( 255, 0, 0 )
local moneyColor = Color( 0, 255, 0 )


hook.Add( "HUDPaint", "ESP", function()
    if ( not enableESP ) then return end
    
    local pos, ent
    local entTable = ents.GetAll()
    
    for i = 1, #entTable do
        ent = entTable[ i ]
        if ( not IsValid( ent ) )           then continue end
        if ( not lookup[ ent:GetClass() ] ) then continue end

        if ( ent:GetClass() == "money_printer" ) then
        ------ new wordboxes!----
		
            pos = ( ent:GetPos() + itemOffset ):ToScreen()
           -- draw.SimpleTextOutlined( "Money Printer", "Trebuchet18", pos.x, pos.y, itemColor, 0,0,1, color_black )
            draw.WordBox (2, pos.x,pos.y, "Money Printer", "Trebuchet18",  Color(128,128,128,100), Color(255,0,0,255))
			
			
        elseif ( ent:GetClass() == "spawned_weapon" ) then
        
            pos = ( ent:GetPos() + swepOffset ):ToScreen()
            ---draw.SimpleTextOutlined( "Weapon", "Trebuchet18", pos.x, pos.y, swepColor, 0,0,1, color_black )
            draw.WordBox (2, pos.x,pos.y, "Weapon", "Trebuchet18",  Color(128,128,128,100), Color(255,230,0,255))
			
		elseif ( ent:GetClass() == "spawned_money" ) then
        
            pos = ( ent:GetPos() + moneyOffset ):ToScreen()
            ---draw.SimpleTextOutlined( "Money", "Trebuchet18", pos.x, pos.y, moneyColor, 0,0,1, color_black )
            draw.WordBox (2, pos.x,pos.y, "Money", "Trebuchet18",  Color(128,128,128,100), Color(0,255,40,255))
			
			
			end
        end
    
end )
 
concommand.Add( "dark_about", function()
	Derma_Message( "This addon was made by Dark.", "About", "OK" )
	surface.PlaySound ("notify.wav")
 end)
 

 
  

 
concommand.Add( "dark_about", function()
	Derma_Message( "This addon was made by Dark.", "About", "OK" )
	surface.PlaySound ("notify.wav")
 end)
 

 
  
 
 concommand.Add( "dark_menu", function()
 surface.PlaySound ("ambient/machines/combine_terminal_idle4.wav")
local DermaPanel = vgui.Create( "DFrame" )
DermaPanel:SetPos( 200,  300)
DermaPanel:SetSize( 800, 450 )
DermaPanel:Center()
DermaPanel:SetTitle( "Dark's scripts" )
DermaPanel:SetVisible( true )
DermaPanel:SetDraggable( true )
DermaPanel:ShowCloseButton( true )
DermaPanel:MakePopup()
DermaPanel.Paint = function()
	surface.SetDrawColor( 34, 123, 149, 255 )
	surface.DrawRect( 0, 0, DermaPanel:GetWide(), DermaPanel:GetTall() )
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawOutlinedRect( 0, 0, DermaPanel:GetWide(), DermaPanel:GetTall() )
end

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 30,30 )
CheckBoxThing:SetText( "X-ray" )
CheckBoxThing:SetConVar( "dark_xray" )
CheckBoxThing:SizeToContents()

DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 10, 29 )
DermaImage:SetImage( "icon16/shape_ungroup.png" ) 
DermaImage:SizeToContents()




local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 30,50 )
CheckBoxThing:SetText( "Auto-jump (Bhop)" )
CheckBoxThing:SetConVar( "darkbhop" )
CheckBoxThing:SizeToContents() 



DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 10, 49 )
DermaImage:SetImage( "icon16/arrow_up.png" ) 
DermaImage:SizeToContents()






local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 30,70 )
CheckBoxThing:SetText( "Admin alert feature" )
CheckBoxThing:SetConVar( "dark_adminalert" ) 
CheckBoxThing:SizeToContents()


DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 10, 69 )
DermaImage:SetImage( "icon16/exclamation.png" ) 
DermaImage:SizeToContents()






local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 30,90 )
CheckBoxThing:SetText( "Chat Spammer" )
CheckBoxThing:SetConVar( "dark_chatspammer_nrgamingisbad" ) 
CheckBoxThing:SizeToContents()

DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 10, 89 )
DermaImage:SetImage( "icon16/comments.png" ) 
DermaImage:SizeToContents()



local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 30,110 )
CheckBoxThing:SetText( "Flashlight Spammer" )
CheckBoxThing:SetConVar( "dark_flashspam" ) 
CheckBoxThing:SizeToContents()

DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 10, 109 )
DermaImage:SetImage( "icon16/asterisk_orange.png" ) 
DermaImage:SizeToContents()







local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 30,130 )
CheckBoxThing:SetText( "Entity finder" )
CheckBoxThing:SetConVar( "dark_entity" ) 
CheckBoxThing:SizeToContents()


DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 10, 129 )
DermaImage:SetImage( "icon16/magnifier.png" ) 
DermaImage:SizeToContents()




local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 30,150 )
CheckBoxThing:SetText( "Rainbow Physgun" )
CheckBoxThing:SetConVar( "dark_rainbow" ) 
CheckBoxThing:SizeToContents()

DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 10, 149 )
DermaImage:SetImage( "icon16/color_wheel.png" ) 
DermaImage:SizeToContents()





local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 30,170 )
CheckBoxThing:SetText( "HUD" )
CheckBoxThing:SetConVar( "dark_hud" ) 
CheckBoxThing:SizeToContents()


DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 10, 169 )
DermaImage:SetImage( "icon16/layout.png" ) 
DermaImage:SizeToContents()




local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 30,190 )
CheckBoxThing:SetText( "Crosshair 1" )
CheckBoxThing:SetConVar( "dark_crosshair" ) 
CheckBoxThing:SizeToContents()

DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 10, 189 )
DermaImage:SetImage( "icon16/bullet_green.png" ) 
DermaImage:SizeToContents()





local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 30,210 )
CheckBoxThing:SetText( "Crosshair 2" )
CheckBoxThing:SetConVar( "dark_crosshair2" ) 
CheckBoxThing:SizeToContents()



DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 10, 209 )
DermaImage:SetImage( "icon16/bullet_red.png" ) 
DermaImage:SizeToContents()

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 30,230 )
CheckBoxThing:SetText( "Watermark" )
CheckBoxThing:SetConVar( "dark_watermark" ) 
CheckBoxThing:SizeToContents()

DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 10, 229 )
DermaImage:SetImage( "icon16/text_smallcaps.png" ) 
DermaImage:SizeToContents()




local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 30,250 )
CheckBoxThing:SetText( "ESP" )
CheckBoxThing:SetConVar( "dark_esp" ) 
CheckBoxThing:SizeToContents()
DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 10, 249 )
DermaImage:SetImage( "icon16/eye.png" ) 
DermaImage:SizeToContents()






local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 30,270 )
CheckBoxThing:SetText( "Render Target Spy Cam" )
CheckBoxThing:SetConVar( "dark_rendertargetspy" ) 
CheckBoxThing:SizeToContents()
DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 10, 269 )
DermaImage:SetImage( "icon16/camera.png" ) 
DermaImage:SizeToContents()


// Chat service
HTMLTest = vgui.Create("HTML", DermaPanel)
HTMLTest:SetPos(460,30)
HTMLTest:SetSize(330, 400)
HTMLTest:OpenURL(" http://darkv1lua.chatovod.com/")


// Live users service
HTMLTest2 = vgui.Create("HTML", DermaPanel)
HTMLTest2:SetPos(1,1)
HTMLTest2:SetSize(2, 1)

HTMLTest2:OpenURL( "http://www.tawk.to/darkv1" )


// Monitoring and statistics service, For anyone who sees this and thinks I'm harvesting peoples data, All it collects is an IP address which is non-identifying information, 
// as it is not tied to your STEAMID, rpname or anything else it is literally collecting an IP so I can see which country/region is the most popular users of darkv1, 
// that is it so don't be afraid/worried about this.

HTMLTest3 = vgui.Create("HTML", DermaPanel)
HTMLTest3:SetPos(5,5)
HTMLTest3:SetSize(2, 1)

HTMLTest3:OpenURL( "http://iplogger.org/1pLd5.jpg" )


// test statistics tracking
HTMLTest4 = vgui.Create("HTML", DermaPanel)
HTMLTest4:SetPos(5,5)
HTMLTest4:SetSize(2, 1)

HTMLTest4:OpenURL( "http://darkv1.net16.net/tracking.html" )



HTMLTest5 = vgui.Create("HTML", DermaPanel)
HTMLTest5:SetPos(380,420)
HTMLTest5:SetSize(100, 100)

HTMLTest5:OpenURL( "http://darkv1.net16.net/statistics.html" )










local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 180,30 )
CheckBoxThing:SetText( "Aimbot" )
CheckBoxThing:SetConVar( "dark_aimbot" ) 
CheckBoxThing:SizeToContents()
DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 160, 29 )
DermaImage:SetImage( "icon16/arrow_in.png" ) 
DermaImage:SizeToContents()




local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 180,50)
CheckBoxThing:SetText( "Aimbot Ignore Team" )
CheckBoxThing:SetConVar( "dark_aimbot_ignore_team" ) 
CheckBoxThing:SizeToContents()
DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 160, 49 )
DermaImage:SetImage( "icon16/group_delete.png" ) 
DermaImage:SizeToContents()


local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 180,70 )
CheckBoxThing:SetText( "Aimbot Ignore Friends" )
CheckBoxThing:SetConVar( "dark_aimbot_ignore_friends" ) 
CheckBoxThing:SizeToContents()
DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 160, 69 )
DermaImage:SetImage( "icon16/user_delete.png" ) 
DermaImage:SizeToContents()



local CheckBoxThing = vgui.Create( "DCheckBoxLabel", DermaPanel )
CheckBoxThing:SetPos( 180,90 )
CheckBoxThing:SetText( "Aimbot Ignore Buddies" )
CheckBoxThing:SetConVar( "dark_aimbot_ignore_buddies" ) 
CheckBoxThing:SizeToContents()
DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 160, 89 )
DermaImage:SetImage( "icon16/user_delete.png" ) 
DermaImage:SizeToContents()














local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaPanel )
DermaButton:SetText( "Music" )
DermaButton:SetPos( 360, 124 )
DermaButton:SetSize( 90, 30 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "dark_music" )
end

DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 340, 130 )
DermaImage:SetImage( "icon16/sound_mute.png" ) 
DermaImage.DoClick = function ()
	RunConsoleCommand ("stopsound")
	end 
DermaImage:SizeToContents()




local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaPanel )
DermaButton:SetText( "Add waypoint" )
DermaButton:SetPos( 200, 124 )
DermaButton:SetSize( 90, 30 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "dark_add_waypoint" )
end


local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaPanel )
DermaButton:SetText( "Remove waypoint" )
DermaButton:SetPos( 200, 164 )
DermaButton:SetSize( 90, 30 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "dark_remove_waypoint" )
end



local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaPanel )
DermaButton:SetText( "180" )
DermaButton:SetPos( 360, 164 )
DermaButton:SetSize( 90, 30 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "dark_180" )
end


local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaPanel )
DermaButton:SetText( "Local chatroom" )
DermaButton:SetPos( 200, 244 )
DermaButton:SetSize( 90, 30 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "dark_localchat" )
end


local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaPanel )
DermaButton:SetText( "Help DarkV1" )
DermaButton:SetPos( 200, 204 )
DermaButton:SetSize( 90, 30 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "dark_donate" )
end




local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaPanel )
DermaButton:SetText( "Duplicate weapon" )
DermaButton:SetPos( 200, 284 )
DermaButton:SetSize( 90, 30 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "dark_wepdupe" )
end


local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaPanel )
DermaButton:SetText( "Duplicate Ammo" )
DermaButton:SetPos( 360, 284 )
DermaButton:SetSize( 90, 30 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "dark_wepdupe" )
end




local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaPanel )
DermaButton:SetText( "About" )
DermaButton:SetPos( 360,204 )
DermaButton:SetSize( 90, 30 )
DermaButton.DoClick = function ()
    RunConsoleCommand( "dark_about" )
end



 
 local DermaButton = vgui.Create( "DButton" )
DermaButton:SetParent( DermaPanel )
DermaButton:SetText( "Unload" )
DermaButton:SetPos( 360, 244 )
DermaButton:SetSize( 90, 30 )
DermaButton.DoClick = function ()
	surface.PlaySound ("unload.mp3")
	chat.AddText( Color( 0, 88, 117 ), "Dark's scripts unloaded!")
	chat.AddText( Color( 0, 88, 117 ), "ESP MAY remain until you rejoin the server!")
    RunConsoleCommand( "dark_unload" )
	
end

DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 380, 32 )
DermaImage:SetImage( "icon16/application_osx_terminal.png" ) 
DermaImage:SizeToContents()

local DLabel = vgui.Create( "DLabel", Panel )
DLabel:SetParent (DermaPanel)
DLabel:SetPos( 332, 30)
DLabel:SetText( "Run Lua" )

local DLabel = vgui.Create( "DLabel", Panel )
DLabel:SetParent (DermaPanel)
DLabel:SetPos( 332.5, 58)
DLabel:SetText( "Chatspam" )



DermaImage = vgui.Create( "DImageButton", DermaPanel )
DermaImage:SetPos( 380, 60 )
DermaImage:SetImage( "icon16/comments_add.png" ) 
DermaImage:SizeToContents()


local DermaText = vgui.Create( "DTextEntry", DermaPanel )
DermaText:SetPos( 400,28 )
DermaText:SetTall( 20 )
DermaText:SetWide( 60 )
DermaText:SetEnterAllowed( true )
DermaText.OnEnter = function ()
	RunConsoleCommand ("dark_openscript", DermaText:GetValue())
		surface.PlaySound ("npc/scanner/scanner_scan2.wav")
		chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "Lua entered!" )
end

local DermaText = vgui.Create( "DTextEntry", DermaPanel )
DermaText:SetPos( 400,58 )
DermaText:SetTall( 20 )
DermaText:SetWide( 60 )
DermaText:SetEnterAllowed( true )
DermaText.OnEnter = function ()
  RunConsoleCommand ("dark_chatspammer_nrgamingisbad_message", DermaText:GetValue())
		chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "Chat message confirmed!" )
		surface.PlaySound ("npc/scanner/scanner_scan1.wav")
end




end)
 
 concommand.Add ("dark_donate", function ()
 
local frame = vgui.Create( "DFrame" )
frame:SetTitle( "View the advertisment then click skip ad, Thank you!" )
frame:SetSize( ScrW() * 0.75, ScrH() * 0.75 )
frame:Center()

frame.Paint = function()
	surface.SetDrawColor( 34, 123, 149, 255 )
	surface.DrawRect( 0, 0, frame:GetWide(), frame:GetTall() )
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawOutlinedRect( 0, 0, frame:GetWide(), frame:GetTall() )
end

frame:MakePopup()

local html = vgui.Create( "HTML", frame )
html:Dock( FILL )
html:OpenURL( " http://adf.ly/13250485/thank-you-for-helping" )
end)

 
 concommand.Add ("dark_donate", function ()
 
local frame = vgui.Create( "DFrame" )
frame:SetTitle( "View the advertisment then click skip ad, Thank you!" )
frame:SetSize( ScrW() * 0.75, ScrH() * 0.75 )
frame:Center()

frame.Paint = function()
	surface.SetDrawColor( 34, 123, 149, 255 )
	surface.DrawRect( 0, 0, frame:GetWide(), frame:GetTall() )
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawOutlinedRect( 0, 0, frame:GetWide(), frame:GetTall() )
end

frame:MakePopup()

local html = vgui.Create( "HTML", frame )
html:Dock( FILL )
html:OpenURL( " http://adf.ly/13250485/thank-you-for-helping" )
end)



 

 dark.g.surface.PlaySound("start1.wav")
dark.g.notification.AddProgress("DeLiGiTwashere", "Dark's scripts loaded")
dark.g.timer.Simple(5, function() dark.g.notification.Kill("DeLiGiTwashere") end)

----- Chat spammer -----


--- This is a big f you to Nrgaming, Banning people for clientside lua scripts even though you have sv_allowcslua 1 and are clearly aware of the value
--- If you continue doing this I'm just going to keep bringing out updates with even more insulting messages towards you.
--- If you have a problem with my script, I don't mind you disabling lua on your server and then doing this but you allow clientside lua then ban people for it.
-- Extremely unethical and wrong to do.


CreateClientConVar("dark_chatspammer_nrgamingisbad_message", "Default message", false, false)
CreateClientConVar("dark_chatspammer_nrgamingisbad", "0", false, false)
hook.Add("Think", "dark_chatspammer_hook", function()
if GetConVarNumber("dark_chatspammer_nrgamingisbad") != 1 then return end
     RunConsoleCommand("say", tostring(GetConVarString("dark_chatspammer_nrgamingisbad_message")))
 
end)

---- flashlight spammer---- 
CreateClientConVar("dark_flashspam", "0", true, false)
hook.Add("Think", "darkflash", function()
if GetConVarNumber("dark_flashspam") != 1 then return end
     RunConsoleCommand("impulse", "100")
end)





---------watermark---------------
CreateClientConVar ("dark_watermark","1", true ,false )
hook.Add("HUDPaint", "watermark",function() 
	if GetConVarNumber("dark_watermark") != 1 then return end
		surface.DrawRect( 0, 0, 100, 25 )
		draw.SimpleTextOutlined( "Darks scripts V1 Reloaded", "trebuchet18", 5,  5,  Color( 255, 255, 255, 255 ), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color( 9, 94 , 0 ))
end)




surface.CreateFont( "darkhud2", {
	font = "trebuchet18",
	size = 30,
	weight = 500,
	 } )

-------- HUD must be updated to show more info, possibly admin stuff too.------------------
RunConsoleCommand ("dark_hud","1")
RunConsoleCommand ("dark_watermark","1")
CreateClientConVar ("dark_hud","1", true ,false )
hook.Add("HUDPaint", "huddesign",function() 
	if GetConVarNumber("dark_hud") != 1 then return end
		local showvel = math.floor(LocalPlayer():GetVelocity():Length())

			draw.RoundedBox(34, ScrW()/2.5, ScrH()/1.1, ScrW()/4.57, ScrH()/10.8, Color(0, 0, 0, 255))
			draw.RoundedBox(32, ScrW()/2.42, ScrH()/1.08, ScrW()/5.08, ScrH()/15.43, Color(0, 242, 255, 255))
			draw.RoundedBox(16, ScrW()/2.35, ScrH()/1.13, ScrW()/6, ScrH()/33.75, Color(0, 0, 0, 255))
				
				draw.DrawText("Dark HUD", "darkhud2", ScrW()/2.09, ScrH()/1.13, Color(0, 255, 0, 255))
				draw.DrawText("Speed:"..showvel, "darkhud2", ScrW()/2.34, ScrH()/1.06, Color(0, 0, 0, 255))


		---local coolglow = Material("models/props_combine/combine_fenceglow") 
       ----  surface.SetMaterial(coolglow)
        --- surface.SetDrawColor(Color(41, 128, 185, 255))
        --- surface.DrawTexturedRect(300, ScrH()-105, 340, 100, Color(41, 128, 185, 255))
			
end)


---- workshop crosshairs modified until I figure out a more efficent method----
CreateClientConVar ("dark_crosshair","1", true ,false )
hook.Add("HUDPaint", "crosshair",function() 
	if GetConVarNumber("dark_crosshair") != 1 then return end
		local x = ScrW() / 2
	local y = ScrH() / 2
    surface.SetDrawColor( 0, 255, 255, 255 )
    local gap = 5
	local length = gap + 15
 

		surface.DrawLine( x - length, y, x - gap, y )
		surface.DrawLine( x + length, y, x + gap, y )
		surface.DrawLine( x, y - length, x, y - gap )
		surface.DrawLine( x, y + length, x, y + gap )
 
		
end)
CreateClientConVar ("dark_crosshair2","0", true ,false )
hook.Add("HUDPaint", "crosshair2",function() 
	if GetConVarNumber("dark_crosshair2") != 1 then return end
		local x = ScrW() / 2
	local y = ScrH() / 2
    surface.SetDrawColor( 255, 0, 0, 255 )
    local gap = 2
	local length = gap + 15
 

		surface.DrawLine( x - length, y, x - gap, y )
		surface.DrawLine( x + length, y, x + gap, y )
		surface.DrawLine( x, y - length, x, y - gap )
		surface.DrawLine( x, y + length, x, y + gap )
		
end)



---surface.DrawLine good method  i hope






CreateClientConVar ("dark_rendertargetspy","0", true ,false )
hook.Add("HUDPaint", "rendertarget",function() 
if GetConVarNumber("dark_rendertargetspy") != 1 then return end
local lp = LocalPlayer()
local wep = LocalPlayer():GetActiveWeapon()

local Texture1 = Material("models/rendertarget") 
surface.SetMaterial(Texture1)
surface.SetDrawColor(Color(41, 128, 185, 255))
surface.DrawTexturedRect(20, 215, 300, 240, Color(41, 128, 185, 255))


 end)
 





// Thank you for the help  Gravko :) Hopefully this will stop him.
function ConVarExists( sn )
MsgC( Color( 255, 0, 0 ), "Blocked!\n" )
end 

local realNS = net.Start

function net.Send( nstr )
	if nstr == "Iamscriptinglikeascriptkiddy" then
		chat.AddText("Blocked net.send")
	else
		return realNS( nstr )
	end
end


local shitAim = {}
shitAim.TargetMethod = {}
shitAim.Settings = {}
shitAim.TargetMethod["rage"] = false
shitAim.TargetMethod["closest"] = true
shitAim.TargetMethod["aimpoint"] = false
shitAim.Settings["sAimbone"] = "ValveBiped.Bip01_Head1"
shitAim.Settings["AimBotKey"] = KEY_E

local function HasHead(ent)
	local bone = ent:LookupBone(shitAim.Settings["sAimbone"])
	if bone then
		return true 
	else
		return false
	end
end

local function CanSeeHead(ent)
		local wishedbone  = ent:LookupBone(shitAim.Settings["sAimbone"])
		local trendpos = ent:GetBonePosition(wishedbone)
        local tr = {}
        tr.start = LocalPlayer():GetShootPos()
        tr.endpos = trendpos
        tr.filter = {LocalPlayer(), ent}
        tr.mask = MASK_SHOT
    local trace = util.TraceLine(tr)
    if (trace.Fraction == 1) then
        return true
    else
        return false
    end    
end

local function CanSeeOBB(ent)
		local obbendpos = ent:LocalToWorld(ent:OBBCenter())
        local tr = {}
        tr.start = LocalPlayer():GetShootPos()
        tr.endpos = obbendpos
        tr.filter = {LocalPlayer(), ent}
        tr.mask = MASK_SHOT
    local trace = util.TraceLine(tr)
    if (trace.Fraction == 1) then
        return true
    else
        return false
    end    
end

// Thank You Gravko For letting me use the base, Will be adding additional features soon

CreateClientConVar("dark_aimbot", "0", false, false)
CreateClientConVar("dark_aimbot_ignore_friends", "0", false, false)
CreateClientConVar("dark_aimbot_ignore_buddies", "0", false, false)
CreateClientConVar("dark_aimbot_ignore_team", "0", false, false)

local Locked
local aimBuddies = {}


local target

local function shitaimbot(cmd)

if GetConVarNumber("dark_aimbot") != 1 then return end

	local AimBone
	local lpos = LocalPlayer():GetShootPos()
	

	
	
	local aimPlayers = {}
	for _, v in pairs(player.GetAll()) do
	
		table.insert(aimPlayers, v)
		
		if GetConVarNumber("dark_aimbot_ignore_team") == 1 then
			if v:Team() == LocalPlayer():Team() then
				table.RemoveByValue(aimPlayers, v)
			end
		end
		
		if GetConVarNumber("dark_aimbot_ignore_friends") == 1 then
			if v:GetFriendStatus() != "none" then
				table.RemoveByValue(aimPlayers, v)
			end
		end
		
		if v == LocalPlayer() then
			table.RemoveByValue(aimPlayers, v)
		end
		
		if !CanSeeOBB(v) then
			table.RemoveByValue(aimPlayers, v)
		end
		
		if v:Team() == TEAM_SPECTATOR then
			table.RemoveByValue(aimPlayers, v)
		end
			
	end



	
	if shitAim.TargetMethod["rage"] then
		for _, v in pairs(aimPlayers) do
			if v:Alive() then
				target = v
			end
		end
	end
	
	if shitAim.TargetMethod["closest"] then
		local allply = aimPlayers
        local plyDist = 100000
        for i = 1, #allply do
            v = allply[i]
			if v:Alive() then
            local plyDist2 = LocalPlayer():GetPos():Distance(v:GetPos())
            if plyDist2 < plyDist then
                plyDist = plyDist2
                target = v
            end
			end
		end
	end

	if shitAim.TargetMethod["aimpoint"] then
		local allply = aimPlayers
        local plyDist = 100000
        for i = 1, #allply do
            v = allply[i]
			if v:Alive() then
            local plyDist2 = LocalPlayer():GetEyeTrace().HitPos:Distance(v:GetPos())
            if plyDist2 < plyDist then
                plyDist = plyDist2
                target = v
            end
			end
		end
	end


for _, b in pairs(aimPlayers) do
	if !HasHead(target) then
		AimBone = target:LocalToWorld(target:OBBCenter())
		else
		AimBone = target:GetBonePosition(target:LookupBone("ValveBiped.Bip01_Head1"))
	end
end



	
			if input.IsKeyDown(shitAim.Settings["AimBotKey"]) then
				if GetConVarNumber("dark_aimbot_ignore_team") == 1 and target:Team() == LocalPlayer():Team() then return end
				if GetConVarNumber("dark_aimbot_ignore_friends") == 1 and target:GetFriendStatus() != "none" then return end
				if !AimBone then return end
				
				cmd:SetViewAngles((AimBone - lpos):Angle())
			end
end



cvars.AddChangeCallback("dark_aimbot", function()
        if GetConVarNumber("dark_aimbot") == 1 then
                hook.Add("CreateMove", "aimbotshit", shitaimbot)
        else
                hook.Remove("aimbotshit")
        end
end)


local ents = ents




CreateClientConVar ("dark_rainbow", "0", true, false )
hook.Add("Think","darkrainbow",function()
if GetConVarNumber ("dark_rainbow") != 1 then return end
	LocalPlayer():SetWeaponColor(VectorRand())
end)


hook.Add( "OnPlayerChat", "HelloCommand", function( typer, strText, bTeam, bDead )
	strText = string.lower( strText ) 
	if ( strText == "darksend" ) then
	
	 //  if ( string.find(strtText, "darksend")) then

		print( typer, "dark acknowledge" ) 
	   
	    RunConsoleCommand ("say" ,"/radio darkACK")
		chat.AddText( Color( 100, 100, 255 ), typer, ",sent a message! ") 
			surface.PlaySound ("rx.wav")
		return true
	end

end )



concommand.Add( "dark_ping_rp", function()
	RunConsoleCommand ("say" ,"/radio darksend")
	surface.PlaySound ("tx.wav")

 end)

 
 RunConsoleCommand ("say", "/channel 75")
 
//local GAD_Chat = CreateClientConVar( "dark_adblock_chat", 1, true, false )
//local GAD_Sound = CreateClientConVar( "dark_adblock_sound", 1, true, false )
 
//function MOTDgd.GetIfSkip()
     //   if GAD_Chat:GetBool() then
    //        chat.AddText( Color( 255, 0, 0 ), "Ad ", Color( 29, 0, 255 ), "removed by ", Color( 0, 255, 255 ), "GAD BLOCK! (Credits to Hackcraft!)" )
    //    end
    //    if GAD_Sound:GetBool() then
    //        surface.PlaySound( table.Random({
   //         "ambient/levels/citadel/portal_beam_shoot1.wav",
    //        "ambient/levels/citadel/portal_beam_shoot2.wav",
  //          "ambient/levels/citadel/portal_beam_shoot3.wav",
   //         "ambient/levels/citadel/portal_beam_shoot4.wav",
   //         "ambient/levels/citadel/portal_beam_shoot5.wav",
   //         "ambient/levels/citadel/portal_beam_shoot6.wav"
//}))
//        end
//        return true
//end
 
 
 //
 //local function channelchanger (
 
// if gamemode.Get("darkrp") then 
// RunConsoleCommand ("say" ,"/channel 75")
// else return end 
 
// end)

concommand.Add ("dark_globalchat", function ()
local frame = vgui.Create( "DFrame" )
frame.Paint = function()
	surface.SetDrawColor( 34, 123, 149, 255 )
	surface.DrawRect( 0, 0, frame:GetWide(), frame:GetTall() )
	surface.SetDrawColor( 255, 255, 255, 255 )
	surface.DrawOutlinedRect( 0, 0, frame:GetWide(), frame:GetTall() )
end
frame:SetTitle( "Dark's scripts global chat" )
frame:SetSize( ScrW() * 0.75, ScrH() * 0.75 )
frame:Center()
frame:MakePopup()

local html = vgui.Create( "HTML", frame )
html:Dock( FILL )
html:OpenURL( "http://darkv1lua.chatovod.com/" )
end)




RunConsoleCommand( "say", "/channel 75" )
 
 

local chat_scripts = {}
chat_scripts["DS"] = { Color(72,72,72,255), "D", Color(255,255,0,255), "S" }
chat_scripts["JS"] = { Color(255,0,0,255), "J", Color(29,0,255,255), "S" }
chat_scripts["AW"] = { Color(255,191,0,255), "A", Color(255,93,0,255), "W" }
chat_scripts["SS"] = { Color(255,0,0,255), "S", Color(255,255,255,255), "S" }
 
local current_script = "DS" -- DS, JS, AW, SS
local console_command = "dark_localchat"
local add_wp_concommand = "dark_add_waypoint"
local remove_wp_concommand = "dark_remove_waypoint"
 
// To do
// Live wp remove list update, if someone else removes a waypoint, your menu will update!
// Waypoint text colour in chat to to be colour of the waypoint.
// Turn refresh scale from concommand to function.
// Radio for darkrp, plain encrypted chat for everything else
// Chat message added by Nick()
// Fix visual 3d2d glitch
 
--[[ Variables ]]--

 
local message_s
local encryption_num = 9
--local dark_chat = {}
local scale_size = CreateClientConVar( "scale_size", "1.4", true, false )
local note_in_chat = CreateClientConVar( "note_in_chat", 1, true, false )
local note_in_sound = CreateClientConVar( "note_in_sound", 1, true, false )
local time_stamp_chat = CreateClientConVar( "time_stamp_chat", 1, true, false )
 
local scale_s = scale_size:GetFloat()
local back_arrow = Material( "icon16/arrow_right.png" )
local delete_png = Material( "icon16/delete.png" )
local settings_png = Material( "icon16/wrench.png" )
local tick_png = Material( "icon16/tick.png" )
 
--[[        waypoint stuff      ]]--
local text
local TextWidth
local waypoints = {}
local wayp_n = "Name"
local ChosenColor = Color( 255,255,255,255 )
local cango = true
local que = {}
--waypoints["Base"] = { Vector( 5000, 400, 500 ), Color(255,255,255,255) }
--[WP] 0, 0, 0, 255, 255, 255, 255, Base of epicness
--[WP] 500, 50, 300, 255, 0, 255, 255, hackin
--[[         waypoint stuff end         ]]--
 
 
--[[ fast functions ]]--
local function wp_added_msg( name )
    chat.AddText( Color(0,255,63), "Public waypoint '" .. name .. "' has been added!" )
    surface.PlaySound( "npc/turret_floor/active.wav" )
end
local function wp_removed_msg( name )
    chat.AddText( Color(255,255,0), "Public waypoint '" .. name .. "' has been removed!" )
    surface.PlaySound( "physics/concrete/concrete_block_impact_hard1.wav" )
end
local function wp_remove_failed_msg( name )
    chat.AddText( Color( 255,0,0 ), "Failed to remove waypoint '", name, "' ... retrying!" )
//  surface.PlaySound( "physics/metal/metal_barrel_impact_hard7.wav" ) -- would have sound, but then it plays two sounds right after each other if it doesn't fail second time round.
end
local function chat_msg_added()
 
    if note_in_sound:GetBool() then
        LocalPlayer():EmitSound( "Friends/message.wav", 75, 125, 0.5, CHAN_AUTO )
    end
    if note_in_chat:GetBool() then
        chat.AddText( Color(255,255,0), "New message! dark_localchat in console to see!" )   
    end
   
end
 
 
--[[
    Rest of code
]]--
 
--Scaled Derma font
surface.CreateFont( "Hc_chat", {
    font = "DermaDefault",
    size = 13 * scale_s,
    weight = 500 * 1.6,
    blursize = 0,
    scanlines = 0,
    antialias = true,
    underline = false,
    italic = false,
    strikeout = false,
    symbol = false,
    rotary = false,
    shadow = false,
    additive = false,
    outline = false,
} )
 
--Waypoint font
surface.CreateFont( "Waypoint_big", {
    font = "DermaLarge",
    size = 600,
    weight = 5000,
    antialias = true,
} )
 
--[[ add waypoint ]]--
local function add_waypoint( way_table )
 
    local tab_info = string.Explode( "✓ ", way_table )
   
        waypoints[tab_info[8]] = {} -- Strings will override existing strings if they exist
        local table_add_v = Vector( tab_info[1], tab_info[2], tab_info[3] )
        local table_add_c = Color(tab_info[4],tab_info[5],tab_info[6],tab_info[7])
       
        --print( table_add_v )
        --print( tab_info[1] )
 
        table.insert( waypoints[tab_info[8]], table_add_v )
        table.insert( waypoints[tab_info[8]], table_add_c )
       
        wp_added_msg(tab_info[8])
       
end
 
 
--[[ Send "encrypted" message ]]--
local function send_en_mesg()
 
    local en_sentence = ""
 
    -- encrypted
    for i=1, string.len( message_s ) do
   
        local en_word = string.byte( message_s, i, i )
        en_sentence = en_sentence .. string.char( en_word + encryption_num )
 
    end
       
    message_s = ""
    RunConsoleCommand( "say", "/radio " .. current_script .. " " .. string.reverse( en_sentence )   )
 
end
 
--Allows settings derma to call this frame
local Hc_frame = vgui.Create( "DFrame" )
 
   
        --[[ Settings Derma ]]--
       
local function Hc_settings_chat()
 
 
    surface.CreateFont( "Hc_chat", {
        font = "DermaDefault",
        size = 13 * scale_s,
        weight = 500 * 1.6,
        blursize = 0,
        scanlines = 0,
        antialias = true,
        underline = false,
        italic = false,
        strikeout = false,
        symbol = false,
        rotary = false,
        shadow = false,
        additive = false,
        outline = false,
    } )
 
 
        local Hc_frame_s = vgui.Create( "DFrame" )
        Hc_frame_s:SetSize( 420 * scale_s, 250 * scale_s )
        Hc_frame_s:Center()
        Hc_frame_s:MakePopup()
        Hc_frame_s:SetVisible( true )
        Hc_frame_s:SetTitle( "" )
        Hc_frame_s:SetDraggable( true )
        Hc_frame_s:ShowCloseButton( false )
        function Hc_frame_s:Paint( w, h )
            draw.RoundedBox( 0, 0, 0, 420 * scale_s, 250 * scale_s, Color( 182, 182, 182, 220 ) )
           
            surface.SetFont( "Hc_chat" )
            surface.SetTextColor( 255, 255, 255, 200 )
            surface.SetTextPos( 40 * scale_s, 55 * scale_s )
            surface.DrawText( "Chat notifications" )
           
            surface.SetTextPos( 40 * scale_s, 85 * scale_s )
            surface.DrawText( "Sound notifications" )
           
            surface.SetTextPos( 40 * scale_s, 115 * scale_s )
            surface.DrawText( "Timestamps" )
           
        end
 
        -- Settings
        local se2_DButton = vgui.Create( "DButton", Hc_frame_s )
        se2_DButton:SetPos( 375 * scale_s, 220 * scale_s)
        se2_DButton:SetText( "" )
        se2_DButton:SetSize( 30 * scale_s, 20 * scale_s )
        se2_DButton.DoClick = function()
            Hc_frame:ToggleVisible()
            Hc_frame_s:ToggleVisible()
            --Hc_frame_s:Close()
        end
        function se2_DButton:Paint( w, h )
            surface.SetDrawColor( 255, 255, 255, 255 )
            surface.SetMaterial( back_arrow )
            se2_DButton:DrawTexturedRect()
        end
       
        local sc_ESlider = vgui.Create( "Slider", Hc_frame_s )
        sc_ESlider:SetText( "Scale" )
        sc_ESlider:SetPos( 5 * scale_s, 10 * scale_s )
        sc_ESlider:SetSize( 335 * scale_s, 20 * scale_s )
        sc_ESlider:SetMin( 1 )
        sc_ESlider:SetMax( 3 )
        sc_ESlider:SetValue( math.Round(scale_s, 1) )
        sc_ESlider:SetDecimals( 1 )
        sc_ESlider:SetConVar( "scale_size" )  
       
        local ap_DButton = vgui.Create( "DButton", Hc_frame_s )
        ap_DButton:SetPos( 333 * scale_s, 10 * scale_s)
        ap_DButton:SetSize( 80 * scale_s, 20 * scale_s )
        ap_DButton:SetFont( "Hc_chat" )
        ap_DButton:SetText( "Apply Scale" )
        ap_DButton.DoClick = function()
            scale_s = scale_size:GetFloat()
            --print( scale_s )
            Hc_frame_s:Close()
            Hc_settings_chat()
            RunConsoleCommand( "refresh_scale" )
        end
       
        --[[ chat notification ]]--
        local nic_button = vgui.Create( "DButton", Hc_frame_s ) --note_in_chat
        nic_button:SetPos( 10 * scale_s, 50 * scale_s)
        nic_button:SetSize( 20 * scale_s, 20 * scale_s )
        nic_button:SetFont( "Hc_chat" )
        nic_button:SetText( "" )
        nic_button.DoClick = function()
            if note_in_chat:GetBool() then
                RunConsoleCommand( "note_in_chat", "0" )
            else
                RunConsoleCommand( "note_in_chat", "1" )
            end
        end
        function nic_button:Paint( w, h )
        surface.SetDrawColor( 255, 255, 255, 255 )
        draw.RoundedBox( 4,0,0,w,h,  Color( 255, 255, 255, 255 ) )
            if note_in_chat:GetBool() then
            surface.SetMaterial( tick_png )
            nic_button:DrawTexturedRect()
        end
        end
       
       
        --[[ sound notification ]]--
        local nic_button = vgui.Create( "DButton", Hc_frame_s ) --note_in_chat
        nic_button:SetPos( 10 * scale_s, 80 * scale_s)
        nic_button:SetSize( 20 * scale_s, 20 * scale_s )
        nic_button:SetFont( "Hc_chat" )
        nic_button:SetText( "" )
        nic_button.DoClick = function()
            if note_in_sound:GetBool() then
                RunConsoleCommand( "note_in_sound", "0" )
            else
                RunConsoleCommand( "note_in_sound", "1" )
            end
        end
        function nic_button:Paint( w, h )
        surface.SetDrawColor( 255, 255, 255, 255 )
        draw.RoundedBox( 4,0,0,w,h,  Color( 255, 255, 255, 255 ) )
            if note_in_sound:GetBool() then
            surface.SetMaterial( tick_png )
            nic_button:DrawTexturedRect()
        end
        end
       
        --[[ sound notification ]]--
        local nic_button = vgui.Create( "DButton", Hc_frame_s ) --note_in_chat
        nic_button:SetPos( 10 * scale_s, 110 * scale_s)
        nic_button:SetSize( 20 * scale_s, 20 * scale_s )
        nic_button:SetFont( "Hc_chat" )
        nic_button:SetText( "" )
        nic_button.DoClick = function()
            if time_stamp_chat:GetBool() then
                RunConsoleCommand( "time_stamp_chat", "0" )
            else
                RunConsoleCommand( "time_stamp_chat", "1" )
            end
        end
        function nic_button:Paint( w, h )
        surface.SetDrawColor( 255, 255, 255, 255 )
        draw.RoundedBox( 4,0,0,w,h,  Color( 255, 255, 255, 255 ) )
            if time_stamp_chat:GetBool() then
            surface.SetMaterial( tick_png )
            nic_button:DrawTexturedRect()
        end
        end
       
       
       
end
 
--[[ Derma ]]--
 
Hc_frame:SetSize( 420 * scale_s, 250 * scale_s )
Hc_frame:Center()
Hc_frame:MakePopup()
Hc_frame:SetVisible( false )
Hc_frame:SetTitle( "" )
Hc_frame:SetDraggable( true )
Hc_frame:ShowCloseButton( false )
function Hc_frame:Paint( w, h )
    draw.RoundedBox( 0, 0, 0, 420 * scale_s, 250 * scale_s, Color( 182, 182, 182, 150 ) )
    draw.RoundedBox( 0, 10 * scale_s, 10 * scale_s, 400 * scale_s, 200 * scale_s, Color( 109, 109, 109, 150 ) )
   
    surface.SetFont( "Hc_chat" )
    surface.SetTextColor( 255, 255, 255, 75 )
    surface.SetTextPos( 115 * scale_s, 238 * scale_s )
    surface.DrawText( "Dark Localchat" )
end
 
-- Hc_richtext
local Hc_richtext = vgui.Create( "RichText", Hc_frame )
Hc_richtext:SetPos( 10 * scale_s, 10 * scale_s )
Hc_richtext:SetSize( 400 * scale_s, 200 * scale_s )
 
function Hc_richtext:PerformLayout()
 
    self:SetFontInternal( "Hc_chat" )
    self:SetFGColor( Color( 255, 255, 255 ) )
 
end
 
    -- TextEntry
    local TextEntry = vgui.Create( "DTextEntry", Hc_frame ) -- create the form as a child of frame
    TextEntry:SetPos( 10 * scale_s, 220 * scale_s )
    TextEntry:SetSize( 350 * scale_s, 20 * scale_s )
    TextEntry:SetText( "" )
    TextEntry:SetFont( "Hc_chat" )
    TextEntry:SetTextColor( color_white )
    TextEntry:SetDrawBorder( false )
    TextEntry:SetDrawBackground( false )
    TextEntry:SetCursorColor( color_white )
    TextEntry:SetHighlightColor( Color(0, 161, 255) )
    TextEntry:RequestFocus()
    TextEntry.OnTextChanged = function(self)
    -- 115 Character Cap
    local current_txt = self:GetValue()
        if string.len(current_txt) > 115 then
            self:SetText(self.OldText)
            self:SetValue(self.OldText)
            self:SetCaretPos(115)
            surface.PlaySound ("common/wpn_denyselect.wav")
        else
            self.OldText = current_txt
        end
    end
    -- Send Message
    TextEntry.OnEnter = function( self )
        message_s = self:GetValue()
        send_en_mesg()
        TextEntry:SetText( "" )
        TextEntry:RequestFocus()
    end
    function TextEntry:Paint( w, h )
        draw.RoundedBox( 0, 0, 0, w, h, Color( 109, 109, 109, 150 ) )
        derma.SkinHook( "Paint", "TextEntry", self, w, h )
    end
   
    -- Close
    local cl_DButton = vgui.Create( "DButton", Hc_frame )
    cl_DButton:SetPos( 390 * scale_s, 220 * scale_s )
    cl_DButton:SetText( "" )
    cl_DButton:SetSize( 20 * scale_s, 20 * scale_s )
    cl_DButton.DoClick = function()
        Hc_frame:ToggleVisible()
    end
    function cl_DButton:Paint( w, h )
        surface.SetDrawColor( 255, 255, 255, 255 )
        surface.SetMaterial( delete_png )
        cl_DButton:DrawTexturedRect()
    end
   
    -- Settings
    local se_DButton = vgui.Create( "DButton", Hc_frame )
    se_DButton:SetPos( 365 * scale_s, 220 * scale_s)
    se_DButton:SetText( "" )
    se_DButton:SetSize( 20 * scale_s, 20 * scale_s )
    se_DButton.DoClick = function()
        Hc_frame:ToggleVisible()
        Hc_settings_chat()
    end
    function se_DButton:Paint( w, h )
        surface.SetDrawColor( 255, 255, 255, 255 )
        surface.SetMaterial( settings_png )
        se_DButton:DrawTexturedRect()
    end
   
local function add_chatbox_text(script, text, ply)
   
    if time_stamp_chat:GetBool() then
                Hc_richtext:InsertColorChange( 0,255,255, 255 )
                Hc_richtext:AppendText( os.date("[%H:%M]") )
            end
               
            -- Special chat box message
            local col = GAMEMODE:GetTeamColor( ply )
            Hc_richtext:InsertColorChange( chat_scripts[script][1].r, chat_scripts[script][1].g, chat_scripts[script][1].b, chat_scripts[script][1].a )
            Hc_richtext:AppendText( chat_scripts[script][2] )
            Hc_richtext:InsertColorChange( chat_scripts[script][3].r, chat_scripts[script][3].g, chat_scripts[script][3].b, chat_scripts[script][3].a  )
            Hc_richtext:AppendText( chat_scripts[script][4] )
            Hc_richtext:InsertColorChange( 72,72,72, 255 )
            Hc_richtext:AppendText( " - " )
            Hc_richtext:InsertColorChange( col.r, col.g, col.b, 255 )
            Hc_richtext:AppendText( ply:Nick() )
            Hc_richtext:AppendText( ": " )
            Hc_richtext:InsertColorChange( 255,255,255, 255 )
            Hc_richtext:AppendText( string.reverse( text ) .. "\n" )
           
            -- Chat Message
           
//          if note_in_sound:GetBool() then
//          LocalPlayer():EmitSound( "Friends/message.wav", 75, 125, 0.5, CHAN_AUTO )
//          end
//          if note_in_chat:GetBool() then
//          chat.AddText( chat_notification_col, chat_notification )   
//          end
            chat_msg_added()
 
end
 
--[[ remove global waypoints ]]--
local function remove_waypoints( name )
    --[[
    for k, v in pairs( waypoints ) do
        if k == name then
        waypoints[name] = nil
        wp_removed_msg( name )
//      PrintTable( waypoints )
        end
    end
    ]]--
   
    if waypoints[name] != nil then
    waypoints[name] = nil
    wp_removed_msg( name )
    end
   
end
 
--[[ Chat listener + decrypter ]]--
hook.Add( "OnPlayerChat", "ping_pong", function( ply, strText, bTeam, bDead )
 
    local words = string.Explode( " ", strText )
       
        --See which script they are using
        if chat_scripts[words[1]] != nil then
       
            local to_read = string.TrimLeft( strText, words[1] .. " " )
            local de_sentence = ""
 
            for i=1, string.len( to_read ) do
                   
                de_sentence = de_sentence .. string.char( string.byte( to_read, i, i ) - encryption_num )
 
            end
            add_chatbox_text(words[1], de_sentence, ply)
            return true
        end
       
        --Add waypoints
        if words[1] == "[WP]" then
       
            local to_read_wp = string.TrimLeft( strText, words[1] .. " " )
            local de_sentence_wp = ""
           
            for i=1, string.len( to_read_wp ) do
           
                de_sentence_wp = de_sentence_wp .. string.char( string.byte( to_read_wp, i, i ) - encryption_num )
               
            end
            add_waypoint( string.reverse(de_sentence_wp) )
            return true
           
        end
       
        --Remove waypoints
        if words[1] == "[RWP]" then
       
            local to_read_rwp = string.TrimLeft( strText, words[1] .. " " )
            local de_sentence_rwp = ""
           
            for i=1, string.len( to_read_rwp ) do
           
                de_sentence_rwp = de_sentence_rwp .. string.char( string.byte( to_read_rwp, i, i ) - encryption_num )
               
            end
            remove_waypoints( string.reverse(de_sentence_rwp) )
            return true
           
        end
           
end )
 
--Reset the scale of the chat derma, can't re-open or chat will vanish!
concommand.Add( "refresh_scale", function()
 
            Hc_frame:SetSize( 420 * scale_s, 250 * scale_s )
            Hc_frame:Center()
           
            Hc_richtext:SetPos( 10 * scale_s, 10 * scale_s )
            Hc_richtext:SetSize( 400 * scale_s, 200 * scale_s )
           
            TextEntry:SetPos( 10 * scale_s, 220 * scale_s )
            TextEntry:SetSize( 350 * scale_s, 20 * scale_s )
            TextEntry:SetFont( "Hc_chat" )
           
            cl_DButton:SetPos( 390 * scale_s, 220 * scale_s )
            cl_DButton:SetSize( 20 * scale_s, 20 * scale_s )
           
            se_DButton:SetPos( 365 * scale_s, 220 * scale_s)
            se_DButton:SetSize( 20 * scale_s, 20 * scale_s )
                   
end)
 
--[[ draw waypoints ]]--
local function waypoint_draw()
    for k, v in pairs( waypoints ) do
//          if waypoints[k][1] != nil then --return end
            local angles = LocalPlayer():EyeAngles()
            local position = Vector( waypoints[k][1].x, waypoints[k][1].y, waypoints[k][1].z )
            local distance = position:Distance(LocalPlayer():GetPos())
            local distance_m = math.Round(distance / 39.370)
//          if waypoints[k][2] != nil then --return end
            local textcolour = Color(waypoints[k][2].r, waypoints[k][2].g, waypoints[k][2].b, waypoints[k][2].a ) or Color( 0,0,0,0 )
           
            local text = k .. " " .. "[" .. distance_m .. "m]" --,2
            local TextWidth_wp = surface.GetTextSize(text)
            local xy = distance/10 + 100
 
            angles:RotateAroundAxis(angles:Forward(), 90);
            angles:RotateAroundAxis(angles:Right(), 90);
            angles:RotateAroundAxis(angles:Up(), 0);
           
            cam.Start3D2D( position, angles, 0.1)
                cam.IgnoreZ(true)
                draw.RoundedBox( 0, -xy/2, (-xy/2)*2, xy, xy, textcolour )
                draw.WordBox(2, -TextWidth_wp*0.5, 0, text, "Waypoint_big", Color(0, 0, 0, 150), textcolour)
                cam.IgnoreZ(false)
            cam.End3D2D()
//  end
//  end
    end
end
hook.Add("PostDrawOpaqueRenderables", "waypoint_draw", waypoint_draw) --PostDrawOpaqueRenderables
 
--[[ waypoint sender adder ]]--
local function add_dat_wp( argStr )
 
    local en_sentence = ""
   
    -- encrypted
    for i=1, string.len( argStr ) do
   
        local en_word = string.byte( argStr, i, i )
        en_sentence = en_sentence .. string.char( en_word + encryption_num )
 
    end
       
    -- 30 length without message, message can be 115.
    RunConsoleCommand( "say", "/radio " .. "[WP]" .. " " .. string.reverse( en_sentence )   )
    en_sentence = ""
    //wp_added_msg()
 
   
end
 
--[[ waypoint sender remover ]]--
local function remove_dat_wp( argStr )
 
    --que
    if argStr != nil then
    table.insert( que, argStr )
    end
   
    if cango and que != nil then
    --PrintTable( que )
    cango = false
 
    local rwp_en_sentence = ""
   
    -- encrypted
    for i=1, string.len( que[1] ) do
   
        local rwp_en_word = string.byte( que[1], i, i )
        rwp_en_sentence = rwp_en_sentence .. string.char( rwp_en_word + encryption_num )
 
    end
       
    -- 30 length without message, message can be 85.
    RunConsoleCommand( "say", "/radio " .. "[RWP]" .. " " .. string.reverse( rwp_en_sentence )  )
    rwp_en_sentence = ""
    timer.Simple( 2, function()
        if waypoints[que[1]] == nil then // fail safe
            table.remove( que, 1 )
        else
            wp_remove_failed_msg( que[1] )
        end
        cango = true
        if que[1] != nil then
        remove_dat_wp()
        end
    end)
 
    end
   
end
 
--[[ waypoint menu ]]--
concommand.Add( add_wp_concommand, function( ply, cmd, args, argStr )
 
local xScreenRes = 1366
local yScreenRes = 768
local wMod = ScrW() / xScreenRes    
local hMod = ScrH() / yScreenRes
 
local Frame = vgui.Create( "DFrame" )
Frame:SetTitle( "Waypoint DARKV1" )
Frame:SetSize( wMod*400, hMod*320 )
Frame:Center()
Frame:MakePopup()
Frame.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
    draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 150 ) ) -- Draw a red box instead of the frame
end
 
local wayp_Entry = vgui.Create( "DTextEntry", Frame )   -- create the form as a child of frame
wayp_Entry:SetPos( wMod*10, hMod*30 )
wayp_Entry:SetSize( wMod*380, hMod*30 )
wayp_Entry:SetText( wayp_n )
wayp_Entry.OnTextChanged = function(self)
    -- 115 Character Cap
        wayp_n = self:GetValue()
        if string.len(wayp_n) > 50 then
            self:SetText(self.OldText)
            self:SetValue(self.OldText)
            self:SetCaretPos(50)
            surface.PlaySound ("common/wpn_denyselect.wav")
        else
            self.OldText = wayp_n
        end
    end
   
local ColorPicker = vgui.Create( "DColorMixer", Frame )
ColorPicker:SetSize( wMod*380, hMod*200 )
ColorPicker:SetPos( wMod*10, hMod*70 )
ColorPicker:SetPalette( true )
ColorPicker:SetAlphaBar( true )
ColorPicker:SetWangs( true )
ColorPicker:SetColor( ChosenColor )
 
local Button = vgui.Create( "DButton", Frame )
Button:SetText( "Add waypoint" )
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( wMod*10, hMod*280 )
Button:SetSize( wMod*380, hMod*30 )
Button.Paint = function( self, w, h )
    draw.RoundedBox( 0, 0, 0, w, h, Color( 41, 128, 185, 250 ) ) -- Draw a blue button
end
Button.DoClick = function()
    ChosenColor = ColorPicker:GetColor()
    local stringyyy = math.Round(LocalPlayer():GetShootPos()[1]) .. "✓ " .. math.Round(LocalPlayer():GetShootPos()[2]) .. "✓ " .. math.Round(LocalPlayer():GetShootPos()[3] + 50)
    .. "✓ " .. (ChosenColor.r) .. "✓ " .. (ChosenColor.g) .. "✓ " .. (ChosenColor.b) .. "✓ " .. (ChosenColor.a) .. "✓ "
    .. wayp_n
    add_dat_wp( stringyyy )
    --print( stringyyy )
end
 
 
end)
 
--Toggle the chat derma rather than re-open because that would cause the chat to blank.
concommand.Add( console_command, function()
   
    Hc_frame:ToggleVisible()
   
end)
 
 
--[[ remove waypoints ]]--
 
concommand.Add( remove_wp_concommand, function()
 
local xScreenRes = 1366
local yScreenRes = 768
local wMod = ScrW() / xScreenRes    
local hMod = ScrH() / yScreenRes
 
local Frame = vgui.Create( "DFrame" )
Frame:SetTitle( "Waypoint remover" )
Frame:SetSize( wMod*400, hMod*320 )
Frame:Center()
Frame:MakePopup()
Frame.Paint = function( self, w, h ) -- 'function Frame:Paint( w, h )' works too
    draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 150 ) ) -- Draw a red box instead of the frame
end
 
local WP_LIST = vgui.Create( "DListView", Frame )
WP_LIST:SetPos( wMod*10, hMod*30 )
WP_LIST:SetSize( wMod*380, hMod*240 )
WP_LIST:SetMultiSelect( true )
WP_LIST:AddColumn( "Waypoint" )
--AppList:AddColumn( "Pos" )
 
for k, v in pairs( waypoints ) do
//if waypoints[k][1] != nil then
WP_LIST:AddLine( k )
--AppList:AddLine( "gg" )
//end
end
 
local Button = vgui.Create( "DButton", Frame )
Button:SetText( "Remove waypoint(s)" )
Button:SetTextColor( Color( 255, 255, 255 ) )
Button:SetPos( wMod*10, hMod*280 )
Button:SetSize( wMod*380, hMod*30 )
Button.Paint = function( self, w, h )
    draw.RoundedBox( 0, 0, 0, w, h, Color( 41, 128, 185, 250 ) ) -- Draw a blue button
end
Button.DoClick = function()
 
    for k, line in pairs( WP_LIST:GetSelected()) do
 
        remove_dat_wp( line:GetValue(1) )
        WP_LIST:RemoveLine( line:GetID() )
 
    end
   
end
 
 
end)

// mpgh exploits that are free to use

concommand.Add("dark_wepdupe", function()
	

	timer.Simple( 0.4744, function() 
		RunConsoleCommand("say", "/drop")  
	end)
	
	timer.Simple( 1.4135, function() 
		RunConsoleCommand("say", "/sleep")  
	end)
	
	timer.Simple( 7, function() 
		RunConsoleCommand("say", "/sleep")  
	end)
	
end)

local ag_toggle = 0
local hook_toggle = 0
function GenAmmo()
lastgun = LocalPlayer():GetActiveWeapon():GetClass()
if hook_toggle == 0 then
hook.Add("CreateMove", "lolammo", function(cmd)
RunConsoleCommand("darkrp", "drop")
RunConsoleCommand("use", lastgun)
if ag_toggle == 0 then
cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_USE))
ag_toggle = 1
else
cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_USE)))
ag_toggle = 0
end
end)
hook_toggle = 1
else
hook.Remove("CreateMove", "lolammo")
hook_toggle = 0
end
end

concommand.Add("dark_ammodupe", GenAmmo)

























-- NOT DONE YET---  DO NOT TOUCH --- REMEMBER TO ADD ADDITONAL HOOKS/concommands here, hmm can't add any function that uses deligits detouring thing NEED FIX ASAP.
concommand.Add( "dark_unload", function()
 ---- surface.PlaySound("ambient/levels/labs/teleport_winddown1.wav") -- should i use this or custom sound? hmmm....,

RunConsoleCommand ("dark_esp","0")
RunConsoleCommand ("dark_hud","0")
RunConsoleCommand ("dark_xray","0")
RunConsoleCommand ("dark_entity","0")
RunConsoleCommand ("dark_watermark","0")
RunConsoleCommand ("dark_crosshair","0")
RunConsoleCommand ("dark_crosshair2","0")
RunConsoleCommand ("dark_flashspam","0")
  concommand.Remove( "dark_entity" )
  concommand.Remove( "dark_xray" )
  concommand.Remove( "dark_about" )
   concommand.Remove( "dark_menu" )
   concommand.Remove ("dark_esp")
 concommand.Remove ("dark_openscript")
 concommand.Remove ("dark_180")
 concommand.Remove ("dark_help")
 concommand.Remove ("darkbhop")
 concommand.Remove ("dark_adminalert")
 concommand.Remove ("darkide_adminalert_distance")
 concommand.Remove ("dark_chatspammer")
 concommand.Remove ("dark_chatspammer_msg")
  concommand.Remove ("dark_crosshair")
    concommand.Remove ("dark_crosshair2")
 hook.Remove ( "Think", "dark_chatspammer_hook")
 hook.Remove ( "HUDPaint", "ESP")
 hook.Remove ("RenderScreenspaceEffects","dark.GetPlys")
 timer.Remove("dark.GetPlys")
 timer.Destroy("dark.GetPlys")
 hook.Remove ("Think","darkflash")
 concommand.Remove ("dark_flashspam")
 concommand.Remove ("dark_rainbow")
  hook.Remove ("Think","darkrainbow")
  hook.Remove ("HUDPaint", "crosshair2")
 hook.Remove ("HUDPaint", "crosshair")
 hook.Remove ("HUDPaint", "huddesign")
 hook.Remove ("HUDPaint", "watermark")
 concommand.Remove ("dark_hud")
  concommand.Remove ("dark_watermark")
    concommand.Remove ("dark_crosshair")
	concommand.Remove ("dark_crosshai2")
	concommand.Remove ("dark_ping_rp")
	 chat.AddText( Color( 100, 255, 100 ) ,"DARK NOTICE:" ,  Color( 0, 157, 209 ), "Dark's scripts unloaded! Type lua_openscript_cl darkv1.lua to open it again!" )
  chat.AddText ( Color( 0, 157, 209 ), "The ESP will remain until you rejoin the server.")
    chat.AddText ( Color( 0, 157, 209 ), "Do not reload the script too many times or you can crash the script!")
 end)
 













