hook.Add("HUDPaint", "testnewSurfaceFunc", function()
	local texture = surface.GetTextureID("ra2_gi");
	local texW, texH = surface.GetTextureSize( texture );
	
	surface.SetTexture( texture );
	surface.SetDrawColor( 255, 255, 255, 255 );
	surface.DrawPartialTexturedRect( 50, 50, 29, 30, 102, 1727, 29, 30, texW, texH );
end);
-- or/and
hook.Add("HUDPaint", "testnewDrawFunc", function()
    draw.DrawPartialTexturedRect( 79, 50, 29, 30, 102, 1727, 29, 30, "ra2_gi" );
end);