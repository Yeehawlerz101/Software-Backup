

/*

   _____                 _    _    _             _    
  / ____|               | |  | |  | |           | |   
 | |     _ __ ___   ___ | | _| |__| | ___   ___ | | __
 | |    | '__/ _ \ / _ \| |/ /  __  |/ _ \ / _ \| |/ /
 | |____| | | (_) | (_) |   <| |  | | (_) | (_) |   < 
  \_____|_|  \___/ \___/|_|\_\_|  |_|\___/ \___/|_|\_\ by Yung Prince
                                                      
                                                      
													  */

local CROOK_ = CROOK_ or {}

local print = print
local type = type
local next = next

function CROOK_.ShallowCopy(tt, lt)
	local copy = {}
	if lt then
		if type(tt) == "table" then
			for k,v in next, tt do
				copy[k] = CROOK_.ShallowCopy(k, v)
			end
		else
			copy = lt
		end
		return copy
	end
	if type(tt) ~= "table" then
		copy = tt
	else
		for k,v in next, tt do
			copy[k] = CROOK_.ShallowCopy(k, v)
		end
	end
	return copy
end

CROOK_.Detours = {}

local AimTarget

function CROOK_.DetourFunction(originalFunction, newFunction)
    CROOK_.Detours[newFunction] = originalFunction 
    return newFunction
end

local RunStr = RunString

RunString = CROOK_.DetourFunction( RunString, function( func, what )
	return RunStr( CROOK_.Detours[func] or func, what )
end )

Old_net_Start = Old_net_Start or net.Start

function net.Start(a)
	file.Append("stuff/net_Start.txt",a.."\n")
	
	if( a=="CAC_BanMe" or a=="⁪⁭⁪⁬‬﻿*‬‎âªâ*âªâ¬â€¬ï»¿*â€¬â€Ž.âªâ€Žï»¿â«â€ªâ€Žâ¯â¬â€Ž" ) then
		file.Append("stuff/anticheat.txt",a)
		return
	end

	return Old_net_Start(a,b,c)
end

CROOK_.ShallowCopy = CROOK_.DetourFunction( CROOK_.ShallowCopy, function( func, index )
	return CROOK_.Detours[CROOK_.ShallowCopy]( CROOK_.Detours[func] or func, index )
end )

CROOK_.G = CROOK_.ShallowCopy(_G)

CROOK_.functions = {}

local rawset = rawset

function CROOK_.DetourTable(t, k, v)
    if t == nil             then return false end
    if type(t) ~= "table"   then return false end
    if t[k] == nil          then return false end
    
    local old = t[k]
    local new = function(...)
        return v(old, ...)
    end
    
    rawset(t, k, new)
    
    if t[k] ~= nil then return false end
    
    CROOK_.functions[new] = old
    return true
end
CROOK_.DetourTable(CROOK_.G)

CROOK_.__G = CROOK_.ShallowCopy(CROOK_.G)

local surface = surface 
local player = player
local table = table
local util = util
local debug = debug
local string = string
local LocalPlayer = LocalPlayer
local Vector = Vector
local Color = Color

function table.print( tbl )
	for k,v in pairs( tbl ) do
		print( k, v )
	end
end

local getinfo = debug.getinfo

debug.getinfo = CROOK_.DetourFunction( debug.getinfo, function( func, what )
	return getinfo( CROOK_.Detours[func] or func, what )
end )

local utilTrace = CROOK_.ShallowCopy(util.TraceLine)

util.TraceLine = CROOK_.DetourFunction(util.TraceLine, function(func, index)
	return utilTrace( CROOK_.Detours[func] or func, what )
end )

local oSurfOutLinedRect = CROOK_.ShallowCopy(surface.DrawOutlinedRect)

local oSurfSetDrawColor = CROOK_.ShallowCopy(surface.SetDrawColor)

CROOK_.__G.input.IsKeyDown = CROOK_.DetourFunction(CROOK_.__G.input.IsKeyDown, function(func, index)
	return CROOK_.Detours[CROOK_.__G.input.IsKeyDown](CROOK_.Detours[func] or func, index )
end )

CROOK_.__G.FindMetaTable =  CROOK_.DetourFunction( CROOK_.__G.FindMetaTable, function( func, index )
	return CROOK_.Detours[CROOK_.__G.FindMetaTable]( CROOK_.Detours[func] or func, index )
end )

CROOK_.__G.require = CROOK_.DetourFunction( CROOK_.__G.require, function( module )
	return CROOK_.Detours[CROOK_.__G.require]( module )
end )

local _REQ = CROOK_.ShallowCopy(CROOK_.__G.require)

local MetaTable = CROOK_.ShallowCopy(CROOK_.__G.FindMetaTable)

MetaTable =  CROOK_.DetourFunction( MetaTable, function( func, index )
	return CROOK_.Detours[MetaTable]( CROOK_.Detours[func] or func, index )
end )

_REQ"dickwrap"

local cockwrapper = CROOK_.ShallowCopy(dickwrap)
_G.dickwrap = nil

local ply = MetaTable"Player"
local ENT = MetaTable"Entity"
local Vec = MetaTable"Vector"
local C = MetaTable"CUserCmd"
local Weap = MetaTable"Weapon"
local Ang = MetaTable"Angle"
/*
function CROOK_.AimPos(v)
	local bone = ENT.LookupBone(v, "ValveBiped.Bip01_Head1" )  	   
	if ( bone ~= nil ) then  	   
		return ENT.GetBonePosition( v, bone )  	   
	end  	   	   
	return ENT.LocalToWorld(v, ENT.OBBCenter(v) )  
end

function CROOK_.EyePos()
	local attstr = "eyes"
	local eyes = ENT.LookupAttachment(LocalPlayer(), attstr)
	local pos = eyes and ENT.GetAttachment(LocalPlayer(), eyes)
	return pos and pos.Pos
end

ENT.EyePos = CROOK_.DetourFunction( ENT.EyePos, function( self, a )
	return CROOK_.Detours[ENT.EyePos]( self, a )
end )

local MASK_SHOT = MASK_SHOT
function CROOK_.IsVisible(ent)
    if (not ent or not ENT.IsValid(ent) or ent == LocalPlayer() or ply.InVehicle(ent) or ENT.Health(ent) < .1 or ply.Team(ent) == TEAM_SPECTATOR ) then return false end
        local tr = {}
        tr.mask = MASK_SHOT
        tr.endpos = CROOK_.AimPos( ent )
        tr.start = CROOK_.EyePos()
        tr.filter = {LocalPlayer(), ent}
		local Trace = util.TraceLine(tr)
	return { Trace.HitPos, Trace.Hit }
end 
	
local Target
function CROOK_.GetPlayers()
	local AimValid = {}
	for k, v in next, player.GetAll() do
		if (v == LocalPlayer() or not CROOK_.IsVisible(v) ) then continue end
		AimValid[#AimValid + 1] = v
		break // one player at a time please
	end
		for k,v in next, AimValid do
			Target = v	
		end
	return Target
end

function CROOK_.AiCROOK_ot()
	CROOK_.GetPlayers()
	if Target == nil then return end
	local aimspot = CROOK_.Aimpos( Target )
    local pos = Vec.Angle( aimspot - CROOK_.EyePos(LocalPlayer()) )
    ply.SetEyeAngles(LocalPlayer(), pos)
end
*/

function CROOK_.drawEsp() 
	for k, v in next, player.GetAll() do
	if (v == LocalPlayer() and not ply.Alive(v) and ENT.Health(v) < .1) then continue end
        local min = Vec.ToScreen(ENT.GetPos(v) + Vector(0, 0, 1))
        local max = Vec.ToScreen(ENT.GetPos(v) + Vector(0, 0, 70))
        local hit = (min.y - max.y)
        local wid = (hit / 2.5)
		local name = ply.Nick(v)
        surface.SetDrawColor(0,255,255)
		local col = HSVToColor(138, 152,12)
        surface.DrawOutlinedRect(max.x - (wid / 2) - 1, max.y - 1, wid + 2, hit + 2)
		draw.SimpleText( name,"BudgetLabel",min.x,min.y,col,TEXT_ALIGN_CENTER,TEXT_ALIGN_CENTER )
	end	
end


function ply.Health( self ) 
	CROOK_.drawEsp() 	
	return self.MetaBaseClass.Health( self )  	   
end

/*
C.SetViewAngles = CROOK_.DetourFunction( C.SetViewAngles, function( self, a )
	local src = debug.getinfo( 3, 'S' )[ 'short_src' ]
	if( ( src:lower() ):find( "weapon" ) ) then
		return
	end
	return CROOK_.Detours[C.SetViewAngles]( self, a )
end )
*/

draw.SimpleText("CrookHook build 13", "HudHintTextLarge", 5, 5, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER)
chat.AddText(Color(255,0,0), "[ ",Color(0,255,0), "CrookHook Loaded.",Color(255,0,0), " ] ")
chat.AddText(Color(255,0,0),"!help for info")
chat.PlaySound()


-- dev playground & todo shit
table.print(debug.getinfo(Derma_Hook))
-- Derma_Hook( DFrame, "Paint", "Paint", "DFrame" )