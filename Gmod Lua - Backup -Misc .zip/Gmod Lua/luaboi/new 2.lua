local names = CreateClientConVar("Prop_Names", "1", true, false)
local PESP = CreateClientConVar("Prop_ESP", "1", true, false)
local ply = LocalPlayer()

hook.Add("HUDPaint", "ESPs", function()
    if PESP:GetInt() == 1 then
	for k, v in pairs(ents.FindByClass("ph_prop")) do
		if v.Owner != ply then
		cam.Start3D(EyePos(), EyeAngles())
        v:SetMaterial("models/wireframe")
		v:SetColor(Color(255, 0, 0, 255))
		render.MaterialOverride("models/wireframe")
		render.SuppressEngineLighting( false )
		render.SetBlend( 0.3 )
		render.SetColorModulation( 1, 0, 0 )
		v:DrawModel()
        if Solic:GetInt() == 1 then
            v:SetMaterial("models/debug/debugwhite")
            render.MaterialOverride("models/debug/debugwhite")
            v:DrawModel()
        end
		cam.End3D()
        if names:GetInt() == 1 then
            local ESP = (v:EyePos()):ToScreen()
			local col = Color(255, 0, 0)
			local x1,y1,x2,y2 = coordinates(v)
			draw.DrawText(v.Owner:Name(), "DefaultFixed", ESP.x, ESP.y, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
        end
		end
	end
	for k,v in pairs(player.GetAll()) do
			for k,v2 in pairs(v:GetWeapons()) do
				if v2:GetClass() == "weapon_crowbar" && v != ply then
					cam.Start3D(EyePos(), EyeAngles())
					v:SetMaterial("models/wireframe")
					v:SetColor(Color(0, 255, 0, 255))
					render.MaterialOverride("models/wireframe")
					render.SuppressEngineLighting( false )
					render.SetBlend( 0.3 )
					render.SetColorModulation( 0, 1, 0 )
					v:DrawModel()
					if Solic:GetInt() == 1 then
						v:SetMaterial("models/debug/debugwhite")
						render.MaterialOverride("models/debug/debugwhite")
						v:DrawModel()
					end
					cam.End3D()
					if names:GetInt() == 1 then
						local ESP = (v:EyePos()):ToScreen()
						local col = Color(0, 255, 0)
						local x1,y1,x2,y2 = coordinates(v)
						draw.DrawText(v:Name(), "DefaultFixed", ESP.x, ESP.y, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					end
				end
			end
		end
    end
end)