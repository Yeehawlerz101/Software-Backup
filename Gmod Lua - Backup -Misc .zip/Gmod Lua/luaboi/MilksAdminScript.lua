-- tsat 7
-- milk
------------------------------------------------------------------------
 
local istnb = false;

local esp = true;
 
local weapons ={
        neutral ={
                "ts2_hands",
                "ts2_keys",
                "ts_hands",
                "ts_keys",
                "ts_medic",
                "weapon_physcannon",
                "gmod_camera",
                "weapon_cc_hands",
        },
        good ={
                "weapon_physgun",
                "gmod_tool",
        },
};
 
local colors ={
        default = Color(235, 235, 235, 255);
        outline = Color(0, 0, 0, 60);
        highlight = Color(70, 255, 70, 64);
        neutralweapon = Color(200, 75, 200, 255);
        badweapon = Color(240, 82, 58, 255);
        goodweapon = Color(94, 232, 81, 255);
        item = Color(247, 185, 52, 255);
        npc = Color(240, 102, 88, 255);
        status = Color(150, 150, 150, 255);
};
 
local noshow = {};
local spot = {};
 
surface.CreateFont("TS2AdminFont2", {
  font = "Calibri",
  size = 12,
  weight = 500,
  blursize = 0,
  scanlines = 0,
  antialias = true,
  underline = false,
  italic = false,
  strikeout = false,
  symbol = false,
  rotary = false,
  shadow = false,
  additive = false,
  outline = false,
});
------------------------------------------------------------------------
 
local function status(ply)
       
        out = "";
       
        if ply:IsSuperAdmin() then
                out = out .. "S";
        else
                out = out .. " ";
        end
       
        if ply:IsAdmin() then
                out = out .. "A";
        else
                out = out .. " ";
        end
       
        if ply:GetFriendStatus() == "friend" then
                out = out .. "F  ";
        elseif ply == LocalPlayer() then
                out = out .. "-- ";
        else
                out = out .. "   ";
        end
       
        return out;
       
end

local function rpname(ply)

        if istnb == false then 
          return "x";
        elseif ply:RPName() != nil then
                return ply:RPName();
        else
                return "x";
        end
       
end
 
local function alpha(ent)
       
        if spot[ent] then return 200 end;
       
        local trace ={
                start = LocalPlayer():EyePos();
                endpos = ent:EyePos() or ent:GetPos();
                filter = LocalPlayer();
        };
       
        local tr = util.TraceLine(trace);
       
        if tr.Entity == ent then
                return 150;
        end
       
        return 50;
       
end
 
local function drawtext(text, x, y, color, a, align)
       
        draw.SimpleText(text, "TS2AdminFont2", x, y,
          Color(color.r, color.g, color.b, a),
          align, align
        );
       
end
 
local function teamcolor(ply)
       
        return Color(math.Clamp(team.GetColor(ply:Team()).r + 50, 0, 255), math.Clamp(team.GetColor(ply:Team()).g + 50, 0, 255), math.Clamp(team.GetColor(ply:Team()).b + 50, 0, 255), colors.default.a);
       
end
 
local function printplayer(ply)
       
        chat.AddText(colors.status, status(ply), teamcolor(ply), rpname(ply), colors.default, "  " .. ply:Name());
       
end
 
local function output(text)
       
        chat.AddText(colors.default, text);
       
end
 
------------------------------------------------------------------------
 
local function drawesp()
       
        if esp then
               
                for k, v in pairs(player.GetAll()) do
                        if v != LocalPlayer() then
                               
                                local base = v:EyePos():ToScreen();
                               
                                if spot[v] then
                                        draw.RoundedBox(4, base.x - 3, base.y - 11, 150, 26, colors.highlight);
                                end
                               
                                local distance = tostring(math.Round(v:EyePos():Distance(LocalPlayer():EyePos()) / 39.37)) .. "m";
                               
                                drawtext(rpname(v), base.x, base.y - 10, teamcolor(v), alpha(v), TEXT_ALIGN_LEFT);
                               
                                drawtext(v:Name(), base.x, base.y, colors.default, alpha(v), TEXT_ALIGN_LEFT);
                                drawtext(distance, base.x + 20, base.y + 10, colors.default, alpha(v), TEXT_ALIGN_LEFT);
                                drawtext(string.Trim(status(v)), base.x - 6, base.y, colors.neutralweapon, alpha(v), TEXT_ALIGN_RIGHT);
                        end
                        for k, v in pairs(v:GetWeapons()) do
                                if not noshow[v] then
                                        noshow[v] = true;
                                end
                        end
                end
               
                local trace ={
                        start = LocalPlayer():EyePos();
                        endpos = LocalPlayer():EyePos() + LocalPlayer():GetAimVector() * 2000;
                        filter = LocalPlayer();
                };
               
                local tr = util.TraceLine(trace);
               
                if tr.HitNonWorld and tr.Entity:IsPlayer() then
                       
                        local diff = 1;
                        local diff2 = 1;
                        local base = tr.Entity:EyePos():ToScreen();
                       
                                --drawtext("HP:"..tr.Entity:Health().." ["..tr.Entity:Armor().."]",base.x + 45,base.y + (diff2 * 10),colors.default, 255,TEXT_ALIGN_RIGHT);      
                                --diff2 = diff2 + 1;
                               
                                --drawtext("Money: $"..tr.Entity:GetNWFloat( "money" ),base.x + 45,base.y + (diff2 * 10),colors.default, 255,TEXT_ALIGN_RIGHT);  
                                --diff2 = diff2 + 1;
                       
                        for k, v in pairs(tr.Entity:GetWeapons()) do
                               
                                local weapon = v:GetClass();
                               
                                if table.HasValue(weapons.good, weapon) then
                                       
                                        drawtext(weapon, base.x + 50, base.y + (diff * 10), colors.goodweapon, 255, TEXT_ALIGN_LEFT);
                                        diff = diff + 1;
                                       
                                elseif table.HasValue(weapons.neutral, weapon) then
                                       
                                        drawtext(weapon, base.x + 50, base.y + (diff * 10), colors.neutralweapon, 255, TEXT_ALIGN_LEFT);
                                        diff = diff + 1;
                               
                                elseif not table.HasValue(weapons.neutral, weapon) then
                                       
                                        drawtext(weapon, base.x + 50, base.y + (diff * 10), colors.badweapon, 255, TEXT_ALIGN_LEFT);
                                        diff = diff + 1;
                                       
                                end
                               
                        end
                       
                end

                if istnb then
                    item = "cc_item*";
                else
                    item = "item_*"
                end
               
                for k, v in pairs(ents.FindByClass(item)) do
                       
                        if not noshow[v] then
                               
                                local base = v:GetPos():ToScreen();
                                local distance = tostring(math.Round(v:GetPos():Distance(LocalPlayer():EyePos()) / 39.37)) .. "m";
                                local itemname = v:GetModel();
                               
                                drawtext(string.gsub(itemname, "models/", ""), base.x, base.y, colors.item, alpha(v), TEXT_ALIGN_LEFT);
                                drawtext(distance, base.x + 20, base.y + 10, colors.item, alpha(v), TEXT_ALIGN_LEFT);
                               
                        end
                       
                end
               
                for k, v in pairs(ents.FindByClass("npc*")) do
                       
                        local base = v:GetPos():ToScreen();
                        local distance = tostring(math.Round(v:GetPos():Distance(LocalPlayer():EyePos()) / 39.37)) .. "m";
                        local itemname = v.ItemName or v:GetModel();
                       
                        drawtext(string.gsub(itemname, "models/", ""), base.x, base.y, colors.npc, alpha(v), TEXT_ALIGN_LEFT);
                        drawtext(distance, base.x + 20, base.y + 10, colors.npc, alpha(v), TEXT_ALIGN_LEFT);
                       
                end
               
        end
       
end
hook.Add("HUDPaint", "drawesp", drawesp);
 
------------------------------------------------------------------------
 
local function getents()
  for k, v in pairs(ents.FindByClass("*")) do
    output(v:GetClass())
  end
end
concommand.Add(".ents", getents);

local function esptoggle()
       
        esp = !esp;
       
end
concommand.Add(".esp", esptoggle);

local function tnb()
       
        istnb = !istnb;
       
end
concommand.Add(".tnb", tnb);
 
local function listplayers()
       
        local i = 0;
       
        for k, v in pairs(player.GetAll()) do
               
                i = i + 1;
                printplayer(v);
               
        end
       
        output(i .. " players total.");
       
end
concommand.Add(".lp", listplayers);
 
local function listadmins()
       
        local i = 0;
       
        for k, v in pairs(player.GetAll()) do
                if v:IsAdmin() then
                       
                        i = i + 1;
                        printplayer(v);
                       
                end
        end
       
        output(i .. " admins total.");
       
end
concommand.Add(".la", listadmins);
 
local function listweapons()
       
        local i = 0;
       
        for k, v in pairs(player.GetAll()) do
       
                printplayer(v);
               
                for _, weapon in pairs(v:GetWeapons()) do
                       
                        i = i + 1
                       
                        if not table.HasValue(weapons.neutral, weapon:GetClass()) and not table.HasValue(weapons.good, weapon:GetClass()) then
                                chat.AddText(colors.badweapon, "        " .. weapon:GetClass());
                        end
                       
                end
               
        end
       
        output(i .. " weapons total.");
       
end
concommand.Add(".lw", listweapons);
 
local function search(ply, cmd, args)
       
        if !args[1] then return; end
       
        term = args[1];
       
        local i = 0;
       
        for k, v in pairs(player.GetAll()) do
               
                if string.match(string.lower(rpname(v)), string.lower(term))
                or string.match(string.lower(v:Name()), string.lower(term)) then
                       
                        i = i + 1;
                        printplayer(v);
                       
                end
               
        end
       
        output("Found " .. i .. " matches.");
       
end
concommand.Add(".s", search);
 
local function who(ply, cmd, args)
       
        if !args[1] then return; end
       
        local name = string.lower(args[1]);
        local i = 0;
       
        for k, v in pairs(player.GetAll()) do
                if string.match(string.lower(rpname(v)), name) or string.match(string.lower(v:Name()), name) then
                       
                        i = i + 1;
                        target = v;
                       
                end
        end
       
        if i == 1 then
               
                if target:GetNWFloat("RPName") != 0 then
                        LocalPlayer():ConCommand("rpa_getinfo \"" .. rpname(target) .. "\"");
                else
                       
                        printplayer(target);
                        print("     Health: " .. target:Health() .. " [" .. target:Armor() .. "]");
                        print("     Model: " .. target:GetModel());
                        print("     SteamID: " .. target:SteamID());
                        print("     Weapons:");
                        for k, weapon in pairs(target:GetWeapons()) do
                                       
                                if not table.HasValue(weapons.neutral, weapon:GetClass()) and not table.HasValue(weapons.good,weapon:GetClass()) then
                                        print("          " .. weapon:GetClass());
                                end
                        end
                       
                end
               
        else
                output("Found " .. i .. " matches.");
        end
       
end
concommand.Add(".who", who);
 
local function cmdall(ply, cmd, args)
       
        if !args[1] then return; end
       
        local command = args[1];
        local arg = args[2];
       
        for k, v in pairs(player.GetAll()) do
                if v != LocalPlayer() or !v:IsAdmin() then
                       
                        local torun = command .. "\"" .. rpname(v) .. "\"";
                       
                        if arg then
                                torun = torun .. " " .. tostring(arg);
                        end
                       
                        LocalPlayer():ConCommand(torun);
                       
                end
        end
       
end
concommand.Add(".cmdall", cmdall);
 
local function spotplayer(ply, cmd, args)
       
        if !args[1] then return; end
       
        local name = string.lower(args[1]);
        local i = 0;
       
        for k, v in pairs(player.GetAll()) do
                if string.match(string.lower(rpname(v)), name) or string.match(string.lower(v:Name()), name) then
                       
                        i = i + 1;
                        spot[v] = true;
                       
                end
        end
        output("Highlighting " .. i .. " matches.");
       
end
concommand.Add(".spot", spotplayer);
 
local function unspot()
       
        spot = {};
       
end
concommand.Add(".unspot", unspot);

local function help()
       
        output("           .esp  Toggle item/player ESP.");
        output("      .who name  List information on a certain player.");
        output("        .s term  List players with term as their IC/OOC name.");
        output("            .la  List all admins/superadmins in game.");
        output("            .lp  List all players and their IC names.");
        output("            .lw  List all players' weapons.");
        output("     .spot name  Highlight player(s) on your ESP.");
        output("        .unspot  Clear all highlighted players.");
        output(".cmdall cmd arg  Do a command to everyone but yourself.");
       
end
concommand.Add(".help", help);
output("---- tsat loaded ----");