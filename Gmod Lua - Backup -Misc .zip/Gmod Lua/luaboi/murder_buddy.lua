--[[]
Scripts Already Defined
local cmdStr = "Anozira"














]]--


 
local cmdStr = "Anozira"
CreateClientConVar( cmdStr.."__weapons_esp", 1, true, false)
CreateClientConVar( cmdStr.."__loot_esp", 1, true, false)
CreateClientConVar( cmdStr.."__player_esp", 1, true, false)

chat.AddText( Color( 0, 180, 180 ), "[Murder Buddy] ", Color( 255, 255, 255 ), "Player ESP loaded successfully!" )
chat.AddText( Color( 0, 180, 180 ), "[Murder Buddy] ", Color( 255, 255, 255 ), "Loot ESP loaded successfully!" )
chat.AddText( Color( 0, 180, 180 ), "[Murder Buddy] ", Color( 255, 255, 255 ), "Weapon ESP loaded successfully!" )



surface.CreateFont("AnoziraDefault", { size = 25, weight = 500, antialias = true, font = "Coolvetica"})
surface.CreateFont("AnoziraMULoot", { size = 15, weight = 500, antialias = true, font = "Coolvetica"})

hook.Add( "HUDPaint", "Loot_esp", function()
if (GetConVarNumber(cmdStr.."__player_esp") == 1) then
	for k,v in pairs (ents.FindByClass("mu_loot")) do 
	local lootpos = ( v:GetPos() + Vector( 0,0,10 ) ):ToScreen()
	draw.DrawText( "Loot Found", "AnoziraMULoot", lootpos.x, lootpos.y, Color( 0, 255, 0, 255 ), 1 )
	halo.Add({v}, Color( 0, 255, 0, 250 ), 5, 1, 5, true, true);
	cam.Start3D()			
	v:SetMaterial( "" )
	v:DrawModel()				
	cam.End3D()
	end
	end
end )


hook.Add( "HUDPaint", "Weapon_esp", function()
if (GetConVarNumber(cmdStr.."__weapons_esp") == 1) then
	for k,v in pairs (ents.FindByClass("weapon_mu_magnum")) do 
	local gunpos = ( v:GetPos() + Vector( 0,0,10 ) ):ToScreen()
	draw.DrawText( "Gun!", "AnoziraDefault", gunpos.x, gunpos.y, Color( 255, 255, 0, 255 ), 1 )
	cam.Start3D()			
	v:SetMaterial( "" )
	v:DrawModel()				
	cam.End3D()
	end
		for k,v in pairs (ents.FindByClass("weapon_mu_knife")) do 
	local knifepos = ( v:GetPos() + Vector( 0,0,10 ) ):ToScreen()
	draw.DrawText( "Knife", "AnoziraDefault", knifepos.x, knifepos.y, Color( 255, 0, 0, 255 ), 1 )
	halo.Add({v}, Color( 255, 0, 0, 250 ), 5, 5, 3, true, true);
	cam.Start3D()			
	v:SetMaterial( "" )
	v:DrawModel()				
	cam.End3D()
	end
	end
end)

