hook.Add("PreDrawHalos", "", function()
	for k,v in next, player.GetAll() do
		if(v:Health() < 1) then continue; end
		if(v:IsDormant()) then continue; end
		if(v:Team() == LocalPlayer():Team()) then
		
		
		
		
		
			halo.Add({v}, Color(255,0,0,255), 2, 2, 1, true, true);
		else
			halo.Add({v}, Color(255,0,0,255), 2, 2, 1, true, true);
		
		
		
		
		end
	end
end);
--Orginal halo.Add({v}, Color(255, 65, 65), 2, 2, 1, false, true);
--Defcxon halo.Add({v}, Color(255,0,0,255), 2, 2, 1, true, true)