local PESP = CreateClientConVar("Prop_ESP", "1", true, false)
local Solic = CreateClientConVar("Prop_Solid", "1", true, false)
local names = CreateClientConVar("Prop_Names", "1", true, false)
local norecoil = CreateClientConVar("Prop_NoRecoil", "1", true, false)
local ply = LocalPlayer()

local function coordinates( ent )
	local min, max = ent:OBBMins(), ent:OBBMaxs()
	local corners = {
			Vector( min.x, min.y, min.z ),
			Vector( min.x, min.y, max.z ),
			Vector( min.x, max.y, min.z ),
			Vector( min.x, max.y, max.z ),
			Vector( max.x, min.y, min.z ),
			Vector( max.x, min.y, max.z ),
			Vector( max.x, max.y, min.z ),
			Vector( max.x, max.y, max.z )
	}
 
	local minX, minY, maxX, maxY = ScrW() * 2, ScrH() * 2, 0, 0
	for _, corner in pairs( corners ) do
		local onScreen = ent:LocalToWorld( corner ):ToScreen()
        minX, minY = math.min( minX, onScreen.x ), math.min( minY, onScreen.y )
        maxX, maxY = math.max( maxX, onScreen.x ), math.max( maxY, onScreen.y )
	end
 
	return minX, minY, maxX, maxY
end
hook.Remove("CreateMove", "UnBlind", function()
    if ply:Blind() then
        ply:Blind(false)
    end
    ply:Freeze(false)
end)

hook.Add("HUDPaint", "ESPs", function()
    if PESP:GetInt() == 1 then
	for k, v in pairs(ents.FindByClass("ph_prop")) do
		if v.Owner != ply then
		cam.Start3D(EyePos(), EyeAngles())
        v:SetMaterial("models/wireframe")
		v:SetColor(Color(255, 0, 0, 255))
		render.MaterialOverride("models/wireframe")
		render.SuppressEngineLighting( false )
		render.SetBlend( 0.3 )
		render.SetColorModulation( 1, 0, 0 )
		v:DrawModel()
        if Solic:GetInt() == 1 then
            v:SetMaterial("models/debug/debugwhite")
            render.MaterialOverride("models/debug/debugwhite")
            v:DrawModel()
        end
		cam.End3D()
        if names:GetInt() == 1 then
            local ESP = (v:EyePos()):ToScreen()
			local col = Color(255, 0, 0)
			local x1,y1,x2,y2 = coordinates(v)
			draw.DrawText(v.Owner:Name(), "DefaultFixed", ESP.x, ESP.y, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
        end
		end
	end
	for k,v in pairs(player.GetAll()) do
			for k,v2 in pairs(v:GetWeapons()) do
				if v2:GetClass() == "weapon_crowbar" && v != ply then
					cam.Start3D(EyePos(), EyeAngles())
					v:SetMaterial("models/wireframe")
					v:SetColor(Color(0, 255, 0, 255))
					render.MaterialOverride("models/wireframe")
					render.SuppressEngineLighting( false )
					render.SetBlend( 0.3 )
					render.SetColorModulation( 0, 1, 0 )
					v:DrawModel()
					if Solic:GetInt() == 1 then
						v:SetMaterial("models/debug/debugwhite")
						render.MaterialOverride("models/debug/debugwhite")
						v:DrawModel()
					end
					cam.End3D()
					if names:GetInt() == 1 then
						local ESP = (v:EyePos()):ToScreen()
						local col = Color(0, 255, 0)
						local x1,y1,x2,y2 = coordinates(v)
						draw.DrawText(v:Name(), "DefaultFixed", ESP.x, ESP.y, col, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT)
					end
				end
			end
		end
    end
end)

function string.starts(String,Start)
   return string.sub(String,1,string.len(Start))==Start
end

function mute(ply, cmd, args)
    for k,v in pairs(player.GetAll()) do
        if string.find(string.lower(v:Name()), string.lower(args[1])) then
            if v:IsMuted() then
                v:SetMuted(false)
                chat.AddText(v:Name(), " is no longer muted.")
            else
                v:SetMuted(true)
                chat.AddText(v:Name(), " is now muted.")
            end
        end
    end
end
concommand.Add("Prop_Mute", mute)

// SpiritWalk by RabidToaster
// Original concept by RabidToaster + Devenger
 
local SW = {}
 
SW.Enabled = false
SW.ViewOrigin = Vector( 0, 0, 0 )
SW.ViewAngle = Angle( 0, 0, 0 )
SW.Velocity = Vector( 0, 0, 0 )
 
function SW.CalcView( ply, origin, angles, fov )
        if ( !SW.Enabled ) then return end
        if ( SW.SetView ) then
                SW.ViewOrigin = origin
                SW.ViewAngle = angles
               
                SW.SetView = false
        end
        return { origin = SW.ViewOrigin, angles = SW.ViewAngle }
end
hook.Add( "CalcView", "SpiritWalk", SW.CalcView )
 
function SW.CreateMove( cmd )
        if ( !SW.Enabled ) then return end
       
        // Add and reduce the old velocity.
        local time = FrameTime()
        SW.ViewOrigin = SW.ViewOrigin + ( SW.Velocity * time )
        SW.Velocity = SW.Velocity * 0.95
       
        // Rotate the view when the mouse is moved.
        local sensitivity = 0.022
        SW.ViewAngle.p = math.Clamp( SW.ViewAngle.p + ( cmd:GetMouseY() * sensitivity ), -89, 89 )
        SW.ViewAngle.y = SW.ViewAngle.y + ( cmd:GetMouseX() * -1 * sensitivity )
       
        // What direction we're going to move in.
        local add = Vector( 0, 0, 0 )
        local ang = SW.ViewAngle
        if ( cmd:KeyDown( IN_FORWARD ) ) then add = add + ang:Forward() end
        if ( cmd:KeyDown( IN_BACK ) ) then add = add - ang:Forward() end
        if ( cmd:KeyDown( IN_MOVERIGHT ) ) then add = add + ang:Right() end
        if ( cmd:KeyDown( IN_MOVELEFT ) ) then add = add - ang:Right() end
        if ( cmd:KeyDown( IN_JUMP ) ) then add = add + ang:Up() end
        if ( cmd:KeyDown( IN_DUCK ) ) then add = add - ang:Up() end
       
        // Speed.
        add = add:GetNormal() * time * 10000
        if ( cmd:KeyDown( IN_SPEED ) ) then add = add * 2 end
       
        SW.Velocity = SW.Velocity + add
       
        // This stops us looking around crazily while spiritwalking.
        if ( SW.LockView == true ) then
                SW.LockView = cmd:GetViewAngles()
        end
        if ( SW.LockView ) then
                cmd:SetViewAngles( SW.LockView )
        end
       
        // This stops us moving while spiritwalking.
        cmd:SetForwardMove( 0 )
        cmd:SetSideMove( 0 )
        cmd:SetUpMove( 0 )
end
hook.Add( "CreateMove", "SpiritWalk", SW.CreateMove )
 
function SW.Toggle()
        SW.Enabled = !SW.Enabled
        SW.LockView = SW.Enabled
        SW.SetView = true
       
        local status = { [ true ] = "ON", [ false ] = "OFF" }
        chat.AddText( "SpiritWalk " .. status[ SW.Enabled ] )
end
concommand.Add( "Prop_SWToggle", SW.Toggle )

function WeaponCheck()
 
if !ply:Alive() then return false end
 
if ply:Alive() and ply:GetActiveWeapon():IsValid() then
 
Weapon = LocalPlayer():GetActiveWeapon():GetClass()
 
else return false
 
end

function NoRecoil()
    if norecoil:GetInt() == 1 and WeaponCheck() and ply:Alive() and ply:GetActiveWeapon():IsValid() and ply:GetActiveWeapon().Primary then
        ply:GetActiveWeapon().Primary.Recoil = 0
    else
        return end
    end
end
 
hook.Add("Think", "Norecoil", NoRecoil)

function HUD()
    local health = ply:Health()
    if health > 0 then
    drawroundedBox(0, 5, ScrH() - 15 - 20, health, 15, Color(255,0,0,255))
        draw.SimpleText(health, "default", 10, ScrH() - 15 - 40, Color(255,255,255,255))
    end
end
hook.Add("HUDPaint", "MyHUD", HUD)

function hidehud(name)
	for k, v in pairs({"CHudHealth", "CHudBattery"})do
		if name == v then return false end
	end
end
hook.Add("HUDShouldDraw", "HideOurHud:D", hidehud)

function GUI()
    local Frame = vgui.Create( "DFrame" )
    Frame:SetSize( 125, 330 )
    Frame:SetPos( 20, 50 )
    //Frame:Center()
    Frame:SetVisible( true )
    Frame:SetDraggable(false)
    Frame:SetTitle("PropHunt GUI")
    Frame:ShowCloseButton(true)
    Frame:MakePopup( )
    
    local PropLabel = vgui.Create( "DLabel", Frame)
    PropLabel:SetText("Prop hacks")
    PropLabel:SetPos( 15,30 )
    PropLabel:SizeToContents()
    
    PropList = vgui.Create( "DPanelList", Frame)
    PropList:SetSize( 100, 55 )
    PropList:SetPos( 10,50 )
    PropList:SetSpacing( 5 )
    PropList:SetDrawBackground(true)
    PropList.Paint = function()
        drawroundedBox(6, 0, 0, PropList:GetWide(), PropList:GetTall(), Color(0, 0, 0, 255))
    end
    PropList:EnableVerticalScrollbar( false)
    
    local ESPCheckBox = vgui.Create( "DCheckBoxLabel")
    ESPCheckBox:SetText( "ESP" )
    ESPCheckBox:SetConVar( "Prop_ESP" )
    ESPCheckBox:SetValue( PESP:GetInt() )
    ESPCheckBox:SizeToContents()
    PropList:AddItem(ESPCheckBox)
    
    local NamesCheckBox = vgui.Create( "DCheckBoxLabel")
    NamesCheckBox:SetText( "Names" )
    NamesCheckBox:SetConVar( "Prop_Names" )
    NamesCheckBox:SetValue( names:GetInt() )
    NamesCheckBox:SizeToContents()
    PropList:AddItem(NamesCheckBox)
    
    local SolidCheckBox = vgui.Create( "DCheckBoxLabel")
    SolidCheckBox:SetText( "Solid ESP" )
    SolidCheckBox:SetConVar( "Prop_Solid" )
    SolidCheckBox:SetValue( Solic:GetInt() )
    SolidCheckBox:SizeToContents()
    PropList:AddItem(SolidCheckBox)
    
    local PropLabel = vgui.Create( "DLabel", Frame)
    PropLabel:SetText("Misc hacks")
    PropLabel:SetPos( 15, 115 )
    PropLabel:SizeToContents()
    
    MiscList = vgui.Create( "DPanelList", Frame)
    MiscList:SetSize( 100, 87 )
    MiscList:SetPos( 10,135 )
    MiscList:SetSpacing( 5 )
    MiscList:SetDrawBackground(true)
    MiscList.Paint = function()
        drawroundedBox(6, 0, 0, MiscList:GetWide(), MiscList:GetTall(), Color(0, 0, 0, 255))
    end
    MiscList:EnableVerticalScrollbar( false)
    
    local text = vgui.Create( "DTextEntry");
    text:SetWide(100)
    text:SetText("Player to mute")
    text.OnEnter = function(self)
        for k,v in pairs(player.GetAll()) do
            if string.find(string.lower(v:Name()), string.lower(self:GetValue())) then
                if v:IsMuted() then
                    v:SetMuted(false)
                    chat.AddText(v:Name(), " is no longer muted.")
                    text:SetText("Player to mute")
                else
                    v:SetMuted(true)
                    chat.AddText(v:Name(), " is now muted.")
                    text:SetText("Player to mute")
                end
            end
        end
    end
    text.OnGetFocus = function (self)
        if self:GetValue() == "Player to mute" then
            self:SetText("")
        end
    end
    text.OnLoseFocus = function (self)
        if self:GetValue() == "" then
            self:SetText("Player to mute")
        end
    end
    MiscList:AddItem(text)
    
    local MutedButton = vgui.Create( "DButton")
    MutedButton:SetWide(100)
    MutedButton:SetText( "Muted Players" )
    MutedButton.DoClick = function()
        local count = 0
        for k, v in pairs(player.GetAll()) do
            if v:IsMuted() then
                chat.AddText(v:Name(), " is muted.")
                count = count + 1
            end
        end
        if count == 0 then
            chat.AddText("No players muted.")
        end
    end
    MiscList:AddItem(MutedButton)
    
    local SWCheckBox = vgui.Create("DCheckBoxLabel")
    SWCheckBox:SetText( "Spirit Walk" )
    SWCheckBox:SetChecked(SW.Enabled)
    SWCheckBox:SizeToContents()
    SWCheckBox.OnChange = function()
        RunConsoleCommand("Prop_SWToggle")
    end
    MiscList:AddItem(SWCheckBox)
    
    local recoilCheckBox = vgui.Create("DCheckBoxLabel")
    recoilCheckBox:SetText( "No Recoil" )
    recoilCheckBox:SetConVar( "Prop_NoRecoil" )
    recoilCheckBox:SetValue( norecoil:GetInt() )
    recoilCheckBox:SizeToContents()
    MiscList:AddItem(recoilCheckBox)
    
    local PropLabel = vgui.Create( "DLabel", Frame)
    PropLabel:SetText("Spammer")
    PropLabel:SetPos( 15, 230 )
    PropLabel:SizeToContents()
    
    SpamList = vgui.Create( "DPanelList", Frame)
    SpamList:SetSize( 100, 72 )
    SpamList:SetPos( 10,250 )
    SpamList:SetSpacing( 5 )
    SpamList:SetDrawBackground(true)
    SpamList.Paint = function()
        drawroundedBox(6, 0, 0, SpamList:GetWide(), SpamList:GetTall(), Color(0, 0, 0, 255))
    end
    SpamList:EnableVerticalScrollbar( false)
    
    local spam = vgui.Create( "DTextEntry");
    spam:SetWide(100)
    spam:SetText("Message to spam")
    spam.OnGetFocus = function (self)
        if self:GetValue() == "Message to spam" then
            self:SetText("")
        end
    end
    spam.OnLoseFocus = function (self)
        if self:GetValue() == "" then
            self:SetText("Message to spam")
        end
    end
    SpamList:AddItem(spam)
    
    local times = vgui.Create( "DTextEntry");
    times:SetWide(100)
    times:SetText("10")
    times.OnLoseFocus = function (self)
        if self:GetValue() == "" then
            self:SetText("10")
        end
    end
    SpamList:AddItem(times)
    
    local SpamButton = vgui.Create( "DButton")
    SpamButton:SetWide(100)
    SpamButton:SetText( "Spam!" )
    SpamButton.DoClick = function()
        timer.Create("SpamTimer", 0.1, tonumber(times:GetValue()), function()
            ply:ConCommand("say " .. spam:GetValue())
        end)
    end
    SpamList:AddItem(SpamButton)
end

concommand.Add("Prop_GUI", GUI)