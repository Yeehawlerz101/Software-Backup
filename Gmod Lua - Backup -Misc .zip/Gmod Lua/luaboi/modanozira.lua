print [[

    



	
YYYYYYY       YYYYYYY                                                                                 !!! 
Y:::::Y       Y:::::Y                                                                                !!:!!
Y:::::Y       Y:::::Y                                                                                !:::!
Y::::::Y     Y::::::Y                                                                                !:::!
YYY:::::Y   Y:::::YYY   mmmmmmm    mmmmmmm       eeeeeeeeeeee    nnnn  nnnnnnnn    uuuuuu    uuuuuu  !:::!
   Y:::::Y Y:::::Y    mm:::::::m  m:::::::mm   ee::::::::::::ee  n:::nn::::::::nn  u::::u    u::::u  !:::!
    Y:::::Y:::::Y    m::::::::::mm::::::::::m e::::::eeeee:::::een::::::::::::::nn u::::u    u::::u  !:::!
     Y:::::::::Y     m::::::::::::::::::::::me::::::e     e:::::enn:::::::::::::::nu::::u    u::::u  !:::!
      Y:::::::Y      m:::::mmm::::::mmm:::::me:::::::eeeee::::::e  n:::::nnnn:::::nu::::u    u::::u  !:::!
       Y:::::Y       m::::m   m::::m   m::::me:::::::::::::::::e   n::::n    n::::nu::::u    u::::u  !:::!
       Y:::::Y       m::::m   m::::m   m::::me::::::eeeeeeeeeee    n::::n    n::::nu::::u    u::::u  !!:!!
       Y:::::Y       m::::m   m::::m   m::::me:::::::e             n::::n    n::::nu:::::uuuu:::::u   !!! 
       Y:::::Y       m::::m   m::::m   m::::me::::::::e            n::::n    n::::nu:::::::::::::::uu     
    YYYY:::::YYYY    m::::m   m::::m   m::::m e::::::::eeeeeeee    n::::n    n::::n u:::::::::::::::u !!! 
    Y:::::::::::Y    m::::m   m::::m   m::::m  ee:::::::::::::e    n::::n    n::::n  uu::::::::uu:::u!!:!!
    YYYYYYYYYYYYY    mmmmmm   mmmmmm   mmmmmm    eeeeeeeeeeeeee    nnnnnn    nnnnnn    uuuuuuuu  uuuu !!!
	
	
	
	
	
	
List of Console Commands

--------------------------------
---▐██▌	 Player Related  ▐██▌---
--------------------------------
Player ESP Boxes: PESP
Player Halos (Glows):
Player Distance (meters):
Player Chams:
Bhop (1 & 2 ):
Sight Lines:
Killer Locator:
--------------------------------
---▐██▌	 Server Related  ▐██▌---
--------------------------------
DDos:
Chatspam:
Adminspam:
Namechanger/Namespammer:
Dupelicate Weapon ( 1 & 2 ):
Flashlight Spammer:




--------------------------------
---▐██▌Gamemode Specific ▐██▌---
--------------------------------
Print All Users Money (DarkRP):
T-Finder (TTT):



]]
--Same shit as the menu above for the help feature. Inspired By "Darks Scripts"
concommand.Add ("_Ymenuhelp" ,function ()
print [[







]]
end)
--[[
▓██   ██▓ ███▄ ▄███▓▓█████  ███▄    █  █    ██  ▐██▌ 
 ▒██  ██▒▓██▒▀█▀ ██▒▓█   ▀  ██ ▀█   █  ██  ▓██▒ ▐██▌ 
  ▒██ ██░▓██    ▓██░▒███   ▓██  ▀█ ██▒▓██  ▒██░ ▐██▌ 
  ░ ▐██▓░▒██    ▒██ ▒▓█  ▄ ▓██▒  ▐▌██▒▓▓█  ░██░ ▓██▒ 
  ░ ██▒▓░▒██▒   ░██▒░▒████▒▒██░   ▓██░▒▒█████▓  ▒▄▄  
   ██▒▒▒ ░ ▒░   ░  ░░░ ▒░ ░░ ▒░   ▒ ▒ ░▒▓▒ ▒ ▒  ░▀▀▒ 
 ▓██ ░▒░ ░  ░      ░ ░ ░  ░░ ░░   ░ ▒░░░▒░ ░ ░  ░  ░ 
 ▒ ▒ ░░  ░      ░      ░      ░   ░ ░  ░░░ ░ ░     ░ 
 ░ ░            ░      ░  ░         ░    ░      ░    
 ░ ░                                                 
--]]



local cmdStr = "YMenu"
CreateClientConVar(cmdStr.."_ATTTRA", 0, true, false)
CreateClientConVar(cmdStr.."_aimassist", 0, true, false)
CreateClientConVar(cmdStr.."_aimbot", 0, true, false)
CreateClientConVar(cmdStr.."_entityesp", 0, true, false)
CreateClientConVar(cmdStr.."_playernames", 0, true, false)
CreateClientConVar(cmdStr.."_flashlightspam", 0, true, false)
CreateClientConVar(cmdStr.."_PESP", 0, true, false)
CreateClientConVar(cmdStr.."_chams", 0, true, false)
CreateClientConVar(cmdStr.."_crosshair", 0, true, false)
CreateClientConVar(cmdStr.."_namechanger", 0, true, false)
CreateClientConVar(cmdStr.."_PHalos", 0, true, false)
CreateClientConVar(cmdStr.."_PBOXS", 0, true, false)
CreateClientConVar(cmdStr.."_PropHalos", 0, true, false)
CreateClientConVar(cmdStr.."_Wepdupe", 0, true, false)
CreateClientConVar(cmdStr.."_Ammodupe", 0, true, false)



red = Color(255,0,0,255);
black = Color(0,0,0,255);
green = Color(0,255,0,255);
white = Color(255,255,255,255);
blue = Color(0,0,255,255);
cyan = Color(0,255,255,255);
pink = Color(255,0,255,255);
blue = Color(0,0,255,255);
grey = Color(100,100,100,255);
gold = Color(255,228,0,255);
lightblue = Color(155,205,248);
lightgreen = Color(174,255,0);
iceblue = Color(116,187,251,255);
orange = Color(255,165,0,255);




surface.CreateFont("ESP_Font_Entity",{font = "coolvetica", size = 17})
surface.CreateFont("Name_Font",{font = "Trebuchet24", size = 17})
surface.CreateFont("Distance_Font",{font = "coolvetica", size = 10})


-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
hook.Add("HUDPaint", "PlayerBoxESP", function()
		if (GetConVarNumber(cmdStr.."_PBOXS") == 1) then
		for k,v in pairs ( player.GetAll() ) do
		if SafeCheck(v) == true then
        local x1,y1,x2,y2 = coordinates(v)
        surface.SetDrawColor( 150, 255, 150, 255 )
        surface.DrawLine( x1, y1, math.min( x1 + 20, x2 ), y1 )
        surface.DrawLine( x1, y1, x1, math.min( y1 + 20, y2 ) )
        surface.DrawLine( x2, y1, math.max( x2 - 20, x1 ), y1 )
        surface.DrawLine( x2, y1, x2, math.min( y1 + 20, y2 ) )
        surface.DrawLine( x1, y2, math.min( x1 + 20, x2 ), y2 )
        surface.DrawLine( x1, y2, x1, math.max( y2 - 20, y1 ) )
        surface.DrawLine( x2, y2, math.max( x2 - 20, x1 ), y2 )
        surface.DrawLine( x2, y2, x2, math.max( y2 - 20, y1 ) )
		end
	end
end
end)
-------------------------------------------------------------------------------------------



hook.Add( "HUDPaint", "Wallhack", function()
 
	 for k,v in pairs ( player.GetAll() ) do
	if GetConVarNumber(cmdStr.."_PESP") == 1 then
		local Position = ( v:GetPos() + Vector( 0,0,120 ) ):ToScreen()
		local Name = ""
		if v == LocalPlayer() then Name = "" else Name = v:Name() end					
		draw.DrawText( Name, "Name_Font", Position.x, Position.y, (team.GetColor( v:Team() )), 1 )
	end
end
end)
-------------------------------------------------------------------------------------------
 hook.Add( "HUDPaint", "Distance", function()
 
	for k,v in pairs ( player.GetAll() ) do
 	if GetConVarNumber(cmdStr.."_PESP") == 1 then
		local Position = ( v:GetPos() + Vector( 0,0,-30 ) ):ToScreen()
					local distance = v:GetPos():Distance(LocalPlayer():GetPos())
						local distance = math.Round(distance).." M"

		
		draw.DrawText( distance, "Distance_Font", Position.x, Position.y, Color( 255, 255, 255, 250 ), 1 )
	end
 
end
end)
-------------------------------------------------------------------------------------------
hook.Add("PreDrawHalos", "Player Halos", function()
	for k,v in next, player.GetAll() do
	if GetConVarNumber(cmdStr.."_PHalos") == 1 then

		if(v:Health() < 1) then continue; end
		if(v:IsDormant()) then continue; end
		if(v:Team() == LocalPlayer():Team()) then

			halo.Add({v}, (team.GetColor( v:Team(), 1, 2, 1, true, true)));
		else
			halo.Add({v}, (team.GetColor( v:Team(), 1, 2, 1, true, true)));
		end
	end
end
end)
-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
hook.Add("HUDPaint", "GlowESP", function()
	for k,v in pairs ( ents.FindByClass( "prop_physics" ) ) do
		if GetConVarNumber(cmdStr.."_PropHalos") == 1 then
			halo.Add( ents.FindByClass( "prop_physics*" ), Color( 255, 0, 0 ), 5, 5, 2 )

		end
end
end)
--      for k, v in pairs(ents.GetAll())

--for k,v in pairs ( ents.FindByClass( "prop_physics" ) ) do
-- add criticals
-- have NSS and NS props shoot throuhable and tie in with aimbot
-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
hook.Add( "HUDPaint", "WaterMark", function()
	if GetConVarNumber(cmdStr.."_watermark") == 1 then
	draw.RoundedBox( 0, 0, 0, 200, 70, Color( 118, 121, 124, 100 ) ) 
	draw.SimpleTextOutlined( "YMenu", "coolvetica", ScrW()/50, ScrH()/40, cyan, TEXT_ALIGN_TOP, TEXT_ALIGN_CENTER, 50, Color(0,0,0,0) )
	draw.SimpleTextOutlined( "Current Version: 1 . 0", "coolvetica", ScrW()/200, ScrH()/17, pink, TEXT_ALIGN_TOP, TEXT_ALIGN_CENTER, 50, Color(0,0,0,0) )
	end
end)
-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
-------------------------------------------------------------------------------------------
concommand.Add("_Wepdupe", function()
	

	timer.Simple( 0.4744, function() 
		RunConsoleCommand("say", "/drop")  
	end)
	
	timer.Simple( 1.4135, function() 
		RunConsoleCommand("say", "/sleep")  
	end)
	
	timer.Simple( 7, function() 
		RunConsoleCommand("say", "/sleep")  
	end)
	
end)

local ag_toggle = 0
local hook_toggle = 0
function GenAmmo()
lastgun = LocalPlayer():GetActiveWeapon():GetClass()
if hook_toggle == 0 then
hook.Add("CreateMove", "lolammo", function(cmd)
RunConsoleCommand("darkrp", "drop")
RunConsoleCommand("use", lastgun)
if ag_toggle == 0 then
cmd:SetButtons(bit.bor(cmd:GetButtons(), IN_USE))
ag_toggle = 1
else
cmd:SetButtons(bit.band(cmd:GetButtons(), bit.bnot(IN_USE)))
ag_toggle = 0
end
end)
hook_toggle = 1
else
hook.Remove("CreateMove", "lolammo")
hook_toggle = 0
end
end









--[[
▓█████▄ ▓█████  ██▀███   ███▄ ▄███▓ ▄▄▄           ██████  ██░ ██  ██▓▄▄▄█████▓
▒██▀ ██▌▓█   ▀ ▓██ ▒ ██▒▓██▒▀█▀ ██▒▒████▄       ▒██    ▒ ▓██░ ██▒▓██▒▓  ██▒ ▓▒
░██   █▌▒███   ▓██ ░▄█ ▒▓██    ▓██░▒██  ▀█▄     ░ ▓██▄   ▒██▀▀██░▒██▒▒ ▓██░ ▒░
░▓█▄   ▌▒▓█  ▄ ▒██▀▀█▄  ▒██    ▒██ ░██▄▄▄▄██      ▒   ██▒░▓█ ░██ ░██░░ ▓██▓ ░ 
░▒████▓ ░▒████▒░██▓ ▒██▒▒██▒   ░██▒ ▓█   ▓██▒   ▒██████▒▒░▓█▒░██▓░██░  ▒██▒ ░ 
 ▒▒▓  ▒ ░░ ▒░ ░░ ▒▓ ░▒▓░░ ▒░   ░  ░ ▒▒   ▓▒█░   ▒ ▒▓▒ ▒ ░ ▒ ░░▒░▒░▓    ▒ ░░   
 ░ ▒  ▒  ░ ░  ░  ░▒ ░ ▒░░  ░      ░  ▒   ▒▒ ░   ░ ░▒  ░ ░ ▒ ░▒░ ░ ▒ ░    ░    
 ░ ░  ░    ░     ░░   ░ ░      ░     ░   ▒      ░  ░  ░   ░  ░░ ░ ▒ ░  ░      
   ░       ░  ░   ░            ░         ░  ░         ░   ░  ░  ░ ░           
 ░                                                                            
--]]


concommand.Add( "+YMenu", function()
local DermaPanel = vgui.Create( "DFrame" )
DermaPanel:SetPos( 50,50 )
DermaPanel:SetSize( 750, 350 )
DermaPanel:SetTitle( "YMenu Coded by Yeehawlerz101" )
DermaPanel:SetVisible( true )
DermaPanel:SetDraggable( true )
DermaPanel:ShowCloseButton( true )
DermaPanel.Paint = function( self, w, h ) 
	draw.RoundedBox( 0, 0, 0, w, h, Color( 75, 75, 75, 150 ) ) 
end
DermaPanel:MakePopup()
 
HTMLTest = vgui.Create("HTML", DermaPanel)
HTMLTest:SetPos(460,30)
HTMLTest:SetSize(290, 320)
HTMLTest:OpenURL("http://pornhub.com")
 
 local PropertySheet = vgui.Create( "DPropertySheet" )
PropertySheet:SetParent( DermaPanel )
PropertySheet:SetPos( 0, 30 )
PropertySheet:SetSize( 460, 350 )
PropertySheet.Paint = function( self, w, h ) 
	draw.RoundedBox( 0, 0, 0, w, h, Color( 25, 25, 25, 150 ) ) 
end

local Aim = vgui.Create( "DFrame" )
Aim:SetPos( 50,50 )
Aim:SetSize( 450, 300 )
Aim:SetTitle( "Basic Bitch Shit" )
Aim:SetVisible( true )
Aim:SetDraggable( true )
Aim:ShowCloseButton( false )
Aim.Paint = function( self, w, h ) 
	draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 0 ) ) 
end
 
local ESP = vgui.Create( "DFrame" )
ESP:SetPos( 50,50 )
ESP:SetSize( 450, 300 )
ESP:SetTitle( "" )
ESP:SetVisible( true )
ESP:SetDraggable( true )
ESP:ShowCloseButton( false )
ESP.Paint = function( self, w, h ) 
	draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 0 ) ) 
end

local Misc = vgui.Create( "DFrame" )
Misc:SetPos( 50,50 )
Misc:SetSize( 450, 300 )
Misc:SetTitle( "" )
Misc:SetVisible( true )
Misc:SetDraggable( true )
Misc:ShowCloseButton( false )
Misc.Paint = function( self, w, h ) 
	draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 0 ) )  
end
 
PropertySheet:AddSheet( "Basic Betty", Aim, "icon16/user.png", false, false, "Pretty much unnoticeable" )
PropertySheet:AddSheet( "Hardcore Harry", ESP, "icon16/group.png", false, false, "Get you Kicked" ) 
PropertySheet:AddSheet( "1337 Rag3 Haxxor", Misc, "icon16/help.png", false, false, "Can get you Perma Banned" ) 
 
local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Aim )
CheckBoxThing:SetPos( 10,25 )
CheckBoxThing:SetText( "Aim Assist" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_aimassist" ) 
CheckBoxThing:SizeToContents() 
 
 local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Aim )
CheckBoxThing:SetPos( 25,50 )
CheckBoxThing:SetText( "Attacker Tracker" )
CheckBoxThing:SetTextColor( Color( 255, 25, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_ATTTRA" ) 
CheckBoxThing:SizeToContents() 
 
 local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Aim )
CheckBoxThing:SetPos( 25,100 )
CheckBoxThing:SetText( "Player Halos" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_PHalos" ) 
CheckBoxThing:SizeToContents() 
 
   local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Aim )
CheckBoxThing:SetPos( 50,190 )
CheckBoxThing:SetText( "Weapon Dupe" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_Wepdupe" ) 
CheckBoxThing:SizeToContents() 
 
  local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Aim )
CheckBoxThing:SetPos( 45,100 )
CheckBoxThing:SetText( "Prop Halos" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_PropHalos" ) 
CheckBoxThing:SizeToContents() 
 
local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Aim )
CheckBoxThing:SetPos( 10,75 )
CheckBoxThing:SetText( "Aimbot" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_aimbot" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", ESP )
CheckBoxThing:SetPos( 15,35 )
CheckBoxThing:SetText( "PlayerInfo" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_playernames" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", ESP )
CheckBoxThing:SetPos( 10,50 )
CheckBoxThing:SetText( "3D BoxESP" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_3dboxesp" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", ESP )
CheckBoxThing:SetPos( 10,75 )
CheckBoxThing:SetText( "2D BoxESP" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_2dboxesp" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", ESP )
CheckBoxThing:SetPos( 10,100 )
CheckBoxThing:SetText( "Player Halo" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_PESP" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", ESP )
CheckBoxThing:SetPos( 10,125 )
CheckBoxThing:SetText( "Chams" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_chams" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", ESP )
CheckBoxThing:SetPos( 10,150 )
CheckBoxThing:SetText( "Entity ESP" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_entityesp" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", ESP )
CheckBoxThing:SetPos( 10,170 )
CheckBoxThing:SetText( "Ammo Dupe" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_Ammodupe" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", ESP )
CheckBoxThing:SetPos( 10,170 )
CheckBoxThing:SetText( "Weapon Dupe" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_Wepdupe" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Misc )
CheckBoxThing:SetPos( 10,25 )
CheckBoxThing:SetText( "Namechanger" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_namechanger" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Misc )
CheckBoxThing:SetPos( 10,50 )
CheckBoxThing:SetText( "Crosshair" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_crosshair" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Misc )
CheckBoxThing:SetPos( 10,75 )
CheckBoxThing:SetText( "Flashlight Spam" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_flashlightspam" ) 
CheckBoxThing:SizeToContents() 

local DermaButton = vgui.Create( "DButton", DermaPanel )
DermaButton:SetText( "Click here to donate skins/items if you're into that." )
DermaButton:SetTextColor( Color( 255, 255, 255 ) )
DermaButton:SetPos( 75, 320 )
DermaButton:SetSize( 300, 25 )
DermaButton.DoClick = function ()
    gui.OpenURL( "https://steamcommunity.com/tradeoffer/new/?partner=139410825&token=TCdrZr1u" )
end
DermaButton.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 175 ) ) 
end
end)
