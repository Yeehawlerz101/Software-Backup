--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~--
-- Hey! My name is Xeaxos and I am the creator of Anozira. --
-- Before you get to looking at the code, please take a    --
-- few things into consideration. They will be listed      --
-- below. Thanks, and have a GREAT day!            -Xeaxos --
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~--
-- 1. I didn't write everything myself. It took time, but everything is custom enough that I can confidintly say
-- that I a. only used open source code and b. have edited it enough that I don't feel that it is really copying.

-- 2. I took a long time to write this code and people saying that it's nice goes a LONG way. Trust me.

-- From here on is the client, thanks for having a listen. 
--~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~--

-- Commands --
-- Desc: In order to run hacks, the menu has to tie each one to a command. This is where they're put. --

local cmdStr = "Anozira"
CreateClientConVar(cmdStr.."_namechanger", 1, true, false)
CreateClientConVar(cmdStr.."_chams", 1, true, false)
CreateClientConVar(cmdStr.."_crosshair", 1, true, false)
CreateClientConVar(cmdStr.."_playerinfo", 1, true, false)
CreateClientConVar(cmdStr.."_aimbot", 1, true, false)
CreateClientConVar(cmdStr.."_aimassist", 1, true, false)
CreateClientConVar(cmdStr.."_boxesp", 1, true, false)
CreateClientConVar( cmdStr.."_entityesp", 1, true, true)

-- Colors --
-- Desc: Just writing colors so instead of numbers I can just use terms like red or blue later on. --

red = Color(255,0,0,255);
black = Color(0,0,0,255);
green = Color(0,255,0,255);
white = Color(255,255,255,255);
blue = Color(0,0,255,255);
cyan = Color(0,255,255,255);
pink = Color(255,0,255,255);
blue = Color(0,0,255,255);
grey = Color(100,100,100,255);
gold = Color(255,228,0,255);
lightblue = Color(155,205,248);
lightgreen = Color(174,255,0);
iceblue = Color(116,187,251,255);

-- Startup Config --
-- Desc: Anything that happens when the client starts will appear here. Sounds, text, etc. --
	
local function SafeCheck(v)
    if v ~=LocalPlayer() and v:Alive() and v:IsValid() and v:GetActiveWeapon():IsValid() and v:Health() >= 1 then
        return true
    else
        return false
    end
end

chat.AddText( cyan, "[Anozira] ", pink, "Initialized!")
chat.AddText( cyan, "[Anozira] ", pink, "v1.3 Made by: Xeaxos")
chat.AddText( cyan, "[Anozira] ", pink, "To open the menu, type +AnoziraMenu in console!")
chat.AddText( cyan, "[Anozira] ", pink, "Aimbot: B (Be sure to enable it in hack menu first!)")

LocalPlayer():EmitSound("UI/buttonclick.wav", 500, 100)

print( "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" )
print( "[Anozira] Initialized!")
print( "[Anozira] v1.3 Made by: Xeaxos")
print( "[Anozira] To open the menu, type +AnoziraMenu in console!")
print( "[Anozira] Aimbot: B (Be sure to enable it in hack menu first!)")
print( "~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~~" )

-- Fonts --
-- Desc: Custom fonts I can call upon later for drawling things. --

surface.CreateFont("AnoziraPlayerTitle", { size = 14, weight = 500, antialias = true, font = "Coolvetica"})
surface.CreateFont("AnoziraPlayerInfo", { size = 14, weight = 500, antialias = true, font = "Coolvetica"})
surface.CreateFont("AnoziraDefault", { size = 25, weight = 500, antialias = true, font = "Coolvetica"})

-- AntiLuaStealer --
-- Desc: Aparently, according to CmdrMatthew, this stops the script from being stolen by servers! --

local old = file.Read
function file.Read(name, usePath)
    if name == "anozira.lua" then
        return ""
    else
        return old(name, usePath)
    end
end

-- Bones --
-- Desc: Just a refrence list so both the lua script and I know what body parts to look at. --

local BONES = {
    { "ValveBiped.Bip01_Head1", "ValveBiped.Bip01_Neck1" },
    { "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_Pelvis" },
    { "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_L_UpperArm" },
    { "ValveBiped.Bip01_Neck1", "ValveBiped.Bip01_R_UpperArm" },
    { "ValveBiped.Bip01_L_UpperArm", "ValveBiped.Bip01_L_Forearm" },
    { "ValveBiped.Bip01_R_UpperArm", "ValveBiped.Bip01_R_Forearm" },
    { "ValveBiped.Bip01_R_Forearm", "ValveBiped.Bip01_R_Hand" },
    { "ValveBiped.Bip01_L_Forearm", "ValveBiped.Bip01_L_Hand" },
    { "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_L_Thigh" },
    { "ValveBiped.Bip01_Pelvis", "ValveBiped.Bip01_R_Thigh" },
    { "ValveBiped.Bip01_L_Thigh", "ValveBiped.Bip01_L_Calf" },
    { "ValveBiped.Bip01_R_Thigh", "ValveBiped.Bip01_R_Calf" },
    { "ValveBiped.Bip01_R_Calf", "ValveBiped.Bip01_R_Foot" },
    { "ValveBiped.Bip01_L_Calf", "ValveBiped.Bip01_L_Foot" },
}

-- Hack Area --
-- Desc: All of the hacks in this client go here. --

-- Aim Assist --
-- Desc: Adds assisted aiming, so you'll snap to a players head when you look anywhere near them! --

function aimassist() 
	if (GetConVarNumber(cmdStr.."_aimassist") == 1) then
		local ply = LocalPlayer()
		local trace = util.GetPlayerTrace( ply ) 
		local traceRes = util.TraceLine( trace ) 
		if traceRes.HitNonWorld then 
			local target = traceRes.Entity 
			if target:IsPlayer() then 
				local targethead = target:LookupBone("ValveBiped.Bip01_Head1")
				local targetheadpos,targetheadang = target:GetBonePosition(targethead) 
				ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle()) 
			end
		end
	end
end
hook.Add("Think","aimassist",aimassist) 

-- Aimbot --
-- Desc: Auto-aims at a player's head.

hook.Add( "Think", "ThinkAboutIt", function()
	if (GetConVarNumber(cmdStr.."_aimbot") == 1) then
	if input.IsKeyDown(KEY_B) then
		local closest = nil
		
		local hitpos = LocalPlayer():GetEyeTrace()
		
		for k, v in pairs( ents.FindInSphere(hitpos.HitPos,2500) ) do
			if v:IsPlayer() and v != LocalPlayer() and v:Alive() then
					closest = v
			end
		end
		
		if closest and closest:IsPlayer() and closest:Alive() then
			local head = closest:LookupBone("ValveBiped.Bip01_Head1")
			local headpos, headang = closest:GetBonePosition(head)
			
			LocalPlayer():SetEyeAngles( (headpos-LocalPlayer():GetShootPos()):Angle() )
			end
		end
	end
end)

-- Custom Crosshair --
-- Desc: This overlays a crosshair in the middle of your screen. --

function crosshair()
if (GetConVarNumber(cmdStr.."_crosshair") == 1) then
		surface.DrawCircle( ScrW() / 2, ScrH() / 2, 5, 255, 50, 50, 255 )
		surface.DrawCircle( ScrW() / 2, ScrH() / 2, 15, 50, 255, 50, 255 )
	end
end
hook.Add('HUDPaint', 'crosshairmiddle', crosshair)

-- Entity ESP --
-- Desc: Shows Entities and information on them through walls. My friend Gravko gave me this one, and I edited it to my liking. --

local function entesp()
if (GetConVarNumber(cmdStr.."_entityesp") == 1) then
for k, v in pairs( player.GetAll() ) do
local pos = ( v:GetShootPos() + Vector( 0, 0, 30) ):ToScreen()
draw.SimpleTextOutlined( v:Nick(), "Default", pos.x + 40, pos.y + 15, Color(0,255,0), 1, 1, 1, Color( 0, 0, 0, 255 ) )
local targetDistance = math.floor((LocalPlayer():GetPos():Distance( v:GetPos()))/40)
local targetDistance3 = math.floor((LocalPlayer():GetPos():Distance( v:GetPos()))/100000)
end
end
end
hook.Add( "HUDPaint", "entesp", entesp)

hook.Add("HUDPaint", "entityesp", function()
		if (GetConVarNumber(cmdStr.."_entityesp") == 1) then
        for k, v in pairs(ents.GetAll()) do
		local mDistance = math.floor((LocalPlayer():GetPos():Distance( v:GetPos()))/40)
        Pos = v:GetPos():ToScreen()
		if not string.find(v:GetClass(), "prop") and not string.find(v:GetClass(), "func") and not string.find(v:GetClass(), "class") and not string.find(v:GetClass(), "env") and not string.find(v:GetClass(), "player") and not string.find(v:GetClass(), "view") and not string.find(v:GetClass(), "world") and not string.find(v:GetClass(), "weapon_") and not string.find(v:GetClass(), "gmod") and not string.find(v:GetClass(), "beam") and not string.find(v:GetClass(), "manipulate") and not string.find(v:GetClass(), "sent") and not string.find(v:GetClass(), "m9k") and not string.find(v:GetClass(), "gun") and not string.find(v:GetClass(), "pocket") and not string.find(v:GetClass(), "vending") and not string.find(v:GetClass(), "npc") and not string.find(v:GetClass(), "sammy") and not string.find(v:GetClass(), "stunstick") and not string.find(v:GetClass(), "unarrest_stick") and not string.find(v:GetClass(), "arrest_stick") and not string.find(v:GetClass(), "door") and not string.find(v:GetClass(), "keys") and not string.find(v:GetClass(), "keypad") and not string.find(v:GetClass(), "lock") and not string.find(v:GetClass(), "chat") and not string.find(v:GetClass(), "gmt") and not string.find(v:GetClass(), "weaponchecker") and not string.find(v:GetClass(), "Keypad") and not string.find(v:GetClass(), "med_") and not string.find(v:GetClass(), "darkrp") and not string.find(v:GetClass(), "swep") and not string.find(v:GetClass(), "fas2") and not string.find(v:GetClass(), "ent_spike") and not string.find(v:GetClass(), "car") and not string.find(v:GetClass(), "fuel") and not string.find(v:GetClass(), "taser") and not string.find(v:GetClass(), "point") and not string.find(v:GetClass(), "hook") and not string.find(v:GetClass(), "tv") and not string.find(v:GetClass(), "newspaper") and not string.find(v:GetClass(), "atm") and not string.find(v:GetClass(), "handcuffs") and not string.find(v:GetClass(), "payphone") and not string.find(v:GetClass(), "wire") then
                                if string.find(v:GetClass(), "printer") then
										draw.SimpleTextOutlined("Money Printer", "Default", Pos.x + 25, Pos.y - 30, Color(25,255,0), 1, 1, 1, Color(0,0,0,255))
                                        draw.SimpleTextOutlined(v:GetClass(), "Default", Pos.x + 54, Pos.y - 20, Color(45,170,0), 1, 1, 1, Color(0,0,0,255))
										draw.SimpleTextOutlined("Distance: ["..mDistance.."]", "Default", Pos.x + 18, Pos.y - 8, Color(60,90,100), 1, 1, 1, Color(0,0,0,255))
                                        elseif v:GetClass() == "spawned_shipment" then
 										draw.SimpleTextOutlined("Weapon Shipment", "Default", Pos.x + 30, Pos.y - 30, Color(25,255,0), 1, 1, 1, Color(0,0,0,255))
                                        draw.SimpleTextOutlined(v:GetClass(), "Default", Pos.x + 55, Pos.y - 20, Color(45,170,0), 1, 1, 1, Color(0,0,0,255))
										draw.SimpleTextOutlined("Distance: ["..mDistance.."]", "Default", Pos.x + 18, Pos.y - 8, Color(60,90,100), 1, 1, 1, Color(0,0,0,255))
										elseif string.find(v:GetClass(), "durgz") then
 										draw.SimpleTextOutlined("Drugs", "Default", Pos.x + 23, Pos.y - 30, Color(25,255,0), 1, 1, 1, Color(0,0,0,255))
                                        draw.SimpleTextOutlined(v:GetClass(), "Default", Pos.x + 50, Pos.y - 20, Color(45,170,0), 1, 1, 1, Color(0,0,0,255))
										draw.SimpleTextOutlined("Distance:["..mDistance.."]", "Default", Pos.x + 18, Pos.y - 8, Color(60,90,100), 1, 1, 1, Color(0,0,0,255))
                                        elseif v:GetClass() == "spawned_weapon" then
										draw.SimpleTextOutlined("Weapon", "Default", Pos.x + 25, Pos.y - 30, Color(25,255,0), 1, 1, 1, Color(0,0,0,255))
                                        draw.SimpleTextOutlined(v:GetClass(), "Default", Pos.x + 50, Pos.y - 20, Color(45,170,0), 1, 1, 1, Color(0,0,0,255))
										draw.SimpleTextOutlined("Distance: ["..mDistance.."]", "Default", Pos.x + 18, Pos.y - 8, Color(60,90,100), 1, 1, 1, Color(0,0,0,255))
                                        elseif v:GetClass() == "spawned_money" then
										draw.SimpleTextOutlined("Money", "Default", Pos.x + 25, Pos.y - 30, Color(25,255,0), 1, 1, 1, Color(0,0,0,255))
                                        draw.SimpleTextOutlined(v:GetClass(), "Default", Pos.x + 50, Pos.y - 20, Color(45,170,0), 1, 1, 1, Color(0,0,0,255))
										draw.SimpleTextOutlined("Distance: ["..mDistance.."]", "Default", Pos.x + 18, Pos.y - 8, Color(60,90,100), 1, 1, 1, Color(0,0,0,255))
                                        else
										
                                end
                        end
                end    
		end
end)

-- Chams --
-- Desc: Shows players bodies through walls. --

hook.Add( "HUDPaint", "ESPChams", function()
 
	for k,v in pairs ( player.GetAll() ) do
	if GetConVarNumber(cmdStr.."_chams") == 1 then
		
		if SafeCheck(v) == true then
		
			local ply = LocalPlayer()
			
			cam.Start3D(EyePos(), EyeAngles())
	         	     render.MaterialOverride("models/debug/debugwhite")
	         	     render.SuppressEngineLighting( false )
	         	     render.SetBlend( 10.0 )
	         	     render.SetColorModulation( 0, 255, 0 )
					v:DrawModel();
					-- This bit is for weapons. --
	         	     render.MaterialOverride("models/debug/debugwhite")
	         	     render.SuppressEngineLighting( false )
	         	     render.SetBlend( 10.0 )
	         	     render.SetColorModulation( 255, 0, 0 )
					v:GetActiveWeapon():DrawModel()
				cam.End3D()
		end
	end
end
end)

-- BoxESP --
-- Desc: Drawls a box around players through walls. --

hook.Add("HUDPaint", "BoxESP", function()
    for k,v in pairs(player.GetAll()) do
        if GetConVarNumber(cmdStr.."_boxesp") == 1 then
			if SafeCheck(v) == true then
			local ply = LocalPlayer()
			local plyPos = v:GetPos()
			local head = v:OBBMaxs()
			local feet = v:OBBMins()
			local eye = v:EyeAngles()
            if SafeCheck(v) then
                cam.Start3D()
					render.DrawWireframeBox( plyPos, Angle( 0, eye.y, 0), feet, head, Color( 150, 150, 150 ) )
	         	     cam.End3D()
	         	  end
	       end
    end
end
end)

if GetConVarNumber(cmdStr.."_boxesp") == 0 then
	hook.Remove("HUDPaint", "BoxESP")
end

-- Name Changer (DarkRP) --
-- Desc: Changes the name of your player in game to make it difficult for staff to ban you. --

function NC()
	if (GetConVarNumber(cmdStr.."_namechanger") == 1) then
		LocalPlayer():ConCommand( "say /rpname " ..tostring( math.random( 9999999, 99999999 ) ) )
	end
end
hook.Add( "Think", "NameChanger", NC )

-- Player Info --
-- Desc: Shows a player's name, health, and weapon through walls. --

hook.Add( "HUDPaint", "PlayerInfo", function()
	if (GetConVarNumber(cmdStr.."_playerinfo") == 1) then
	for k,v in pairs ( player.GetAll() ) do
		
		if SafeCheck(v) == true then
		
			local plyPos = v:GetPos()
			local pos = ( plyPos + Vector( 0, 0, 90 )):ToScreen()
			local plyName = v:Nick()
			local plyHP = "HP: " .. v:Health()
			local ply = LocalPlayer()

			draw.SimpleTextOutlined( plyName, "AnoziraDefault", pos.x, pos.y, Color( 150, 150, 255 ), 1, 1, 1, Color( 0, 0, 0 ) )
			draw.SimpleTextOutlined( plyHP, "AnoziraDefault", pos.x, pos.y + 15, Color( 150, 255, 150 ), 1, 1, 1, Color( 0, 0, 0 ) )
		end
	end
end
end)

-- Menu Area --
-- Desc: The GUI or Menu of the hack and everything needed to display it goes here. --

concommand.Add( "+AnoziraMenu", function()
local DermaPanel = vgui.Create( "DFrame" )
DermaPanel:SetPos( 50,50 )
DermaPanel:SetSize( 450, 300 )
DermaPanel:SetTitle( "Anozira Coded by Xeaxos" )
DermaPanel:SetVisible( true )
DermaPanel:SetDraggable( true )
DermaPanel:ShowCloseButton( true )
DermaPanel.Paint = function( self, w, h ) 
	draw.RoundedBox( 0, 0, 0, w, h, Color( 75, 75, 75, 150 ) ) 
end
DermaPanel:MakePopup()
 
 local PropertySheet = vgui.Create( "DPropertySheet" )
PropertySheet:SetParent( DermaPanel )
PropertySheet:SetPos( 5, 30 )
PropertySheet:SetSize( 440, 230 )
PropertySheet.Paint = function( self, w, h ) 
	draw.RoundedBox( 0, 0, 0, w, h, Color( 25, 25, 25, 150 ) ) 
end

local Aim = vgui.Create( "DFrame" )
Aim:SetPos( 50,50 )
Aim:SetSize( 450, 300 )
Aim:SetTitle( "" )
Aim:SetVisible( true )
Aim:SetDraggable( true )
Aim:ShowCloseButton( false )
Aim.Paint = function( self, w, h ) 
	draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 0 ) ) 
end
 
local ESP = vgui.Create( "DFrame" )
ESP:SetPos( 50,50 )
ESP:SetSize( 450, 300 )
ESP:SetTitle( "" )
ESP:SetVisible( true )
ESP:SetDraggable( true )
ESP:ShowCloseButton( false )
ESP.Paint = function( self, w, h ) 
	draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 0 ) ) 
end

local Misc = vgui.Create( "DFrame" )
Misc:SetPos( 50,50 )
Misc:SetSize( 450, 300 )
Misc:SetTitle( "" )
Misc:SetVisible( true )
Misc:SetDraggable( true )
Misc:ShowCloseButton( false )
Misc.Paint = function( self, w, h ) 
	draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 0 ) )  
end
 
PropertySheet:AddSheet( "Aim Hacks", Aim, "icon16/user.png", false, false, "Aimbot and Aimbot settings." )
PropertySheet:AddSheet( "ESP Hacks", ESP, "icon16/group.png", false, false, "ESP hacks and ESP settings." ) 
PropertySheet:AddSheet( "Misc Hacks", Misc, "icon16/help.png", false, false, "All misc hacks." ) 
 
local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Aim )
CheckBoxThing:SetPos( 10,25 )
CheckBoxThing:SetText( "Aim Assist" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_aimassist" ) 
CheckBoxThing:SizeToContents() 
 
local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Aim )
CheckBoxThing:SetPos( 10,50 )
CheckBoxThing:SetText( "Aimbot" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_aimbot" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", ESP )
CheckBoxThing:SetPos( 10,25 )
CheckBoxThing:SetText( "PlayerInfo" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_playerinfo" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", ESP )
CheckBoxThing:SetPos( 10,50 )
CheckBoxThing:SetText( "BoxESP" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_boxesp" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", ESP )
CheckBoxThing:SetPos( 10,75 )
CheckBoxThing:SetText( "Chams" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_chams" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", ESP )
CheckBoxThing:SetPos( 10,100 )
CheckBoxThing:SetText( "Entity ESP" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_entityesp" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Misc )
CheckBoxThing:SetPos( 10,25 )
CheckBoxThing:SetText( "Namechanger" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_namechanger" ) 
CheckBoxThing:SizeToContents() 

local CheckBoxThing = vgui.Create( "DCheckBoxLabel", Misc )
CheckBoxThing:SetPos( 10,50 )
CheckBoxThing:SetText( "Crosshair" )
CheckBoxThing:SetTextColor( Color( 255, 255, 255 ) )
CheckBoxThing:SetConVar( cmdStr.."_crosshair" ) 
CheckBoxThing:SizeToContents() 

local DermaButton = vgui.Create( "DButton", DermaPanel )
DermaButton:SetText( "Click here to donate skins/items if you're into that." )
DermaButton:SetTextColor( Color( 255, 255, 255 ) )
DermaButton:SetPos( 75, 270 )
DermaButton:SetSize( 300, 25 )
DermaButton.DoClick = function ()
    gui.OpenURL( "https://steamcommunity.com/tradeoffer/new/?partner=139410825&token=TCdrZr1u" )
end
DermaButton.Paint = function( self, w, h )
	draw.RoundedBox( 0, 0, 0, w, h, Color( 0, 0, 0, 175 ) ) 
end
end)