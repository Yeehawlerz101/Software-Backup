
------------------------------------------------------------
------------------------------------------------------------
------------------------------------------------------------
--	Star Wars: Clone HUD System
--	Date:	2016-April-27
--	By V92: http://steamcommunity.com/id/JesseVanover/
--	Official Upload:	http://steamcommunity.com/sharedfiles/filedetails/?id=
--	With contributions by:	
--		GSC @ Clone Games / CoP HUD textures
--		thejjokerr @ DrawPartialTexturedRect Function
--		GcDesign & Splambob @ Original GPS HUD
--		Rush_Freak @ Vignette Effect
--		Gonzo @ Quest Context Menu Plugin
--		Jinto @ First-Person Death View
--		ChessNut @ First-Person Legs
--		Suicidal Banana @ SUI Scoreboard
--
--	Steam Group:	http://steamcommunity.com/groups/firestormstudios
--	
--	Have nice day.
------------------------------------------------------------
------------------------------------------------------------
------------------------------------------------------------

AddCSLuaFile()

if !ConVarExists("VNT_Debug_Prints") then						CreateClientConVar( "VNT_Debug_Prints", '1', true, false )	end
if GetConVarNumber("VNT_Debug_Prints") != 0 then	print( "[V92] Clone HUD Shared Loading..." )	end
------------------------------------------------------------
--	HUD System CVars
------------------------------------------------------------
if !ConVarExists("VNT_CloneHUD_Installed") then				CreateConVar( "VNT_CloneHUD_Installed", '1', { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Internal Developer CVar for Extensions" )	end
if !ConVarExists("VNT_CloneHUD_HelmetFX") then				CreateClientConVar( "VNT_CloneHUD_HelmetFX", '1', true, false, "Toggle the Clone HUD Vignette FX overlay" )	end
if !ConVarExists("VNT_CloneHUD_Toggle_Main") then			CreateClientConVar( "VNT_CloneHUD_Toggle_Main", '1', true, false, "Toggle the Clone HUD root HUD" )	end
if !ConVarExists("VNT_CloneHUD_Toggle_Compass") then		CreateClientConVar( "VNT_CloneHUD_Toggle_Compass", '1', true, false, "Toggle the Clone HUD compass HUD" )	end
if !ConVarExists("VNT_CloneHUD_Toggle_Visor") then			CreateClientConVar( "VNT_CloneHUD_Toggle_Visor", '1', true, false, "Toggle the Clone HUD viosr HUD" )	end
if !ConVarExists("VNT_CloneHUD_Radar_Toggle") then			CreateClientConVar( "VNT_CloneHUD_Radar_Toggle", '1', true, false, "Toggle the Clone HUD radar on/off on the client" )	end
if !ConVarExists("VNT_CloneHUD_Radar_Toggle_Admin") then	CreateConVar( "VNT_CloneHUD_Radar_Toggle_Admin", '1', { FCVAR_ARCHIVE, FCVAR_REPLICATED }, "Admin Toggles Ability to Use Radars in the Clone HUD" )	end
if !ConVarExists("VNT_CloneHUD_Radar_Names") then			CreateClientConVar( "VNT_CloneHUD_Radar_Names", '0', true, false, "Toggle the showing of names on the Clone HUD radar" )	end
if !ConVarExists("VNT_CloneHUD_Radar_UpdateRate") then		CreateClientConVar( "VNT_CloneHUD_Radar_UpdateRate", '1500', true, false, "Update rate in milliseconds for the radar, low number = higher CPU load" )	end
------------------------------------------------------------
--	HUD Adjustments
------------------------------------------------------------
if !ConVarExists("VNT_CloneHUD_XPos") then					CreateClientConVar( "VNT_CloneHUD_XPos", '100', true, false )	end
if !ConVarExists("VNT_CloneHUD_YPos") then					CreateClientConVar( "VNT_CloneHUD_YPos", '232', true, false )	end
if !ConVarExists("VNT_CloneHUD_Radar_XPos") then			CreateClientConVar( "VNT_CloneHUD_Radar_XPos", '64', true, false )	end
if !ConVarExists("VNT_CloneHUD_Radar_YPos") then			CreateClientConVar( "VNT_CloneHUD_Radar_YPos", '64', true, false )	end
--if !ConVarExists("VNT_CloneHUD_Compass_XPos") then			CreateClientConVar( "VNT_CloneHUD_Compass_XPos", '532', true, false )	end
if !ConVarExists("VNT_CloneHUD_Compass_YPos") then			CreateClientConVar( "VNT_CloneHUD_Compass_YPos", '128', true, false )	end
--if !ConVarExists("VNT_CloneHUD_VisorTop_XPos") then			CreateClientConVar( "VNT_CloneHUD_VisorTop_XPos", '532', true, false )	end
if !ConVarExists("VNT_CloneHUD_VisorTop_YPos") then			CreateClientConVar( "VNT_CloneHUD_VisorTop_YPos", '200', true, false )	end
--if !ConVarExists("VNT_CloneHUD_VisorBottom_XPos") then		CreateClientConVar( "VNT_CloneHUD_VisorBottom_XPos", '532', true, false )	end
if !ConVarExists("VNT_CloneHUD_VisorBottom_YPos") then		CreateClientConVar( "VNT_CloneHUD_VisorBottom_YPos", '500', true, false )	end

------------------------------------------------------------
--	Quest Marker Hook-Ins
--	Author: Gonzo
------------------------------------------------------------
properties.Add( "V92QuestOn", {
	MenuLabel	=	"Mark as Quest",
	Order		=	1500,
	MenuIcon	=	"icon16/star.png",		
	Filter		=	function( self, ent, ply ) 
			if ( !IsValid( ent ) ) then return false end
			if (ent:GetNWBool("V92QUESTITEM") == true ) then return false end
			return true 
		end,		
	Action		=	function( self, ent )
			self:MsgStart()
			net.WriteEntity( ent )
			self:MsgEnd()
		end,
	Receive		=	function( self, length, player )
			local ent = net.ReadEntity()
			if ( !self:Filter( ent, player ) ) then return end
			ent:SetNWBool("V92QUESTITEM",true)
		end	
})
properties.Add( "V92QuestOff",{
	MenuLabel	=	"Remove as Quest",
	Order		=	1500,
	MenuIcon	=	"icon16/cross.png",
	Filter		=	function( self, ent, ply ) 
			if ( !IsValid( ent ) ) then return false end
			return ent:GetNWBool("V92QUESTITEM") == true 
		end,
	Action		=	function( self, ent )
			self:MsgStart()
			net.WriteEntity( ent )
			self:MsgEnd()
		end,		
	Receive		=	function( self, length, player )
			local ent = net.ReadEntity()
			if ( !self:Filter( ent, player ) ) then return end
			ent:SetNWBool("V92QUESTITEM",false)
		end	
})

local	function vntCloneHUDOptions( Panel )

	Panel:ClearControls()

	Panel:AddControl( "Header", { 
		Text = "Clone Wars HUD" ,
		Description	=[[Welcome to Star Wars Clone HUD!
		You can find all the options and controls to customize the HUD below.
		Leave Feedback Here:
		http://steamcommunity.com/groups/firestormstudios
		Enjoy!
		]],
	}  )

	Panel:AddControl( "Button", 	{ 
		Label = "Toggle HUD",	
		Command = "VNT_CloneHUD_Toggle",	
	}  )

	Panel:AddControl( "Checkbox", 	{ 
		Label = "Toggle Helmet",	
		Command = "VNT_CloneHUD_HelmetFX",	
		Type = "bool"
	}  )

	Panel:AddControl( "Checkbox", 	{ 
		Label = "Toggle Compass",	
		Command = "VNT_CloneHUD_Toggle_Compass",	
	}  )

	Panel:AddControl( "Checkbox", 	{ 
		Label = "Toggle Visor",	
		Command = "VNT_CloneHUD_Toggle_Visor",	
	}  )

	Panel:AddControl( "Checkbox", 	{ 
		Label = "Toggle Main",	
		Command = "VNT_CloneHUD_Toggle_Main",	
	}  )

	Panel:AddControl( "Header", { 
		Text = "Customization" ,
		Description	="Use the following to adjust the radars"
	}  )

	Panel:AddControl( "Slider", {
		Label = "Radar Update Rate",
		Command = "VNT_CloneHUD_Radar_UpdateRate",	
		Type = "int",
		Min = "500", 	
		Max = "10000"
	}	)

	Panel:AddControl( "Checkbox", 	{ 
		Label = "Toggle Radar",	
		Command = "VNT_CloneHUD_Radar_Toggle",	
	}  )

	Panel:AddControl( "Checkbox", 	{ 
		Label = "Toggle Radar Names",	
		Command = "VNT_CloneHUD_Radar_Names",	
	}  )

	Panel:AddControl( "Checkbox", 	{ 
		Label = "ADMIN: Enable Radar",	
		Command = "VNT_CloneHUD_Radar_Toggle_Admin",	
	}  )
end

local	function CloneHUDIndex()	spawnmenu.AddToolMenuOption( "Options", "V92",   "Clone Wars HUD",   "Clone Wars HUD",    "",    "",    vntCloneHUDOptions )	end
hook.Add( "PopulateToolMenu", "CloneHUDIndex", CloneHUDIndex )

if SERVER then	-- Server Realm
	resource.AddWorkshop( "" )	--	Clone HUD
end

------------------------------------------------------------
-- Health Boxes: Devenger
------------------------------------------------------------

local _DIVHPBOXES 						= {}			--	I like tables
	_DIVHPBOXES.number 					= 5			--	The health within each health box

local _DIVAPBOXES 						= {}			--	I like tables
	_DIVAPBOXES.number 					= 5				--	The armour within each health box

if CLIENT then

	_SHOWHUD	= true
	_HPBOXNUM	= 20
	_APBOXNUM	= 20
	surface.CreateFont(	"CloneHUDText", {			size = 24,	weight = 500,	antialias = true,	shadow = true,	font = "TitilliumWebBold"})
	surface.CreateFont(	"CloneHUDWeight", {			size = 24,	weight = 500,	antialias = true,	shadow = true,	font = "TitilliumWebBold"})
		------------------------------------------------------------
	--	HUD Special Functions
	--	Author: thejjokerr
	--	Source:	http://facepunch.com/showthread.php?t=1026117
	------------------------------------------------------------
	function surface.DrawPartialTexturedRect( x, y, w, h, partx, party, partw, parth, texw, texh )
		--[[ 
			Arguments:
			x: Where is it drawn on the x-axis of your screen
			y: Where is it drawn on the y-axis of your screen
			w: How wide must the image be?
			h: How high must the image be?
			partx: Where on the given texture's x-axis can we find the image you want?
			party: Where on the given texture's y-axis can we find the image you want?
			partw: How wide is the partial image in the given texture?
			parth: How high is the partial image in the given texture?
			texw: How wide is the texture?
			texh: How high is the texture?
		]]--
		
		-- Verify that we recieved all arguments
		if not( x && y && w && h && partx && party && partw && parth && texw && texh ) then
			ErrorNoHalt("surface.DrawPartialTexturedRect: Missing argument!")	
			
			return	
		end	
		
		-- Get the positions and sizes as percentages / 100
		local percX, percY = partx / texw, party / texh	
		local percW, percH = partw / texw, parth / texh	
		
		-- Process the data
		local vertexData = {
			{
				x = x,
				y = y,
				u = percX,
				v = percY
			},
			{
				x = x + w,
				y = y,
				u = percX + percW,
				v = percY
			},
			{
				x = x + w,
				y = y + h,
				u = percX + percW,
				v = percY + percH
			},
			{
				x = x,
				y = y + h,
				u = percX,
				v = percY + percH
			}
		}	
			
		surface.DrawPoly( vertexData )	
	end	  
	function surface.DrawPartialTexturedRectRotated( x, y, w, h, partx, party, partw, parth, texw, texh, rot )
	local matrix = Matrix()
		  matrix:Rotate( Angle( 0,-rot,0 ) )  
	cam.PushModelMatrix( matrix )
	surface.DrawPartialTexturedRect( x, y, w, h, partx, party, partw, parth, texw, texh )
	cam.PopModelMatrix()
	end
	
	------------------------------------------------------------
	--	HUD Hiding
	--	Author: AceCool
	------------------------------------------------------------
	local HideHudElements = {
		// HL2 HUD - set these up how you want...
		CAchievementNotificationPanel   = false;	 -- Achievement notifications
		CHudAmmo                        = true;	 -- Primary Ammo
		CHudBattery                     = true;	 -- Your Armor
		CHudChat                        = false;	 -- The chat area
		CHudCloseCaption                = false;	 -- The closed-caption messages
		CHudCredits                     = false;	 -- Credits
		CHudCrosshair                   = true;	 -- Your crosshair
		CHudDeathNotice                 = true;	 -- Death notices that appear at the top right of the screen
		CHudHealth                      = true;	 -- Your Health
		CHudHintDisplay                 = true;	 -- Displays hints as seen in Half-Life 2
		CHudHistoryResource             = true;	 -- List of items/ammunition the player recently picked up
		CHudSecondaryAmmo               = true;	 -- Secondary Ammo
		CHudSuitPower                   = false;	 -- Most likely Auxiliary Power
		CHudTrain                       = false;	 -- Controls when using a func_train?
		CHudMessage                     = false;	 -- Messages printed to the center of the screen
		CHudMenu                        = false;	 -- Unknown
		CHudWeapon                      = false;	 -- This is the indicators that appear when you have picked up ammo or weapons.
		CHudWeaponSelection             = false;	 -- Player weapon selection menu
		CHudGMod                        = false;	 -- HUD's produced by Garrysmod
		CHudDamageIndicator             = false;	 -- The red trapazoids displayed on the side of the screen when damage is taken, also includes the red screen you get when died from combat.
		CHudVehicle                     = false;	 -- Control panel when entering a vehicle/crane?
		CHudVoiceStatus                 = false;	 -- Shows when other players use microphone voice chat.
		CHudVoiceSelfStatus             = false;	 -- Shows when the local player uses microphone voice chat.
		CHudSquadStatus                 = false;	 -- Squad status panel shown when rebels join your squad
		CHudZoom                        = false;	 -- Dimming and large crosshair
		CHudCommentary                  = false;	 -- Display showing the duration and progress of the currently active commentary node
		CHudGeiger                      = false;	 -- Commentary panel
		CHudAnimationInfo               = false;	 -- Displays information about HUD elements, activated by the console command cl_animationinfo
		CHUDAutoAim                     = false;	 -- Unknown
		CHudFilmDemo                    = false;	 -- Unknown
		CHudHDRDemo                     = false;	 -- Lost Coast HDR Demonstration HUD element
		CHudPoisonDamageIndicator       = false;	 -- Panel that appears upon a player receiving poison [Neurotoxin] damage
		CPDumpPanel						= false;	 -- Unknown
		VNTHUDStalker					= false;		 -- Don't hide the basic hud we just added...
	}	

	local	function VNTCloneHUDDisabler( _name )	
		if(!_SHOWHUD) then return end
		return !HideHudElements[ _name ]	
	end
	hook.Add("HUDShouldDraw", "VNTCloneHUDDisabler", VNTCloneHUDDisabler)
	
	local	function vnt_ToggleCloneHUD()	_SHOWHUD = !_SHOWHUD	end
	concommand.Add("VNT_CloneHUD_Toggle", vnt_ToggleCloneHUD)

	local	function vntCloneHUDDraw()
		if(!_SHOWHUD) then return end
		local _P = LocalPlayer()
		local _W = _P:GetActiveWeapon()	
		if ((_P:Alive() == false) or (IsValid(_P)) == false) or ( IsValid(_W) and _W:GetClass() == "gmod_camera" ) then return end
		local _SHOULDDRAW = hook.Call( "HUDShouldDraw", GAMEMODE, "VNTHUDClone" )

		if GetConVarNumber("VNT_CloneHUD_Toggle_Main") != 0 then
			_DIVHPBOXES.XOffset				=	ScrW()/2 + GetConVarNumber("VNT_CloneHUD_XPos")
			_DIVHPBOXES.YOffset				=	ScrH()/2 + GetConVarNumber("VNT_CloneHUD_YPos")
			_DIVHPBOXES.graphicalTweenSpeed =	50
			_DIVHPBOXES.displayAttributes	=	{x = _DIVHPBOXES.XOffset + 6, y = _DIVHPBOXES.YOffset, boxw = 5, boxh = 16, gapw = 6}
			_DIVAPBOXES.displayAttributes	=	{x = _DIVHPBOXES.XOffset + 6, y = _DIVHPBOXES.YOffset + 34, boxw = 5, boxh = 16, gapw = 6}
			_SWAmmoMag1_X					=	_DIVHPBOXES.XOffset+10
			_SWAmmoMag1_Y					=	_DIVHPBOXES.YOffset-50
			_SWAmmoStore1_X					=	_DIVHPBOXES.XOffset+10
			_SWAmmoStore1_Y					=	_DIVHPBOXES.YOffset-28
			_SWAmmoMag2_X					=	_DIVHPBOXES.XOffset+150
			_SWAmmoMag2_Y					=	_DIVHPBOXES.YOffset-50
			_SWAmmoStore2_X					=	_DIVHPBOXES.XOffset+150
			_SWAmmoStore2_Y					=	_DIVHPBOXES.YOffset-28
			_VISORTOP						=	surface.GetTextureID( "jessev92/ui/mint/hudtop" )
			_VISORBOTTOM					=	surface.GetTextureID( "jessev92/ui/mint/hudbottom" )
			surface.SetDrawColor (55, 80, 150, 128)

			surface.SetDrawColor(Color(0,230,230,150))
			surface.DrawRect(_DIVHPBOXES.XOffset, _DIVHPBOXES.YOffset-8, 225, 30)	--	health box
			surface.DrawRect(_DIVHPBOXES.XOffset, _DIVHPBOXES.YOffset+26, 225, 30)	--	armour box
			surface.DrawRect(_DIVHPBOXES.XOffset, _DIVHPBOXES.YOffset-60, 225, 48)	--	ammo box
			------------------------------------------------------------
			--	HUD Ammo
			------------------------------------------------------------
			
			------------------------------------------------------------
			--	HUD Primary Ammo
			------------------------------------------------------------
			local	mag		= _W:Clip1()
			local	store	= _P:GetAmmoCount(	_W:GetPrimaryAmmoType()		)
			if mag > 999 then mag = 999 end
			if store > 999 then store = 999 end
			if mag >= 0 or store > 0 then
				if !_W:IsValid() then return false end
				if mag == -1 then
					draw.SimpleText( "MAG:" .. store, "CloneHUDText", _SWAmmoStore1_X, _SWAmmoStore1_Y, Color( 230, 230, 230, 240 ), 0, 1)
				elseif mag >= 10 and mag <= 99 then
					draw.SimpleText( "MAG:0" .. mag, "CloneHUDText", _SWAmmoMag1_X, _SWAmmoMag1_Y, Color( 230, 230, 230, 240 ), 0, 1)
				elseif mag >= 0 and mag <= 9 then
					draw.SimpleText( "MAG:00" .. mag, "CloneHUDText", _SWAmmoMag1_X, _SWAmmoMag1_Y, Color( 230, 230, 230, 240 ), 0, 1)
				else
					draw.SimpleText( "MAG:" .. mag, "CloneHUDText", _SWAmmoMag1_X, _SWAmmoMag1_Y, Color( 230, 230, 230, 240 ), 0, 1)
				end
				if store == -1 then
					draw.SimpleText( "RES:" .. store, "CloneHUDText", _SWAmmoStore1_X, _SWAmmoStore1_Y, Color( 230, 230, 230, 240 ), 0, 1)
				elseif store >= 10 and store <= 99 then
					draw.SimpleText( "RES:0" .. store, "CloneHUDText", _SWAmmoStore1_X, _SWAmmoStore1_Y, Color( 230, 230, 230, 240 ), 0, 1)
				elseif store >= 0 and store <= 9 then
					draw.SimpleText( "RES:00" .. store, "CloneHUDText", _SWAmmoStore1_X, _SWAmmoStore1_Y, Color( 230, 230, 230, 240 ), 0, 1)
				else
					draw.SimpleText( "RES:" .. store, "CloneHUDText", _SWAmmoStore1_X, _SWAmmoStore1_Y, Color( 230, 230, 230, 240 ), 0, 1)
				end
			else
				draw.SimpleText( "MAG: -/-", "CloneHUDText", _SWAmmoMag1_X, _SWAmmoMag1_Y, Color( 230, 230, 230, 240 ), 0, 1)
				draw.SimpleText( "RES: -/-", "CloneHUDText", (_SWAmmoStore1_X), _SWAmmoStore1_Y, Color( 230, 230, 230, 240 ), 0, 1)
			end
			------------------------------------------------------------
			--	HUD Secondary Ammo
			------------------------------------------------------------
			local	store2	= _W:Clip2()
			local	mag2	= _P:GetAmmoCount(	_W:GetSecondaryAmmoType()	) + store2
			if mag2 > 999 then mag2 = 999 end
			if store2 > 999 then store2 = 999 end
			if mag2 >= 0 then	
				if !_W:IsValid() then return false end
				if mag2 == -1 then
					draw.SimpleText( "ALT:" .. store2, "CloneHUDText", _SWAmmoStore2_X, _SWAmmoStore2_Y, Color( 230, 230, 230, 240 ), 0, 1)
				elseif mag2 >= 10 and mag2 <= 99 then
					draw.SimpleText( "ALT:0" .. mag2, "CloneHUDText", _SWAmmoMag2_X, _SWAmmoMag2_Y, Color( 230, 230, 230, 240 ), 0, 1)
				elseif mag2 >= 0 and mag2 <= 9 then
					draw.SimpleText( "ALT:00" .. mag2, "CloneHUDText", _SWAmmoMag2_X, _SWAmmoMag2_Y, Color( 230, 230, 230, 240 ), 0, 1)
				else
					draw.SimpleText( "ALT:" .. mag2, "CloneHUDText", _SWAmmoMag2_X, _SWAmmoMag2_Y, Color( 230, 230, 230, 240 ), 0, 1)
				end
				--[[
				if store2 == -1 then
					draw.SimpleText( "RES:" .. store2, "CloneHUDText", _SWAmmoStore2_X, _SWAmmoStore2_Y, Color( 230, 230, 230, 240 ), 1, 1)
				elseif store2 >= 10 and store2 <= 99 then
					draw.SimpleText( "RES:0" .. store2, "CloneHUDText", _SWAmmoStore2_X, _SWAmmoStore2_Y, Color( 230, 230, 230, 240 ), 1, 1)
				elseif store2 >= 0 and store2 <= 9 then
					draw.SimpleText( "RES:00" .. store2, "CloneHUDText", _SWAmmoStore2_X, _SWAmmoStore2_Y, Color( 230, 230, 230, 240 ), 1, 1)
				else
					draw.SimpleText( "RES:" .. store2, "CloneHUDText", _SWAmmoStore2_X, _SWAmmoStore2_Y, Color( 230, 230, 230, 240 ), 1, 1)
				end--]]
			else
				draw.SimpleText( "ALT: -/-", "CloneHUDText", _SWAmmoMag2_X, _SWAmmoMag2_Y, Color( 230, 230, 230, 240 ), 0, 1)
				--draw.SimpleText( "RES: -/-", "CloneHUDText", (_SWAmmoStore2_X), _SWAmmoStore2_Y, Color( 230, 230, 230, 240 ), 0, 1)
			end
			------------------------------------------------------------
			--	HUD Health Bars
			------------------------------------------------------------		
			local	_ACTUALHP	= _P:Health()
			local	_TWEENHP	= _P:Health()
			local	_DATHP		= _DIVHPBOXES.displayAttributes

			if _ACTUALHP != _TWEENHP then
				if _ACTUALHP > _TWEENHP then 
					_TWEENHP = math.min (_TWEENHP + _DIVHPBOXES.graphicalTweenSpeed * FrameTime(), _ACTUALHP) 
				else 
					_TWEENHP = math.max (_TWEENHP - _DIVHPBOXES.graphicalTweenSpeed * FrameTime(), _ACTUALHP) 
				end
			end
			local	y = _DATHP.y
			local	h = _DATHP.boxh
			for i=0, _HPBOXNUM do
				local health = math.Round (math.min (_DIVHPBOXES.number, _TWEENHP - i * _DIVHPBOXES.number))
				if health <= 0 then break end
				local x = _DATHP.x + i * (_DATHP.boxw + _DATHP.gapw)
				local w = _DATHP.boxw * (health / _DIVHPBOXES.number)
				surface.SetDrawColor(150,50,60,200)
				surface.DrawRect (x-2,y-4,w+2,h+6)
			end
			------------------------------------------------------------
			--	HUD Armour Bars
			------------------------------------------------------------		
			local	_ACTUALAP	= _P:Armor()
			local	_TWEENAP	= _P:Armor()
			local	_DATAP		= _DIVAPBOXES.displayAttributes

			if _ACTUALAP != _TWEENAP then
				if _ACTUALAP > _TWEENAP then 
					_TWEENAP = math.min (_TWEENAP + _DIVAPBOXES.graphicalTweenSpeed * FrameTime(), _ACTUALAP) 
				else 
					_TWEENAP = math.max (_TWEENAP - _DIVAPBOXES.graphicalTweenSpeed * FrameTime(), _ACTUALAP) 
				end
			end
			local	y = _DATAP.y
			local	h = _DATAP.boxh
			for i=0, _APBOXNUM do
				local armour = math.Round (math.min (_DIVAPBOXES.number, _TWEENAP - i * _DIVAPBOXES.number))
				if armour <= 0 then break end
				local x = _DATAP.x + i * (_DATAP.boxw + _DATAP.gapw)
				local w = _DATAP.boxw * (armour / _DIVAPBOXES.number)
				surface.SetDrawColor(50,75,215,200)
				surface.DrawRect (x-2,y-4,w+2,h+6)
			end
		end
		
		------------------------------------------------------------
		--	HUD Visor
		------------------------------------------------------------
		if GetConVarNumber("VNT_CloneHUD_Toggle_Visor") != 0 then
			surface.SetTexture( _VISORTOP )
			surface.SetDrawColor(Color(0,230,230,255))
			surface.DrawTexturedRect(ScrW()/2 - 512, GetConVarNumber("VNT_CloneHUD_VisorTop_YPos"), 1024, 256)
			surface.SetTexture( _VISORBOTTOM )
			surface.DrawTexturedRect(ScrW()/2 - 512, GetConVarNumber("VNT_CloneHUD_VisorBottom_YPos"), 1024, 256)
		end
		
		------------------------------------------------------------
		--	HUD Compass
		------------------------------------------------------------
		if GetConVarNumber("VNT_CloneHUD_Toggle_Compass") != 0 then
			local compass = surface.GetTextureID("jessev92/ui/fallout/compass") 
			surface.SetTexture(compass)
			surface.SetDrawColor(Color(0,230,230,175))
			surface.DrawPartialTexturedRect( ScrW()/2 - 128, GetConVarNumber("VNT_CloneHUD_VisorTop_YPos")+32, 256, 128, (-LocalPlayer():GetAngles().y/360) * 1024+143, 0, 256, 64,1024,64 )
			draw.SimpleText( ( "UID: " .. _P:Nick()), "CloneHUDText",ScrW()/2,GetConVarNumber("VNT_CloneHUD_VisorTop_YPos")+150,Color( 230, 230, 230, 240 ),1,1)
		end

		------------------------------------------------------------
		--	HUD Radar
		--	Author: GcDesign & Splambob
		------------------------------------------------------------
		local	_RADARDOTCOLOUR		= Color( 255, 255, 255, 255 )
		local	_RADARTEXTCOLOUR	= Color( 255, 255, 255, 255 )
		local	_RADARW				= 256
		local	_RADARH				= 256
		local	_RADAR_X			= 16 + GetConVarNumber("VNT_CloneHUD_Radar_XPos")
		local	_RADAR_Y			= 16 + GetConVarNumber("VNT_CloneHUD_Radar_YPos")
		local	_RADARALP			= 0.8
		local	_RADARRANGE			= 2500
		local	_RADARBGDCOL		= Color(0,230,230,255)
		local	_RADARFGDCOL		= Color(0,0,0,255)
		local	_RADARDETAIL		= 64
		local	_RADARANG			= 0
		local	_RADNUMPLY			= 0	--	HUD Radar Player Counter
		local	_RADARNOISE_SIZE	= _RADARW +8
		local	_RADARNOISE_X 		= _RADAR_X-2
		local	_RADARNOISE_Y 		= _RADAR_Y-8
		
		if GetConVarNumber( "VNT_CloneHUD_Radar_Toggle_Admin" ) == 0 then
			surface.SetTexture(surface.GetTextureID("jessev92/ui/division/radar_base"))
			surface.SetDrawColor(255,255,255,200)
			surface.DrawTexturedRect ( _RADAR_X, _RADAR_Y, _RADARW, _RADARH )
			
			local Tex_HudMapNoise = surface.GetTextureID("jessev92/ui/stalker/cop/noise_minimap")
			surface.SetTexture( Tex_HudMapNoise )
			surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
			surface.DrawTexturedRect ( _RADARNOISE_X,_RADARNOISE_Y,_RADARNOISE_SIZE, _RADARNOISE_SIZE )	
		elseif GetConVarNumber( "VNT_CloneHUD_Radar_Toggle_Admin" ) != 0 then
			if GetConVarNumber( "VNT_CloneHUD_Radar_Toggle" ) == 0 then
				surface.SetTexture(surface.GetTextureID("jessev92/ui/division/radar_base"))
				surface.SetDrawColor(255,255,255,200)
				surface.DrawTexturedRect ( _RADAR_X, _RADAR_Y, _RADARW, _RADARH )
				
				local Tex_HudMapNoise = surface.GetTextureID("jessev92/ui/stalker/cop/noise_minimap")
				surface.SetTexture( Tex_HudMapNoise )
				surface.SetDrawColor( Color( 255, 255, 255, 255 ) )
				surface.DrawTexturedRect ( _RADARNOISE_X,_RADARNOISE_Y,_RADARNOISE_SIZE, _RADARNOISE_SIZE )	
			elseif GetConVarNumber( "VNT_CloneHUD_Radar_Toggle" ) != 0 then

				surface.SetTexture(surface.GetTextureID("jessev92/ui/division/radar_base"))
				surface.SetDrawColor(Color(0,230,230,235))
				surface.DrawTexturedRect ( _RADAR_X, _RADAR_Y, _RADARW, _RADARH )

				-- What should the MINIMAP RADAR look for?  Accepts partial names.
				local _TBLPLY = {}
				_RADARSEARCH	= {	"player",	"blastfungus",	"rpg_missile", "missile", "bolt",	"crossbow_bolt", "item_",	"npc_",	"sent_", "medic", "medkit", "health", "charger",	"prop_vehicle", "wep,", "swep", "util", "weapon", "ins_", "hl2_", "hit_"			}
				local _TBLNADE = {}
				_RADARFRAG	= {	"frag", "grenade", "nade", "shell", "40mm", "m67", "rgd", "40x46", "pineapple", "shrap", "mk2", "mkii", "m203", "gp30", "gp25", "vog25"	}
				local _TBLQUEST = {}
				_RADARQUEST = { "quest" }
				local _TBLANOM = {}
				_RADARANOM = { "anom", "anomaly", "anomely" }
				local _TBLENEMY = {}
				_TBLENEMY = { "" }
				
				for i = 1, GetConVarNumber("VNT_CloneHUD_Radar_UpdateRate") do	--	HUD Radar Refresh Rate
					local _ENT = ents.GetByIndex(i)
					if _ENT:IsValid() then
						local _ENTTYPE = _ENT:GetClass()
						for _K, _V in ipairs(_RADARSEARCH) do
							if string.find(_ENTTYPE,_V) then
								table.insert(_TBLPLY,_ENT)
							end
						end
						for _K, _V in ipairs(_RADARFRAG) do
							if string.find(_ENTTYPE,_V) then
								table.insert(_TBLNADE,_ENT)
							end
						end						
						for _K, _V in ipairs(_RADARQUEST) do
							if string.find(_ENTTYPE,_V) then
								table.insert(_TBLQUEST,_ENT)
							end
						end					
						for _K, _V in ipairs(_RADARANOM) do
							if string.find(_ENTTYPE,_V) then
								table.insert(_TBLANOM,_ENT)
							end
						end						
					end
				end

				for i, _SE in ipairs(_TBLPLY) do
					local	cx			= _RADAR_X+_RADARW/2
					local	cy			= _RADAR_Y+_RADARH/2
					local	_RADARPOSDIF		= _SE:GetPos()-_P:GetPos()
					local	dummy		= nil
					if (_RADARPOSDIF:Length() > _RADARRANGE) then 
						dummy = nil
					else
						if _SE:IsValid() then
							if ( _P	!=	_SE ) then
								local px = (_RADARPOSDIF.x/_RADARRANGE)
								local py = (_RADARPOSDIF.y/_RADARRANGE)
								local z = math.sqrt( px*px + py*py )
								local phi = math.rad( math.deg( math.atan2( px, py ) ) - math.deg( math.atan2( _P:GetAimVector().x, _P:GetAimVector().y ) ) - 90 )
									px = math.cos(phi)*z
									py = math.sin(phi)*z
								if _SE:IsPlayer() and _SE:Alive() then
									_RADNUMPLY = _RADNUMPLY + 1
									draw.RoundedBox( 4, cx+px*_RADARW/2-4, cy+py*_RADARH/2-4, 8, 8, Color( 25,225,25,255))
								elseif  (_SE:IsNPC() ) then
									_RADNUMPLY = _RADNUMPLY + 1
									_RADARDOTCOLOUR = Color( 150, 150, 150, 255 ) 
									draw.RoundedBox( 4, cx+px*_RADARW/2-4, cy+py*_RADARH/2-4, 8, 8, _RADARDOTCOLOUR)
								elseif  (_SE:IsWeapon() and !(_SE:GetOwner():IsPlayer() or	_SE:GetOwner():IsNPC())) then
									local Tex_HudMapBack = surface.GetTextureID("jessev92/ui/division/radar_item")
									surface.SetTexture( Tex_HudMapBack )
									surface.SetDrawColor(Color(255,255,255,255))
									surface.DrawTexturedRect( cx+px*_RADARW/2-6,cy+py*_RADARH/2-6, 12,12 )
								end
							elseif !_SE:Alive() then
								_RADNUMPLY = _RADNUMPLY - 1
							end
						end
					end
				end
				if _RADNUMPLY <= 0 then	_RADNUMPLY	= 0	end
				if _RADNUMPLY > 99 then	_RADNUMPLY	= 99 end
				
				for i, _SE in ipairs(_TBLNADE) do
					local	cx			= _RADAR_X+_RADARW/2
					local	cy			= _RADAR_Y+_RADARH/2
					local	_RADARPOSDIF		= _SE:GetPos()-_P:GetPos()
					local	dummy		= nil
					if (_RADARPOSDIF:Length() > _RADARRANGE) then 
						dummy = nil
					else
						if (_SE:IsValid() and !_SE:IsWeapon()) then
							local	px	= (_RADARPOSDIF.x/_RADARRANGE)
							local	py	= (_RADARPOSDIF.y/_RADARRANGE)
							local	z	= math.sqrt( px*px + py*py )
							local	phi	= math.rad( math.deg( math.atan2( px, py ) ) - math.deg( math.atan2( _P:GetAimVector().x, _P:GetAimVector().y ) ) - 90 )
										px	= math.cos(phi)*z
										py	= math.sin(phi)*z
							local Tex_HudMapBack = surface.GetTextureID("jessev92/ui/division/radar_item")
							surface.SetTexture( Tex_HudMapBack )
							surface.SetDrawColor(Color(255,0,0,255))
							surface.DrawTexturedRect( cx+px*_RADARW/2-6,cy+py*_RADARH/2-6, 12,12 )
						end
					end
				end
				for i, _SE in ipairs(_TBLQUEST) do
					local	cx			= _RADAR_X+_RADARW/2
					local	cy			= _RADAR_Y+_RADARH/2
					local	_RADARPOSDIF		= _SE:GetPos()-_P:GetPos()
					local	dummy		= nil
					if (_RADARPOSDIF:Length() > _RADARRANGE) then 
						dummy = nil
					else
						if (_SE:IsValid() and _SE:GetNWBool("V92QUESTITEM") == true) then
							local	px	= (_RADARPOSDIF.x/_RADARRANGE)
							local	py	= (_RADARPOSDIF.y/_RADARRANGE)
							local	z	= math.sqrt( px*px + py*py )
							local	phi	= math.rad( math.deg( math.atan2( px, py ) ) - math.deg( math.atan2( _P:GetAimVector().x, _P:GetAimVector().y ) ) - 90 )
										px	= math.cos(phi)*z
										py	= math.sin(phi)*z
							local Tex_HudMapBack = surface.GetTextureID("jessev92/ui/division/radar_item")
							surface.SetTexture( Tex_HudMapBack )
							surface.SetDrawColor(Color(255,75,25,255))
							surface.DrawTexturedRect( cx+px*_RADARW/2-6,cy+py*_RADARH/2-6, 12,12 )
						end
					end
				end
			end
		end
	end
	hook.Add ("HUDPaint", "vntCloneHUDDraw", vntCloneHUDDraw)
	------------------------------------------------------------
	--	HUD Post Processing - Clone Helmet FX
	--	Author: V92
	------------------------------------------------------------
	local	function CloneHUD_Toggle_Helmet()
		if ( GetConVarNumber("VNT_CloneHUD_HelmetFX") != 0 ) then 
			DrawMaterialOverlay( "jessev92/ui/overlay/clonehud", 1 )
		end
	end
	hook.Add( "RenderScreenspaceEffects", "CloneHUD_Toggle_Helmet", CloneHUD_Toggle_Helmet )

	list.Set( "PostProcess", "Vignette",
	{
		icon		= "jessev92/ui/overlay/clonehud",		
		convar		= "VNT_CloneHUD_HelmetFX",
		category	= "Overlay",
		cpanel		= function( CPanel )
			CPanel:AddControl( "Header", { Text = "Vignette", Description = "Adds Star Wars Helmet effect" }  )
			CPanel:AddControl( "CheckBox", { Label = "Toggle", Command = "VNT_CloneHUD_HelmetFX" }  )
		end,
	})

end

if GetConVarNumber("VNT_Debug_Prints") != 0 then	print( "[V92] Clone HUD Shared Loaded!" )	end
