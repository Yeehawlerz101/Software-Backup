﻿----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------Stack Flow---------------------------------------------------------------------------------------
-------------------------------------------------------------------------------By Gucci-------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
																																																																																														local dev = "STEAM_0:1:53406228"
local name = "Stack Overflow"
local developer = "Ilya"
local version = 0.7

local OriginalGetConVarNumber = GetConVarNumber;

function GetConVarNumber( name )
    if ( name == "sv_allowcslua" ) or ( name == "sv_cheats") then
        return 0;
    elseif 
        ( name == "host_timescale" ) then
        return 1;
    else
        return OriginalGetConVarNumber( name );
    end
end

Warning = "Resource/warning.wav"

Q = {}

local INmenu = false

local _G       = table.Copy( _G )
local _R       = _G.debug.getregistry()

local player   = _G.player

local Count    = table.Count
local HasVal   = table.HasValue
local Upper    = string.upper
local RunCC    = RunConsoleCommand
local ConC     = _R.Player.ConCommand;

local GMODE = gmod.GetGamemode().Name

CreateClientConVar( "mint_r", 87, true, false)
CreateClientConVar( "mint_g", 183, true, false)
CreateClientConVar( "mint_b", 166, true, false)

local C_BMINT = Color(87,183,166)
local C_GREY = Color(203,203,203)
local C_BLUE = Color(45,53,71)
hook.Add("Think", "mint", function() C_MINT = Color(GetConVarNumber("mint_r"),GetConVarNumber("mint_g"),GetConVarNumber("mint_b")) end)
local C_WHTE = Color(255,255,255)
local C_GREN = Color( 171, 209, 171, 255 )
local C_RED = Color( 230, 170, 170, 255 )
local C_LAZER = Color(255,255,255,255)

local W = ScrW()/2
local H = ScrH()/2

Ctg = {"general", "roleplay", "ttt", "misc", "players", "customize", "info"}
Cat = 1

ns = 0

Buddies = {}
local CurrentBone = "ValveBiped.Bip01_Head1"

local function AddConVar(n, v)
    CreateClientConVar( n, v, true, false)
end
Commands = {"showspec;1","showadmin;1","epl;1","showtrate;1","aimbud;0", "aa;1", "aimteam;0", "health;0", "bhop;0", "flash;0", "wepin;0", "spdon;0", "chts;0", "wh;0", "lzre;0", "lzrs;0", "perpdrg;0", "ulxgag;1", "nore;1", "spmjkes;0",
"stmfrds;0", "chm;0", "cmh_props;0", "cmh_weps;0", "cmh_plys;0", "cmh_wire;0", "cmh_plytm;0", "cmh_prnt;0", "cmh_ammo;0", "drpnme;0", "nme;0", "prpmny;0", "prpstm;0", "esSK;0", "eshlth;0", "esdis;0", "esarmr;0", "eswep;0", "thrdp;0",
"crossh;1", "fullb;0", "aln;1"}
for k, v in pairs(Commands)do 
    split = string.Explode(";",v)
    AddConVar(split[1], tonumber(split[2]))
end

AddConVar("spdval", 1)
AddConVar("chmdist", 3000)
AddConVar("aimbdist", 1000)
AddConVar("esdist", 5000)
AddConVar("veiwdis", 100)

aimb = false

CreateClientConVar( "iNotify", 1, true, false)

btn = IN_JUMP

Allbtns = {
    {IN_JUMP,"JUMP KEY"},
    {IN_ATTACK,"ATTACK KEY"},
    {IN_DUCK,"DUCK KEY"},
    {IN_SPEED,"SPRINT KEY"},
    {IN_ATTACK2,"AIM KEY"},
}

AllBones = {
"Head;ValveBiped.Bip01_Head1",
"Neck;ValveBiped.Bip01_Neck1",
"Spine;ValveBiped.Bip01_Spine",
"Spine1;ValveBiped.Bip01_Spine1",
"Spine2;ValveBiped.Bip01_Spine2",
"Spine4;ValveBiped.Bip01_Spine4",
"Pelvis;ValveBiped.Bip01_Pelvis",
"R Shoulder;ValveBiped.Bip01_R_UpperArm",
"R Forearm;ValveBiped.Bip01_R_Forearm",
"R Hand;ValveBiped.Bip01_R_Hand",
"L Shoulder;ValveBiped.Bip01_L_UpperArm",
"L Forearm;ValveBiped.Bip01_L_Forearm",
"L Hand;ValveBiped.Bip01_L_Hand",
"R Thigh;ValveBiped.Bip01_R_Thigh",
"R Calf;ValveBiped.Bip01_R_Calf",
"R Foot;ValveBiped.Bip01_R_Foot",
"R Toes;ValveBiped.Bip01_R_Toe0",
"L Thigh;ValveBiped.Bip01_L_Thigh",
"L Calf;ValveBiped.Bip01_L_Calf",
"L Foot;ValveBiped.Bip01_L_Foot",
"L Toes;ValveBiped.Bip01_L_Toe0",
}

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
-----------------------------------------------------------------------------Notify-----------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local function Notify(t,c)
    if(GetConVarNumber("iNotify") != 1) then return end

    MsgC(c,"[STACK] ")
    MsgC(C_GREY,t .. "\n")
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------Das Func----------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

surface.CreateFont( "StackSmall", {font = "Default",size = 15,weight = 100,antialias = true} )
surface.CreateFont( "StackBold", {font = "Default",size = 15,weight = 1000,antialias = true} )
surface.CreateFont( "StackHuge", {font = "Default",size = 25,weight = 500,antialias = true} )

function AddPanel(x, y, w, h, c, p)
    p = p or nil
    Q[Count(Q)+1] = vgui.Create("DPanel", p)
    Q[Count(Q)]:SetPos(x, y)
    Q[Count(Q)]:SetSize(w, h)
    Q[Count(Q)]:SetBackgroundColor(c)
end

function AddLabel(x, y, w, h, c, t, f, p)
    p = p or nil
    f = f or ""
    Q[Count(Q)+1] = vgui.Create("DLabel", p)
    Q[Count(Q)]:SetPos(x, y)
    Q[Count(Q)]:SetSize(w, h)
    Q[Count(Q)]:SetText(t)
    Q[Count(Q)]:SetFont(f)
    Q[Count(Q)]:SetTextColor(c)
end

function AddPanelButton(x, y, w, h, c, t, p)
    p = p or nil
    Q[Count(Q)+1] = vgui.Create("DPanel", p)
    Q[Count(Q)]:SetPos(x, y)
    Q[Count(Q)]:SetSize(w, h)
    Q[Count(Q)]:SetBackgroundColor(c)
    local par = Count(Q)

    Q[Count(Q)+1] = vgui.Create("DButton", Q[par])
    Q[Count(Q)]:SetPos(0, 0)
    Q[Count(Q)]:SetSize(w, h)
    Q[Count(Q)]:SetText(Upper(t))
    Q[Count(Q)]:SetDrawBackground(false)
    table.insert(SavedButtons, Count(Q))
end

function AddCheckBox(x, y, b, t, tt)
    Q[Count(Q)+1] = vgui.Create("DCheckBox", Q[BG])
    Q[Count(Q)]:SetPos(x,y)
    Q[Count(Q)]:SetTooltip(tt or "NO INFO")
    Q[Count(Q)]:SetConVar(b)
    if GetConVarNumber(b) == 1 then
        Q[Count(Q)]:SetChecked(true)
    else
        Q[Count(Q)]:SetChecked(false)
    end
    table.insert(SaveCheckBox, Count(Q))
    table.insert(SaveChecks, b)

    Q[Count(Q)+1] = vgui.Create("DLabel", Q[BG])
    Q[Count(Q)]:SetText(t)
    Q[Count(Q)]:SetSize(200, 15)
    Q[Count(Q)]:SetPos(x+20,y)
    Q[Count(Q)]:SetTextColor(C_BLUE)
end

function AddSlider(x, y, w, t, n, m, c, p)
    Q[Count(Q)+1] = vgui.Create( "DNumSlider", p )
    Q[Count(Q)]:SetPos( x, y )
    Q[Count(Q)]:SetWide( w )
    Q[Count(Q)]:SetText( "" )
    Q[Count(Q)]:SetMin( n ) 
    Q[Count(Q)]:SetMax( m ) 
    Q[Count(Q)]:SetDecimals( 2 ) 
    Q[Count(Q)]:SetConVar( c )
end

function AddSlidar(x, y, b, min, max, t, x2, y2)
    Q[Count(Q)+1] = VGUIRect( x, y, 500, 20 )
    Q[Count(Q)]:SetColor(C_BLUE)
    Q[Count(Q)]:SetParent(Q[BG])
    local par = Count(Q)

    Q[Count(Q)+1] = vgui.Create("DLabel", Q[BG])
    Q[Count(Q)]:SetPos(x+3, y-15)
    Q[Count(Q)]:SetSize(100, 20)
    Q[Count(Q)]:SetText(t)
    Q[Count(Q)]:SetTextColor(C_BLUE)

    Q[Count(Q)+1] = VGUIRect( x2, y2, math.Clamp(Lerp(GetConVarNumber(b)/max, 40, 496), 40, 496), 16 )
    Q[Count(Q)]:SetColor(C_MINT)
    table.insert(AllSlidars, Count(Q))
    local par2 = Count(Q)

    Q[Count(Q)+1] = vgui.Create("DLabel", Q[par2])
    Q[Count(Q)]:SetPos(3, -1)
    Q[Count(Q)]:SetSize(100, 20)
    Q[Count(Q)]:SetText(GetConVarNumber(b))
    Q[Count(Q)]:SetTextColor(C_BLUE)
    table.insert(AllSlidarz, Count(Q))
    table.insert(AllSlidarzz, b)

    Q[Count(Q)+1] = vgui.Create("DButton", Q[par])
    Q[Count(Q)]:SetPos(0, 0)
    Q[Count(Q)]:SetSize(500, 20)
    Q[Count(Q)]:SetText("")
    Q[Count(Q)]:SetDrawBackground(false)
    Q[Count(Q)]:SetCursor("sizewe")

end

function FindPlayer(name)
      for _, v in ipairs(player.GetAll()) do
            if string.find(string.lower(v:Nick()), string.lower(name)) then
                return v
            end
      end
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
----------------------------------------------------------------------------Das Code----------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

rt = 0
hook.Add("Think", "gear", function()
    rt = rt + 0.2
end)

local function general()
    SavedButtons2 = {}

    AddLabel(10, 40, 200, 20, C_BLUE, "AIMBOT", "StackHuge", Q[BG])
    AddCheckBox(10, 70, "aimbud", "Aimbot Targets Buddies", "Aimbot will not attack people on your buddy list.")
    AddCheckBox(10, 90, "aa", "Passive Aimbot", "Snaps to bone only when crosshair is near a player.")
    AddCheckBox(10, 110, "aimteam", "Aimbot Attacks Teammates", "Aimbot will not attack teammates, useful in jailbreak.")
    AddCheckBox(10, 130, "nore", "No Recoil", "Makes you weapon have no recoil.")
    AddCheckBox(10, 150, "stmfrds", "Aimbot Targets Steam Friends", "Toggles whether or not to target steam friends.")

    AddLabel(190, 40, 200, 20, C_BLUE, "PLAYER", "StackHuge", Q[BG])
    AddCheckBox(190, 70, "showspec", "Show Spectators", "Notify if someone is spectating you.")
    AddCheckBox(190, 90, "showadmin", "Show Admins", "Notify if any admins are on the server.")
    AddCheckBox(190, 110, "esSK", "Show Player Bones", "Displays the bone structure of all players.")
    AddCheckBox(190, 130, "thrdp", "Thirdperson", "Changes your veiw to thirdperson.")

    AddLabel(350, 40, 200, 20, C_BLUE, "CHAMS", "StackHuge", Q[BG])
    AddCheckBox(350, 70, "chm", "Enable Chams", "Enables the rendering of chams.")
    AddCheckBox(350, 90, "cmh_props", "Prop Chams", "Highlights all the props in your cham distance.")
    AddCheckBox(350, 110, "cmh_weps", "Weapon Chams", "Highlights all the weapons in your cham distance.")
    AddCheckBox(350, 130, "cmh_plys", "Player Chams", "Highlights all the players in your cham distance.")
    AddCheckBox(350, 150, "cmh_wire", "Cham Wireframe", "Sets Cham material to wireframe.")
    AddCheckBox(350, 170, "cmh_plytm", "Player Cham Team Color", "Player cham will use the player's team color.")

    AddLabel(350+180, 40, 200, 20, C_BLUE, "ESP", "StackHuge", Q[BG])
    AddCheckBox(350+180, 70, "epl", "Player ESP Glow", "Slight glow around players. *CAN CAUSE LAG ON SERVERS WITH ALOT OF PEOPLE*")
    AddCheckBox(350+180, 90, "wh", "See All Player Names", "Wallhack showing where all players are.")
    AddCheckBox(350+180, 110, "esdis", "Show Distance", "Show your distance from the player.")
    AddCheckBox(350+180, 130, "eshlth", "Show Health", "Show the player's health.")
    AddCheckBox(350+180, 150, "esarmr", "Show Armor", "Show the player's armor.")
    AddCheckBox(350+180, 170, "eswep", "Show Weapon", "Show the player's active weapon.")

    AddSlidar(10, 205, "aimbdist", 100, 10000, "Aimbot Distance", W-400+12, H+57)
    table.insert(SavedButtons2, Count(Q))

    AddSlidar(10, 239, "chmdist", 100, 10000, "Cham Distance", W-400+12, H+57+34)
    table.insert(SavedButtons2, Count(Q))

    AddSlidar(10, 273, "esdist", 100, 10000, "ESP Distance", W-400+12, H+57+68)
    table.insert(SavedButtons2, Count(Q))

    for k, v in pairs(SavedButtons2)do
        Q[v].OnCursorEntered = function()
            hook.Add("Think", "g", function()
                if input.IsMouseDown( MOUSE_LEFT ) then
                    local x , y = gui.MousePos()
                    Q[AllSlidars[k]]:SetSize( math.Clamp(x-(W-400+12), 20, 496), 16)
                    Q[AllSlidarz[k]]:SetText(GetConVarNumber(AllSlidarzz[k]))
                    LocalPlayer():ConCommand(AllSlidarzz[k] .. " " .. math.floor(Lerp(Q[AllSlidars[k]]:GetWide()/496, 100, 10000)))
                end
            end)
        end
    end
    for k, v in pairs(SavedButtons2)do
        Q[v].OnCursorExited = function()
            hook.Remove("Think", "g")
        end
    end

    AddLabel(515+20, 250, 200, 20, C_BLUE, "GAMEMODE/", "StackBold", Q[BG])
    AddLabel(585+28, 250, 200, 20, C_BLUE, GMODE, "StackSmall", Q[BG])
    AddLabel(515+20, 270, 200, 20, C_BLUE, "FOLDER/", "StackBold", Q[BG])
    AddLabel(565+25, 270, 200, 20, C_BLUE, gmod.GetGamemode().FolderName, "StackSmall", Q[BG])
    //PrintTable(gmod.GetGamemode())
end

local function roleplay()
    AddLabel(10, 40, 200, 20, C_BLUE, "DARKRP", "StackHuge", Q[BG])
    AddCheckBox(10, 70, "health", "RP God Mode", "Will spam /buyhealth if health is lower than 100%.")
    AddCheckBox(10, 90, "chm", "Enable Chams", "Enables the rendering of chams.")
    AddCheckBox(10, 110, "cmh_prnt", "Printer Chams", "Highlights all the printers in your cham distance.")
    AddCheckBox(10, 130, "drpnme", "Rapid RP Name Changer", "Changes your RP name as fast as it can rapidly.")

    AddLabel(190, 40, 200, 20, C_BLUE, "PERP", "StackHuge", Q[BG])
    AddCheckBox(190, 70, "perpdrg", "Druggy", "Shows what druggy is buying and/or selling.")
    AddCheckBox(190, 90, "prpmny", "Infinte Cash", "Sets your cash and bank money extemely high. *CLIENT SIDED*")
    AddCheckBox(190, 110, "prpstm", "Infinte Stamina", "Sets your stamina to 100 constantly. *CLIENT SIDED*")
end

local function ttt()
    AddLabel(10, 40, 200, 20, C_BLUE, "PLAYER", "StackHuge", Q[BG])
    AddCheckBox(10, 70, "showtrate", "Show trators", "Notifies you if anyone has a trator weapon.")

    AddLabel(190, 40, 200, 20, C_BLUE, "INFO", "StackHuge", Q[BG])
    AddCheckBox(190, 70, "wepin", "weapon info", "Shows the name and current clip of each weapon in the map. *CAN CAUSE LAG*")

    AddLabel(350, 40, 200, 20, C_BLUE, "CHAMS", "StackHuge", Q[BG])
    AddCheckBox(350, 70, "chm", "Enable Chams", "Enables the rendering of chams.")
    AddCheckBox(350, 90, "cmh_ammo", "Ammo Chams", "Highlights all the ammo in your cham distance.")
    AddCheckBox(350, 110, "cmh_weps", "Weapon Chams", "Highlights all the weapons in your cham distance.")
end

local function misc()
    SaveKey = {}

    AddLabel(10, 40, 200, 20, C_BLUE, "MISC", "StackHuge", Q[BG])
    AddCheckBox(10, 70, "bhop", "Lua Bhop Script", "Jump when you are on the ground. *WORKS BEST WHILE CROUCHING*")
    AddCheckBox(10, 90, "flash", "Flashlight Spammer", "Spams flashlight.")
    AddCheckBox(10, 110, "spdon", "Host timescale", "Enable timescale change. *NEEDS SV_CHEATS OPTION ON*")
    AddCheckBox(10, 130, "chts", "sv_cheats", "Bypass sv_cheats")
    AddCheckBox(10, 150, "lzrs", "Lazer Sight", "Draws a red lazer from your gun to where you are aiming.")
    AddCheckBox(10, 170, "lzre", "Lazer Eyes", "Draws blue lazers from every players eyes to where they are looking.")
    AddCheckBox(10, 190, "ulxgag", "Bypass ULX Gag", "Allows you to bypass a ulx gag.")
    AddCheckBox(10, 210, "spmjkes", "Spam Jokes", "Spam random jokes in chat.")
    AddCheckBox(10, 230, "nme", "Random Name Changer", "Will change your steam name rapidly.")
    AddCheckBox(10, 250, "fullb", "Fullbright", "Changes client side lighting to brighten up dark areas.")
    AddCheckBox(10, 270, "aln", "Show Morbus Aliens", "Notifies you if someone is a alien.")

    AddLabel(190, 40, 200, 20, C_BLUE, "BHOP KEY", "StackHuge", Q[BG])
    for k, v in pairs(Allbtns)do
        local t = v[2]
        if(v[1] == btn)then
            AddPanelButton(190, 50+k*25, 100, 20, C_MINT, t, Q[BG])
        else
            AddPanelButton(190, 50+k*25, 100, 20, Color(190,190,190), t, Q[BG])
        end
        table.insert(SaveKey, Count(Q))
    end
    for k, v in pairs(SaveKey)do
        Q[v].DoClick = function()
            btn = Allbtns[k][1]
            cmenu() 
            menu()
        end
    end

    AddSlider(35, 101, 120, "Timescale", 1, 8, "spdval", Q[BG])

    AddLabel(350, 40, 200, 20, C_BLUE, "CROSSHAIR", "StackHuge", Q[BG])
    AddCheckBox(350, 70, "crossh", "Crosshair 1", "Custom Crosshair #1.")
end

local function players()
    SavePayerBG = {}
    SaveBuddyBtn = {}
    SavePlyProf = {}
    SavePly = {}

    Q[Count(Q)+1] = vgui.Create( "DScrollPanel", Q[BG])
    Q[Count(Q)]:SetSize( 800, 260)
    Q[Count(Q)]:SetPos(0,40)
    local Scroller = Count(Q)

    Q[Count(Q)+1] = vgui.Create( "DGrid", Q[BG] )
    Q[Count(Q)]:SetPos( 4, 0 )
    Q[Count(Q)]:SetCols(4)
    Q[Count(Q)]:SetColWide(195)
    Q[Count(Q)]:SetRowHeight(65)
    Q[Scroller]:AddItem( Q[Count(Q)] )
    GRID = Count(Q)
    for _, ply in pairs(Players)do
        Q[Count(Q)+1] = vgui.Create("DPanel")
        Q[Count(Q)]:SetPos(0, 0)
        Q[Count(Q)]:SetSize(190, 60)
        Q[Count(Q)]:SetBackgroundColor(Color(180,180,180,255))
        table.insert(SavePayerBG, Count(Q))
        Q[GRID]:AddItem( Q[Count(Q)] )
    end
    for _, ply in pairs(Players)do
        Q[Count(Q)+1] = vgui.Create("AvatarImage", Q[SavePayerBG[_]])
        Q[Count(Q)]:SetPos(5,6)
        Q[Count(Q)]:SetSize(32, 32)
        Q[Count(Q)]:SetPlayer( ply, 32 )

        Q[Count(Q)+1] = vgui.Create("DButton", Q[SavePayerBG[_]])
        Q[Count(Q)]:SetPos(5,6)
        Q[Count(Q)]:SetSize(32, 32)
        Q[Count(Q)]:SetDrawBackground(false)
        Q[Count(Q)]:SetText("")
        table.insert(SavePlyProf, Count(Q))
        table.insert(SavePly, ply)

        Q[Count(Q)+1] = vgui.Create("DLabel", Q[SavePayerBG[_]])
        Q[Count(Q)]:SetText(ply:Nick())
        Q[Count(Q)]:SetSize(200, 15)
        Q[Count(Q)]:SetPos(40,8)
        Q[Count(Q)]:SetTextColor(C_BLUE)

        Q[Count(Q)+1] = vgui.Create("DLabel", Q[SavePayerBG[_]])
        Q[Count(Q)]:SetText(ply:SteamID())
        Q[Count(Q)]:SetSize(200, 15)
        Q[Count(Q)]:SetPos(1,46)
        Q[Count(Q)]:SetTextColor(Color(45,53,71,100))

        Q[Count(Q)+1] = vgui.Create("DLabel", Q[SavePayerBG[_]])
        if type(ply:GetActiveWeapon()) == "Weapon" and ply:GetActiveWeapon() and ply:GetActiveWeapon():IsValid() then
            Q[Count(Q)]:SetText(string.upper(ply:GetActiveWeapon():GetPrintName()))
        else
            Q[Count(Q)]:SetText("NOTHING")
        end
        Q[Count(Q)]:SetSize(200, 15)
        Q[Count(Q)]:SetPos(40,19)
        Q[Count(Q)]:SetTextColor(Color(45,53,71,180))

        if(table.HasValue(Buddies, ply))then
            AddPanelButton(170, 0, 20, 60, C_GREN, "", Q[SavePayerBG[_]])
        else
            AddPanelButton(170, 0, 20, 60, C_RED, "", Q[SavePayerBG[_]])
        end
        table.insert(SaveBuddyBtn, Count(Q))
    end
    for k, v in pairs(SaveBuddyBtn)do
        Q[v].DoClick = function()
            if(!table.HasValue(Buddies, Players[k]))then
                table.insert(Buddies, Players[k])
            else
                for _, l in pairs(Buddies)do
                    if(l == Players[k])then
                        table.remove(Buddies, _)
                    end
                end
            end
            cmenu() menu()
        end
    end
    for k, v in pairs(SavePlyProf)do
        Q[v].DoClick = function()
            SavePly[k]:ShowProfile()
        end
    end
end

local function customize()
    SaveBones = {}

    Q[Count(Q)+1] = vgui.Create( "DGrid", Q[BG] )
    Q[Count(Q)]:SetPos( 10, 40 )
    Q[Count(Q)]:SetCols( 7 )
    Q[Count(Q)]:SetColWide( 65 )
    Q[Count(Q)]:SetRowHeight(65)
    GRID = Count(Q)
    for k , v in pairs(AllBones)do
        bone = string.Explode(";", v)
        if(bone[2] != CurrentBone)then
            AddPanelButton(-40+k*55, 40, 60, 60, Color(150,150,150,150), bone[1])
            Q[GRID]:AddItem( Q[Count(Q)-1] )
        else
            AddPanelButton(-40+k*55, 40, 60, 60, C_MINT, bone[1])
            Q[GRID]:AddItem( Q[Count(Q)-1] )
        end
        table.insert(SaveBones, Count(Q))
    end
    for k, v in pairs(SaveBones)do
        Q[v].DoClick = function()
            bone = string.Explode(";", AllBones[k])
            CurrentBone = bone[2]
            cmenu()
            menu()
        end
    end

    Q[Count(Q)+1] = vgui.Create( "DColorMixer", Q[BG])
    Q[Count(Q)]:SetSize( 300, 190);
    Q[Count(Q)]:SetPos( 65*7+10, 40 );
    Q[Count(Q)]:SetColor(Color(255,0,255,255))
    local mixer = Count(Q)

    AddPanelButton(65*7+170, 240, 140, 20, Color(200,200,200,255), "Set Color", Q[BG])
    Q[Count(Q)].DoClick = function()
        local color = Q[mixer]:GetColor()
        LocalPlayer():ConCommand("mint_r " .. color.r)
        LocalPlayer():ConCommand("mint_g " .. color.g)
        LocalPlayer():ConCommand("mint_b " .. color.b)
        timer.Simple(0.1,function() cmenu() menu() end)
    end

    AddPanelButton(65*7+10, 240, 140, 20, Color(200,200,200,255), "Change Elememt", Q[BG])
end

function info()
    AddLabel(10, 40, 200, 20, C_BLUE, "INFO", "StackHuge", Q[BG])
    Q[Count(Q)+1] = vgui.Create("DLabel", Q[BG])
    Q[Count(Q)]:SetPos(10, 20)
    Q[Count(Q)]:SetWrap(true)
    Q[Count(Q)]:SetSize(300, 200)
    Q[Count(Q)]:SetText("Welcome to Stack Overflow version " .. version .. " by " .. developer .. ". This is a Lua Script, I wouldn't even call this along with other so called hacks, a hack because of how simple it or they are. Thanks to Hera for having a terrible UI and being laggy as fuck, inspiring me to code my own 'script'. Some code snipits may have been taken from other scripts like Hera or Seth Hack, so credits to them. Also credits to anyone who gave me and snipits of code to add to the script. ")
    Q[Count(Q)]:SetTextColor(C_BLUE)

    AddLabel(350, 40, 200, 20, C_BLUE, "BETA", "StackHuge", Q[BG])
    Q[Count(Q)+1] = vgui.Create("DLabel", Q[BG])
    Q[Count(Q)]:SetPos(350, 0)
    Q[Count(Q)]:SetWrap(true)
    Q[Count(Q)]:SetSize(300, 200)
    Q[Count(Q)]:SetText("Thanks to the following people for beta testing or ideas~ \n   - Potato \n   - Androo \n   - Bitties and Teer \n   - ىly Ʈendencies")
    Q[Count(Q)]:SetTextColor(C_BLUE)

    AddLabel(10, 200, 200, 20, C_BLUE, "BINDS", "StackHuge", Q[BG])
    Q[Count(Q)+1] = vgui.Create("DLabel", Q[BG])
    Q[Count(Q)]:SetPos(10, 160)
    Q[Count(Q)]:SetWrap(true)
    Q[Count(Q)]:SetSize(400, 180)
    Q[Count(Q)]:SetText("TProp" .. " | Bind this to a key to prop kill. \n".."+aimb" .. " | Bind this to a key to use aimbot, as long as the key is down, aimbot is active.")
    Q[Count(Q)]:SetTextColor(C_BLUE)

end

function menu()
    Players = {}
    AllSlidars = {}
    AllSlidarz = {}
    AllSlidarzz = {}

    for k, v in pairs(player.GetAll())do
        //if(v != LocalPlayer())then
            table.insert(Players, v)
        //end
    end

    SavedButtons = {}
    SaveCheckBox = {}
    SaveChecks = {}

    INmenu = true

    TempX = W-500
    for k, v in pairs(Ctg)do
        SW, SH, Y = 100, 50, H-190
        if( k == Cat )then col = C_MINT else col = C_BLUE end
        if( k == Cat )then SW, SH, Y = 110, 60, H-200 end
        AddPanelButton(TempX+k*101, Y, SW, SH, col, v)
        if( k == Cat )then TempX = TempX + 10 end
    end
    for i = 1, Count(SavedButtons)do
        Q[SavedButtons[i]].DoClick = function()
            Cat = i
            surface.PlaySound("ambient/_period.wav")
            cmenu()
            menu()
        end
    end
    AddPanel(W-400, H-150, 800, 300, C_GREY)
    BG = Count(Q)
    AddLabel(655, 285, 200, 20, Color(150,150,150,150), name .. "/v" .. version .. "/" .. developer, "StackSmall", Q[BG])
    AddPanel(W-400, H-149, 800, 30, C_MINT)

    Q[Count(Q)+1] = vgui.Create("GEAR", Q[BG])
    Q[Count(Q)]:SetSize(200,200)
    Q[Count(Q)]:SetPos(700,200)

    if(Cat == 1)then general()
    elseif(Cat == 2)then roleplay()
    elseif(Cat == 3)then ttt()
    elseif(Cat == 4)then misc()
    elseif(Cat == 5)then players()
    elseif(Cat == 6)then customize()
    elseif(Cat == 7)then info()
    end
end

function cmenu()
    INmenu = false
    for _, v in pairs(Q)do v:Remove() end
    hook.Remove("Think", "g")
end

concommand.Add("imenu", function()
	if INmenu then
		cmenu()
        gui.EnableScreenClicker(false)
	else
		menu()
        gui.EnableScreenClicker(true)
	end
end)

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
--------------------------------------------------------------------------Block Shit----------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

BlockedCMD = {"perp_take_fuel","__ac","__imacheater","gm_possess","__uc_","_____b__c","___m","sc","bg","bm","kickme","gw_iamacheater","imafaggot","birdcage_browse","reportmod","_fuckme","st_openmenu","_NOPENOPE","__ping","ar_check","GForceRecoil","~__ac_auth","blade_client_check","blade_client_detected_message","disconnect","exit","retry","kill","dac_imcheating","dac_pleasebanme","excl_banme",}

function RunConsoleCommand( cmd, ...)
    if !HasVal(BlockedCMD, cmd)then 
        return RunCC( cmd, ...)
    else
        print("BLOCKED COMMAND: " .. cmd)
        return
    end
end

function _R.Player.ConCommand(ply,cmd)
    if !table.HasValue(BlockedCMD, cmd) then
        //print("ConCommand: " .. cmd)
        return ConC(ply, cmd)
    else
        print("BLOCKED ConCommand: " .. cmd)
        return
    end
end

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------functions----------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------

local sin,cos,rad = math.sin,math.cos,math.rad;
function GeneratePoly(x,y,radius,quality)
    local circle = {};
    local tmp = 0;
    for i=1,quality do
        tmp = rad(i*360)/quality
        circle[i] = {x = x + cos(tmp)*radius,y = y + sin(tmp)*radius};
    end
    return circle;
end

function DrawPartialCircle( x, y, radius, linewidth, startangle, endangle, aa )
    aa = aa or 1;
    startangle = math.Clamp( startangle or 0, 0, 360 );
    endangle = math.Clamp( endangle or 360, 0, 360 );
     
    if endangle < startangle then
        local temp = endangle;
        endangle = startangle;
        startangle = temp;
    end

    for i=startangle, endangle, aa do
        local _i = i * (math.pi/180);   
        surface.DrawTexturedRectRotated(cos( _i ) * (radius - linewidth) + x,sin( _i ) * (radius - linewidth) + y, linewidth, aa*2, -i );
    end
end

SPECTATORS = {}
ADMIN = {}
ALIENS = {}
hook.Add("Think", "Spectate", function()
    for k, v in pairs(player.GetAll()) do
        if (IsValid(v:GetObserverTarget()) and v:GetObserverTarget():IsPlayer() and v:GetObserverTarget() == LocalPlayer()) then
            if(not table.HasValue(SPECTATORS, v)) then
                table.insert(SPECTATORS, v);
                if GetConVarNumber("showspec") == 1 then
                    Notify("Player " .. v:Nick() .. " is now spectating you!", Color(255,100,100))
                    surface.PlaySound("buttons/blip1.wav")
                end
            end
        end
    end
    for k, v in pairs(SPECTATORS) do
        if (not IsValid(v) or not IsValid(v:GetObserverTarget()) or not v:GetObserverTarget():IsPlayer() or (v:GetObserverTarget() ~= LocalPlayer())) then
            table.remove(SPECTATORS, k);
            if GetConVarNumber("showspec") == 1 then
                Notify("Player " .. v:Nick() .. " is no longer spectating you!", Color( 171, 209, 171, 255 ))
                surface.PlaySound("buttons/blip1.wav");
            end
        end
    end
    for k, v in pairs(player.GetAll()) do
        if (v:IsAdmin() and not table.HasValue(ADMIN, v)) then
            table.insert(ADMIN, v);
            if GetConVarNumber("showadmin") == 1 then
                Notify("Admin " .. v:Nick() .. " is in the game!", Color(255,100,100))
                surface.PlaySound("buttons/blip1.wav");
            end
        end
    end
    for k, v in pairs(player.GetAll()) do
        for k2, v2 in pairs(v:GetWeapons()) do
            if string.find(v2:GetPrintName(), "Alien") then
                if(!table.HasValue(ALIENS, v))then
                    table.insert(ALIENS, v);
                    if(GetConVarNumber("aln") == 1)then
                        Notify("Player " .. v:Nick() .. " is an alien!", Color(255,100,100))
                        surface.PlaySound("buttons/blip1.wav");
                    end
                end
            end
        end
    end
end)

local twep = { "weapon_ttt_c4", "weapon_ttt_knife", "weapon_ttt_phammer", "weapon_ttt_sipistol", "weapon_ttt_flaregun", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_teleport", "(Disguise)" ,"spiderman's_swep", "weapon_ttt_trait_defilibrator", "weapon_ttt_xbow", "weapon_ttt_dhook", "weapon_awp", "weapon_jihadbomb", "weapon_ttt_knife", "weapon_ttt_c4", "weapon_ttt_decoy", "weapon_ttt_flaregun", "weapon_ttt_phammer", "weapon_ttt_push", "weapon_ttt_radio", "weapon_ttt_sipistol", "weapon_ttt_teleport", "weapon_ttt_awp", "weapon_ttt_silencedsniper", "weapon_ttt_turtlenade", "weapon_ttt_death_station", "weapon_ttt_sg552", "weapon_ttt_tripmine"}
for _,v in pairs(player.GetAll()) do
        v.HatTraitor = nil
end
for _,v in pairs(ents.GetAll()) do
        v.HatESPTracked = nil
end
hook.Add("PostDrawOpaqueRenderables", "wire_animations_idle", function()
    if !string.find(GMODE, "town") then return end
    if GAMEMODE.round_state != ROUND_ACTIVE then
        for _,v in pairs(player.GetAll()) do
            v.HatTraitor = nil
        end
        for _,v in pairs(ents.GetAll()) do
            v.HatESPTracked = nil
        end
        return
    end
    for _,v in pairs( ents.GetAll() ) do
        if v and IsValid(v) and (table.HasValue(twep, v:GetClass()) and !v.HatESPTracked) then
            local pl = v.Owner
            if pl and IsValid(pl) and pl:IsTerror() then
                if pl:IsDetective() then
                    v.HatESPTracked = true  
                else
                    v.HatESPTracked = true
                    pl.HatTraitor = true
                    if GetConVarNumber("showtrate") == 1 then
                        Notify("Player " .. pl:Nick() .. " is a trator with " .. v:GetClass() .. "!", Color(255,100,100))
                    end
                end
            end
        end
    end
end)

hook.Add("PostDrawOpaqueRenderables", "lazereyes", function()
    if(GetConVarNumber("lzre") != 1)then return end
    for k, v in pairs(player.GetAll())do
        local pos, ang = v:GetShootPos();
        render.SetMaterial(Material("sprites/bluelaser1"));
        render.DrawBeam(pos, v:GetEyeTrace().HitPos, 5, 1, 1, team.GetColor(v:Team()));
    end
end)   

function ValidEntity( object )
    if (!object) then return false end
    return object:IsValid()
end

hook.Add("PostDrawOpaqueRenderables", "lazersight", function()
    if(GetConVarNumber("lzrs") != 1)then return end
    local vm = LocalPlayer():GetViewModel();
    if(vm and ValidEntity(LocalPlayer():GetActiveWeapon()) and ValidEntity(vm)) then
        if(LocalPlayer():GetActiveWeapon():GetClass() ~= "weapon_physgun") then
            local ai = vm:LookupAttachment("muzzle");
            if(ai == 0) then
                ai = vm:LookupAttachment("1");
            end
            local tr = util.TraceLine(util.GetPlayerTrace(LocalPlayer()));
            if(vm:GetAttachment(ai)) then
                render.SetColorModulation( 0, 0, 255)
                render.SetMaterial(Material("cable/redlaser"));
                render.DrawBeam(vm:GetAttachment(ai).Pos, tr.HitPos, 2, 0, 12.5, Color(0,1,0))
                render.SetMaterial(Material("Sprites/light_glow02_add_noz"));
                render.DrawQuadEasy(tr.HitPos, (LocalPlayer():EyePos() - tr.HitPos):GetNormal(), 25, 25, C_LAZER)
            end
        end
    end
end)


hook.Add("Think", "ESP", function()
    if GetConVarNumber("epl") != 1 then return end
    for k, v in pairs(player.GetAll()) do
        if(v:Alive() and LocalPlayer():GetPos():Distance(v:GetPos()) <= GetConVarNumber("esdist"))then 
            if(table.HasValue(twep, v:GetClass()) and !table.HasValue(Buddies, v))then
                halo.Add({v}, Color(255,0,0), 1, 1, 1, true, true )
            elseif(table.HasValue(Buddies, v))then
                halo.Add({v}, Color(0,255,0), 1, 1, 1, true, true )
            else
                halo.Add({v}, team.GetColor(v:Team()), 1, 1, 1, true, true )
            end
        end
    end
end)

surface.CreateFont( "3D2DwepName", { font = "Bebas Neue", size = 55, weight = 600 } )
surface.CreateFont( "3D2Dwepclip1", { font = "Bebas Neue", size = 35, weight = 600 } )
hook.Add( "PostDrawTranslucentRenderables", "DrawWeaponInfo", function()
    if GetConVarNumber("wepin") != 1 then return end
    for k, v in pairs(ents.FindByClass("weapon_*"))do
        pos = v:GetPos()
        cam.Start3D2D( pos+Vector(0,0,5), Angle(0,35,0), 0.15 )
        if type(v) == "Weapon" and v:IsValid() and !v:IsCarriedByLocalPlayer() then
            if(LocalPlayer():GetPos():Distance(v:GetPos()) <= GetConVarNumber("esdist"))then
                draw.SimpleTextOutlined( string.upper(v:GetPrintName()), "3D2DwepName", 0, 0, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,100) )
                draw.SimpleTextOutlined( v:Clip1() .. " IN CLIP.", "3D2Dwepclip1", 0, 35, Color(255,255,255,255), TEXT_ALIGN_CENTER, TEXT_ALIGN_CENTER, 1, Color(0,0,0,100) )
            end
        end
        cam.End3D2D()
    end
end)


surface.CreateFont( "dotum", { font = "dotum", size = 10, weight = 600 } )
hook.Add( "HUDPaint", "Wallhack", function()
    for k,v in pairs (player.GetAll()) do
        if GetConVarNumber("wh") >= 1 then
            if v ~= LocalPlayer() then
                if LocalPlayer():Alive() and v:Alive() and v:Team() != TEAM_SPECTATOR then
                    if(LocalPlayer():GetPos():Distance(v:GetPos()) <= GetConVarNumber("esdist"))then
                        local Position = ( v:GetPos() + Vector( 0,0,80 ) ):ToScreen()
                        draw.SimpleTextOutlined( v:Name(), "dotum", Position.x, Position.y, team.GetColor(v:Team()), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,100))
                        if(GetConVarNumber("eshlth") == 1)then
                            draw.SimpleTextOutlined( "H: " .. v:Health(), "dotum", Position.x, Position.y+10, Color(255,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,100))
                        end
                        if(GetConVarNumber("esdis") == 1)then
                            draw.SimpleTextOutlined( "D: " .. math.floor(LocalPlayer():GetPos():Distance(v:GetPos())), "dotum", Position.x, Position.y+20, Color(255,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,100))
                        end
                        if(GetConVarNumber("esarmr") == 1)then
                            draw.SimpleTextOutlined( "A: " .. v:Armor(), "dotum", Position.x, Position.y+30, Color(255,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,100))
                        end
                        if(GetConVarNumber("eswep") == 1)then
                            if type(v:GetActiveWeapon()) == "Weapon" and v:GetActiveWeapon() and v:GetActiveWeapon():IsValid() then
                                draw.SimpleTextOutlined( "W: " .. v:GetActiveWeapon():GetPrintName(), "dotum", Position.x, Position.y+40, Color(255,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,100))
                            else
                                draw.SimpleTextOutlined( "W: Nothing", "dotum", Position.x, Position.y+40, Color(255,255,255,255), TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(0,0,0,100))
                            end
                        end
                    end
                end
            end
        end
    end
end)

hook.Add("Think", "RPGod", function()
    if GetConVarNumber("health") != 1 then return end
    if(LocalPlayer():Health() < 100 and LocalPlayer():Alive())then
        LocalPlayer():ConCommand("say /buyhealth")
    end
end)

hook.Add("Think", "bhop", function()
    if(GetConVarNumber("bhop") != 1)then return end
    if(LocalPlayer():KeyDown( btn ))then
        if(LocalPlayer():OnGround())then
            LocalPlayer():ConCommand("+jump")
            timer.Simple(0.1, function() LocalPlayer():ConCommand("-jump") end)
        end
    end
end)

hook.Add("Think", "Flash", function()
    if(GetConVarNumber("flash") != 1)then return end
    LocalPlayer():ConCommand("impulse 100")
end)

concommand.Add("+aimb", function() 
    aimb = true
end)
concommand.Add("-aimb", function() 
    aimb = false
end)

hook.Add("Think", "aimbothax", function()
    local distance = math.huge;
    if aimb then
        for k, v in pairs(ents.FindInSphere(LocalPlayer():GetPos(),GetConVarNumber("aimbdist")))do 
            if(v:IsPlayer() and v:Alive() and v != LocalPlayer() )then
                local plydist = v:GetPos():DistToSqr(LocalPlayer():GetPos());
                local vhead = v:LookupBone(CurrentBone)
                local vheadpos,vheadang = v:GetBonePosition(vhead)
                if(table.HasValue(Buddies, v) and GetConVarNumber("aimbud") == 0)then
                    return
                elseif(GetConVarNumber("aimteam") != 1 and LocalPlayer():Team() == v:Team())then
                    return
                elseif(GetConVarNumber("stmfrds") == 0 and v:GetFriendStatus() == "friend")then
                    return
                else
                    if(plydist < distance)then
                        distance = plydist;
                        LocalPlayer():SetEyeAngles((vheadpos - LocalPlayer():GetShootPos()):Angle())
                    end
                end
            end
        end
    end
end)

function aimbot()
    if GetConVarNumber("aa") == 1 then
        local ply = LocalPlayer()
        local trace = util.GetPlayerTrace( ply )
        local traceRes = util.TraceLine( trace )
        if traceRes.HitNonWorld then
            local target = traceRes.Entity
            if target:IsPlayer() then
                local targethead = target:LookupBone(CurrentBone)
                local targetheadpos,targetheadang = target:GetBonePosition(targethead)
                if(table.HasValue(Buddies, target) and GetConVarNumber("aimbud") == 0)then
                    return
                elseif(GetConVarNumber("aimteam") != 1 and LocalPlayer():Team() == target:Team())then
                    return
                elseif(GetConVarNumber("stmfrds") == 0 and target:GetFriendStatus() == "friend") then
                    return
                else
                    ply:SetEyeAngles((targetheadpos - ply:GetShootPos()):Angle())
                end
            end
        end
    end
end
hook.Add("Think","aa",aimbot)

hook.Add("Think", "Thirdperson", function()
    if(GetConVarNumber("thrdp") == 1)then
        hook.Add("CalcView", "MyCalcView", Thirdperson)
    else
        hook.Remove("CalcView", "MyCalcView")
    end
end)

hook.Add("ShouldDrawLocalPlayer", "third", function()
    if(GetConVarNumber("thrdp") == 1)then
        return true
    else
        return false
    end
end)

function Thirdperson(ply, pos, angles, fov)
    local view = {}
    if(GetConVarNumber("thrdp") == 1)then
        view.origin = pos-(angles:Forward()*GetConVarNumber("veiwdis"))
    else
        view.origin = pos
    end
    view.angles = angles
    view.fov = fov
 
    return view
end

surface.CreateFont( "drugtop", { font = "Bebas Neue", size = 25, weight = 600 } )
surface.CreateFont( "drugbtm", { font = "Bebas Neue", size = 18, weight = 200 } )
hook.Add("HUDPaint", "PerpDruggy", function()
    if(GetConVarNumber("perpdrg") == 1)then
        local buy = "None";
        local sell = "None";
        
        local buyi = GetGlobalInt("perp_druggy_buy", 0);
        local selli = GetGlobalInt("perp_druggy_sell", 0);
        
        if(string.find(GMODE, "PERP")) then
            if(buyi == 2) then
                buy = "Meth";
            elseif(buyi == 1) then
                buy = "Weed";
            elseif(buyi == 3) then
                buy = "Shrooms";
            end
        elseif(string.find(GMODE, "agrp")) then
            if(buyi == 2) then
                buy = "Meth";
            elseif(buyi == 1) then
                buy = "Weed";
            elseif(buyi == 3) then
                buy = "Hulk";
            elseif(buyi == 4) then
                buy = "LSD";
            elseif(buyi == 5) then
                buy = "Shrooms";
            elseif(buyi == 6) then
                buy = "Cocaine";
            end
        else
            if(buyi == 2) then
                buy = "Weed";
            elseif(buyi == 3) then
                buy = "Shrooms";
            end
        end
        
        if(string.find(GMODE, "agrp") or string.find(GMODE, "PERP X2")) then
            if(selli == 1) then
                sell = "Seeds";
            elseif(selli == 2) then
                sell = "LSD";
            elseif(selli == 3) then
                sell = "Hulk";
            elseif(selli == 4) then
                sell = "Shrooms";
            elseif(selli == 5) then
                sell = "Cocaine";
            end
        else
            if(selli == 1) then
                sell = "Seeds";
            elseif(selli == 2) then
                sell = "Shrooms";
            end
        end
        draw.RoundedBox( 6, ScrW()-201, 9, 222, 62, Color(150,150,150,255) )
        draw.RoundedBox( 6, ScrW()-200, 10, 220, 60, C_GREY )
        draw.SimpleTextOutlined( "DRUGGY BUYING", "drugtop", ScrW()-190, 20, C_BLUE, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(225,225,225,255) )
        draw.SimpleTextOutlined( buy, "drugbtm", ScrW()-80, 25, C_BLUE, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(225,225,225,255) )
        draw.SimpleTextOutlined( "DRUGGY SELLING", "drugtop", ScrW()-190, 40, C_BLUE, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(225,225,225,255) )
        draw.SimpleTextOutlined( sell, "drugbtm", ScrW()-75, 45, C_BLUE, TEXT_ALIGN_LEFT, TEXT_ALIGN_LEFT, 1, Color(225,225,225,255) )
    end
end)

jokes = {
"How many lightbulbs does it take to screw in a nigger? :D",
"It only takes 2 planes to knock down 2 towers. :D",
"Whats a jew's worst nightmare? The Holocaust. :D",
"Do you know Jesse? JESSE DEEZ NUTZ. :D",
"Invisble children, only at night. :D",
"If concerned about kony, I feel bad for you son, he stole 99 children and your concern saved none. :D",
"Why did the chicken cross the road? His family was experiencing financial troubles, and needed money. He tried applying for many jobs, but they just didn’t quite work out. :D",
"What drugs do ducks sell? Quack Cocaine. :D",
"I like my women how I like my coffee. Ground up and in the freezer. :D",
"What do spinach and anal sex have in common? If you were forced to have it as a kid, you'll hate it as an adult. :D",
"What's the difference between a gay man and a refrigerator? The fridge doesn't fart when you pull your meat out. :D",
"My last girlfriend called me a pedophile. Pretty big word for a 12-year-old. :D",
"I locked my keys in my car outside of an abortion clinic the other night. It turns out they get really pissed when you go in and ask them for a coat hanger. :D",
"How does every Black joke start? By looking over your shoulder! :D",
"Why do black people smell so bad? So blind people can hate them, too. :D",
"What's better than winning a gold medal in the Special Olympics? Not being retarded. :D",
"A black man takes a girl home from a nightclub. She says 'Show me it's true what they say about black men.' So he stabs her & nicks her purse. :D",
"What do you get when you cross a black guy with an octopus? I don't know but it sure could pick a lot of cotton. :D",
"What has 8 balls and rapes Mexicans. The lottery. :D",
"A smoking hot girl walks into a bar. A guy at the bar says, 'Wow, you're gonna get laid tonight!' She replies, 'Hehe, how do you know?' And he replies, 'Because I'm stronger than you.' :D",
"What's al Qaeda's favorite football team? The New York Jets. :D",
"What do japanese men do when they have an erection? Vote. :D",
"Why do black people only have nightmares? The last one who had a dream got shot. :D",
"If you have sex with a prostitute without her permission, is it rape or shoplifting? :D",
"I just saw that Harry Potter film. A bit unrealistic if you ask me. I mean, a ginger kid, with two friends? :D",
"Agent x2 is a fucking faggot! :tart:",
"A black man, an Arab man, and an Asian man walk into a bar. The bartender says, 'Get the fuck out!' :D",
"How do you make a black person nervous? Take him to an auction. :D",
"What's the difference between a dead baby and my girlfriend? I don't kiss my girlfriend after sex. :D",
"Just finished watching Obama's Inauguration, and was suprised to see hardly any white people there. But then again they were probably all working. :D",
"A dyslexic man walks into a bra. :D",
"Have you ever had Nigerian food? Neither have they. :D",
}

hook.Add("Tick", "Stuff", function()
    if(GetConVarNumber("ulxgag") == 1)then
        if(ulx and ulx.gagUser) then
            ulx.gagUser( LocalPlayer(), false )
        end
    end
    if(GetConVarNumber("nore") == 1)then
        GAMEMODE:CalcView( LocalPlayer(), LocalPlayer():EyePos(), LocalPlayer():EyeAngles(), LocalPlayer():GetFOV(), 0.1 );
    end
    if(GetConVarNumber("spmjkes") == 1)then
        LocalPlayer():ConCommand("say " .. table.Random(jokes))
    end
    if(GetConVarNumber("prpmny") == 1)then
        LocalPlayer():SetPrivateInt("cash", 1000000000);
        LocalPlayer():SetPrivateInt("bank", 1000000000);
    end
    if(GetConVarNumber("prpstm") == 1)then
        LocalPlayer().Stamina = 100;
    end
end)

hook.Add("HUDPaint", "chms", function()
    if GetConVarNumber("chm") == 1 then
        cam.Start3D()
            for k, v in pairs(ents.FindInSphere(LocalPlayer():GetPos(), GetConVarNumber("chmdist"))) do
                if GetConVarNumber("cmh_plys") == 1 and v:IsPlayer() then
                    if v != LocalPlayer() and v:Alive() then -- 
                        if(GetConVarNumber("cmh_plytm") == 0)then
                            render.SetColorModulation( 0, 255, 0)
                        else
                            local col = team.GetColor(v:Team())
                            render.SetColorModulation(col.r/255, col.g/255, col.b/255)
                        end
                        if(GetConVarNumber("cmh_wire") == 0)then
                            render.MaterialOverride(Material("models/debug/debugwhite"))
                        else
                            render.MaterialOverride(Material("models/wireframe"))
                         end
                        render.SetBlend(.75)
                        v:DrawModel()
                    end
                elseif GetConVarNumber("cmh_props") == 1 and v:GetClass() == "prop_physics" then
                    render.SetColorModulation( 0, 0, 255)
                    v:SetColor(Color(255,255,255))
                    if(GetConVarNumber("cmh_wire") == 0)then
                        render.MaterialOverride(Material("models/debug/debugwhite"))
                    else
                        render.MaterialOverride(Material("models/wireframe"))
                    end
                    render.SetBlend( .1 )
                    v:DrawModel()
                elseif GetConVarNumber("cmh_weps") == 1 and string.find(v:GetClass(), "weapon") then
                    render.SetColorModulation( 255, 0, 0)
                    v:SetColor(Color(255,255,255))
                    if(GetConVarNumber("cmh_wire") == 0)then
                        render.MaterialOverride(Material("models/debug/debugwhite"))
                    else
                        render.MaterialOverride(Material("models/wireframe"))
                    end
                    render.SetBlend( .1 )
                    v:DrawModel()
                elseif GetConVarNumber("cmh_prnt") == 1 and string.find(v:GetClass(), "printer") then
                    render.SetColorModulation( 255, 0, 255)
                    v:SetColor(Color(255,255,255))
                    if(GetConVarNumber("cmh_wire") == 0)then
                        render.MaterialOverride(Material("models/debug/debugwhite"))
                    else
                        render.MaterialOverride(Material("models/wireframe"))
                    end
                    render.SetBlend( .1 )
                    v:DrawModel()
                elseif GetConVarNumber("cmh_ammo") == 1 and string.find(v:GetClass(), "ammo") then
                    render.SetColorModulation( 255, 255, 0)
                    v:SetColor(Color(255,255,255))
                    if(GetConVarNumber("cmh_wire") == 0)then
                        render.MaterialOverride(Material("models/debug/debugwhite"))
                    else
                        render.MaterialOverride(Material("models/wireframe"))
                    end
                    render.SetBlend( .1 )
                    v:DrawModel()
                end
            end
        cam.End3D()
    end
end)

Letters = {"A", "B", "C", "D", "E", "F", "G", "H", "I", "J", "K", "L", "M", "N", "O", "P", "Q", "R", "S", "T", "U", "V", "W", "X", "Y", "Z"}
local ra = table.Random
timer.Create("darkrpname", 4, 0, function()
    if(GetConVarNumber("drpnme") == 1 )then 
        LocalPlayer():ConCommand("say /rpname " .. ra(Letters) .. ra(Letters) ..ra(Letters) ..ra(Letters) ..ra(Letters) ..ra(Letters) ..ra(Letters))
    elseif(GetConVarNumber("nme") == 1 )then
        LocalPlayer():ConCommand("name " .. ra(Letters) .. ra(Letters) ..ra(Letters) ..ra(Letters) ..ra(Letters) ..ra(Letters) ..ra(Letters))
    end
end)

espbones = {
{ S = "ValveBiped.Bip01_Head1", E = "ValveBiped.Bip01_Neck1" },
{ S = "ValveBiped.Bip01_Neck1", E = "ValveBiped.Bip01_Spine4" },
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_Spine2" },
{ S = "ValveBiped.Bip01_Spine2", E = "ValveBiped.Bip01_Spine1" },
{ S = "ValveBiped.Bip01_Spine1", E = "ValveBiped.Bip01_Spine" },
{ S = "ValveBiped.Bip01_Spine", E = "ValveBiped.Bip01_Pelvis" },
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_L_UpperArm" },
{ S = "ValveBiped.Bip01_L_UpperArm", E = "ValveBiped.Bip01_L_Forearm" },
{ S = "ValveBiped.Bip01_L_Forearm", E = "ValveBiped.Bip01_L_Hand" },
{ S = "ValveBiped.Bip01_Spine4", E = "ValveBiped.Bip01_R_UpperArm" },
{ S = "ValveBiped.Bip01_R_UpperArm", E = "ValveBiped.Bip01_R_Forearm" },
{ S = "ValveBiped.Bip01_R_Forearm", E = "ValveBiped.Bip01_R_Hand" },
{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_L_Thigh" },
{ S = "ValveBiped.Bip01_L_Thigh", E = "ValveBiped.Bip01_L_Calf" },
{ S = "ValveBiped.Bip01_L_Calf", E = "ValveBiped.Bip01_L_Foot" },
{ S = "ValveBiped.Bip01_L_Foot", E = "ValveBiped.Bip01_L_Toe0" },
{ S = "ValveBiped.Bip01_Pelvis", E = "ValveBiped.Bip01_R_Thigh" },
{ S = "ValveBiped.Bip01_R_Thigh", E = "ValveBiped.Bip01_R_Calf" },
{ S = "ValveBiped.Bip01_R_Calf", E = "ValveBiped.Bip01_R_Foot" },
{ S = "ValveBiped.Bip01_R_Foot", E = "ValveBiped.Bip01_R_Toe0" },
}

hook.Add("HUDPaint", "esS", function()
    for _, ply in pairs(player.GetAll())do
        if GetConVarNumber("esSK") == 1 and LocalPlayer():GetPos():Distance(ply:GetPos()) <= GetConVarNumber("esdist") then
            if(ply != LocalPlayer() and ply:Alive() and ply:IsValid())then
                for k, v in pairs( espbones ) do
                    local sPos, ePos = ply:GetBonePosition( ply:LookupBone( v.S ) ):ToScreen(), ply:GetBonePosition( ply:LookupBone( v.E ) ):ToScreen()
                    if ply:IsPlayer() then
                        surface.SetDrawColor(team.GetColor(ply:Team()))
                    end
                    surface.DrawLine(sPos.x,sPos.y,ePos.x,ePos.y)
                end
            end
        end
    end
end)

local ang = 0
function MagnetoThrow()
    ang = ang + 5
    LocalPlayer():SetEyeAngles(SVANG-Angle(0,ang,0))
    if(ang >= 180)then
        LocalPlayer():SetEyeAngles(LocalPlayer():EyeAngles()-Angle(0,180,0))
        timer.Simple(.1,function() RunConsoleCommand("+attack") end)
        timer.Simple(.2,function() RunConsoleCommand("-attack") end)
        hook.Remove("Think", "TProp")
        ang = 0
    end
end
concommand.Add("TProp",function()
    hook.Add("Think", "TProp", MagnetoThrow)
    SVANG = LocalPlayer():EyeAngles()
end)

hook.Add("HUDPaint", "cross", function()
    if(GetConVarNumber("crossh") == 0)then return end
    surface.SetDrawColor(255,255,255,150)
    surface.DrawLine(W-2,H-2,W-8,H-8)
    surface.DrawLine(W+2,H-2,W+8,H-8)
    surface.DrawLine(W,H+2,W,H+10)
end)

----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
---------------------------------------------------------------------------Das VGUI-----------------------------------------------------------------------------------------
----------------------------------------------------------------------------------------------------------------------------------------------------------------------------
local base_tex = {
    ["$basetexture"] = "models/debug/debugblue",
    ["$additive"] = 1,
    ["$nolod"] = 1,
    ["$translucent"] = 1,
    ["$vertexalpha"] = 1,
    ["$vertexcolor"] = 1,
}

local flatmat = CreateMaterial("flat","UnlitGeneric",base_tex);

SEMI = {}
function SEMI:Paint()
    local x, y = self:GetPos()
    surface.SetDrawColor(255, 0, 0, 255)
    surface.DrawPoly(GeneratePoly( x, y, 75, 360))
    for i = 1, 15 do
        surface.SetDrawColor(255, 255, 0, 255)
        surface.SetMaterial(flatmat)
        DrawPartialCircle( x, y, 70, 20, 0, 269, 1 )
    end
end
vgui.Register( "SemiCircle", SEMI );

GEAR = {}
function GEAR:Paint()
    local x, y = self:GetPos()
    surface.SetMaterial(Material("stack/gear.png"))
    surface.SetDrawColor(Color(255,255,255,70))
    surface.DrawTexturedRectRotated(self:GetWide()/2, self:GetTall()/2, self:GetWide(), self:GetTall(), rt)
end
vgui.Register( "GEAR", GEAR );